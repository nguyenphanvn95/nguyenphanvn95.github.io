/**
 * background.js - Service Worker (Manifest V3)
 *
 * Relay messages between content scripts and the offscreen engine host.
 * Engine binaries are loaded in the offscreen document, not inside the SW.
 */

let engineReady = false;
let engineLoading = false;
let offscreenCreated = false;
let selectedEngine = 'yaneuraou';
let lastEngineError = null;

const STREAM_SOURCE_KEY = 'shStreamSourceTabId';
const STREAM_MODE_PREFIX = 'shStreamModeTab_';

let pendingAnalysis = null;
let pendingTabId = null;
let hostDebugState = {
  currentSfen: null,
  currentVariant: null,
  bestDepthSeen: 0,
  pvBufferDepths: [],
  lastAnalyzeRequest: null,
  lastEngineLines: [],
};

const attachedTabs = new Set();

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

async function setSingleStreamMode(tabId, enabled) {
  const key = `${STREAM_MODE_PREFIX}${tabId}`;
  const update = { [key]: !!enabled };
  if (enabled) update[STREAM_SOURCE_KEY] = tabId;
  await storageSet(update);
}

async function setStreamModeSource(sourceTabId) {
  const prev = await storageGet([STREAM_SOURCE_KEY]);
  const prevTabId = Number(prev?.[STREAM_SOURCE_KEY]);
  const update = {
    [STREAM_SOURCE_KEY]: sourceTabId,
    [`${STREAM_MODE_PREFIX}${sourceTabId}`]: true,
  };
  if (prevTabId && prevTabId !== sourceTabId) {
    update[`${STREAM_MODE_PREFIX}${prevTabId}`] = false;
  }
  await storageSet(update);
}

function log(...args) { console.log('[SH-BG]', ...args); }
function warn(...args) { console.warn('[SH-BG]', ...args); }
function err(...args) { console.error('[SH-BG]', ...args); }

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomInt(min, max) {
  const lo = Number.isFinite(min) ? Math.round(min) : 0;
  const hi = Number.isFinite(max) ? Math.round(max) : lo;
  if (hi <= lo) return lo;
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

async function ensureAttached(tabId) {
  if (attachedTabs.has(tabId)) return true;
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
    attachedTabs.add(tabId);
    log('Debugger attached to tab', tabId);
    return true;
  } catch (e) {
    if (String(e?.message || '').includes('already attached')) {
      attachedTabs.add(tabId);
      return true;
    }
    warn('Debugger attach failed for tab', tabId, e?.message || e);
    return false;
  }
}

chrome.debugger.onDetach.addListener((source) => {
  if (source?.tabId != null) {
    attachedTabs.delete(source.tabId);
    warn('Debugger detached from tab', source.tabId);
  }
});

async function cdpMouse(tabId, type, x, y, button = 'left', buttons = 0, clickCount = 0) {
  await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type,
    x: Math.round(x),
    y: Math.round(y),
    button,
    buttons,
    clickCount,
    modifiers: 0,
    deltaX: 0,
    deltaY: 0,
  });
}

async function handleShogiClickSequence(msg, sender) {
  const tabId = sender?.tab?.id;
  if (!tabId) return { ok: false, error: 'no_tab_id' };
  if (!(await ensureAttached(tabId))) return { ok: false, error: 'debugger_unavailable' };
  try {
    const points = Array.isArray(msg.points) ? msg.points : [];
    const delayMinMs = Number.isFinite(msg.delayMinMs) ? msg.delayMinMs : 70;
    const delayMaxMs = Number.isFinite(msg.delayMaxMs) ? msg.delayMaxMs : 110;
    log('SHOGI_CLICK_SEQUENCE tab', tabId, '| points:', points.length);
    for (let i = 0; i < points.length; i++) {
      const pt = points[i];
      if (!pt || !Number.isFinite(pt.x) || !Number.isFinite(pt.y)) continue;
      await cdpMouse(tabId, 'mouseMoved', pt.x, pt.y, 'none', 0);
      await sleep(12);
      await cdpMouse(tabId, 'mousePressed', pt.x, pt.y, 'left', 1, 1);
      await sleep(24);
      await cdpMouse(tabId, 'mouseReleased', pt.x, pt.y, 'left', 0, 1);
      if (i < points.length - 1) {
        await sleep(randomInt(delayMinMs, delayMaxMs));
      }
    }
    return { ok: true };
  } catch (e) {
    warn('SHOGI_CLICK_SEQUENCE error:', e?.message || e);
    return { ok: false, error: String(e?.message || e) };
  }
}

async function handleShogiDragMove(msg, sender) {
  const tabId = sender?.tab?.id;
  if (!tabId) return { ok: false, error: 'no_tab_id' };
  if (!(await ensureAttached(tabId))) return { ok: false, error: 'debugger_unavailable' };
  try {
    const { fromX, fromY, toX, toY, intermediates = [] } = msg;
    if (![fromX, fromY, toX, toY].every(Number.isFinite)) {
      return { ok: false, error: 'invalid_drag_points' };
    }
    const waypoints = [{ x: fromX, y: fromY }, ...intermediates, { x: toX, y: toY }];
    log('SHOGI_DRAG_MOVE tab', tabId, '| from', Math.round(fromX), Math.round(fromY), 'to', Math.round(toX), Math.round(toY));
    await cdpMouse(tabId, 'mouseMoved', fromX, fromY, 'none', 0);
    await sleep(20);
    await cdpMouse(tabId, 'mousePressed', fromX, fromY, 'left', 1, 1);
    await sleep(36);
    const steps = 10;
    for (let seg = 0; seg < waypoints.length - 1; seg++) {
      const start = waypoints[seg];
      const end = waypoints[seg + 1];
      for (let i = 1; i <= steps; i++) {
        const x = start.x + (end.x - start.x) * (i / steps);
        const y = start.y + (end.y - start.y) * (i / steps);
        await cdpMouse(tabId, 'mouseMoved', x, y, 'left', 1);
        await sleep(10);
      }
      if (seg < waypoints.length - 2) await sleep(40);
    }
    await cdpMouse(tabId, 'mouseReleased', toX, toY, 'left', 0, 1);
    await sleep(20);
    await cdpMouse(tabId, 'mouseMoved', toX, toY, 'none', 0);
    return { ok: true };
  } catch (e) {
    warn('SHOGI_DRAG_MOVE error:', e?.message || e);
    return { ok: false, error: String(e?.message || e) };
  }
}

async function loadSettings() {
  try {
    const { engineType } = await chrome.storage.local.get(['engineType']);
    if (engineType) selectedEngine = engineType;
  } catch (e) {
    warn('loadSettings failed:', e?.message || e);
  }
}

async function ensureOffscreen() {
  if (offscreenCreated) return true;
  try {
    const existing = await chrome.offscreen.hasDocument?.();
    if (existing) {
      offscreenCreated = true;
      return true;
    }
  } catch (e) {}

  try {
    await chrome.offscreen.createDocument({
      url: chrome.runtime.getURL('src/engine-host.html'),
      reasons: ['WORKERS'],
      justification: 'Run local Shogi engines for analysis',
    });
    offscreenCreated = true;
    log('Offscreen document created');
    return true;
  } catch (e) {
    err('Failed to create offscreen document:', e);
    try {
      await chrome.offscreen.closeDocument();
      await chrome.offscreen.createDocument({
        url: chrome.runtime.getURL('src/engine-host.html'),
        reasons: ['WORKERS'],
        justification: 'Run local Shogi engines for analysis',
      });
      offscreenCreated = true;
      log('Offscreen document re-created');
      return true;
    } catch (e2) {
      err('Offscreen re-create failed:', e2);
      return false;
    }
  }
}

async function sendToOffscreen(message) {
  const ok = await ensureOffscreen();
  if (!ok) {
    err('No offscreen document, cannot send message');
    return false;
  }

  try {
    await chrome.runtime.sendMessage(message);
    return true;
  } catch (e) {
    warn('sendToOffscreen failed:', e?.message || e, 'recreating offscreen');
    offscreenCreated = false;
    const ok2 = await ensureOffscreen();
    if (!ok2) return false;
    try {
      await chrome.runtime.sendMessage(message);
      return true;
    } catch (e2) {
      err('sendToOffscreen retry failed:', e2);
      return false;
    }
  }
}

function broadcastStatus(extra = {}) {
  chrome.tabs.query({ url: '*://lishogi.org/*' }, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'ENGINE_STATUS_UPDATE',
        ready: engineReady,
        loading: engineLoading,
        engine: selectedEngine,
        ...extra,
      }).catch(() => {});
    }
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === 'OPEN_STREAM_WINDOW') {
    const sourceTabId = Number.isFinite(Number(msg.tabId)) ? Number(msg.tabId) : tabId;
    if (!sourceTabId) {
      sendResponse?.({ ok: false, error: 'no_source_tab' });
      return false;
    }
    setStreamModeSource(sourceTabId)
      .then(() => chrome.windows.create({
        url: chrome.runtime.getURL(`src/stream.html?tabId=${sourceTabId}`),
        type: 'popup',
        width: 1180,
        height: 860,
        focused: true,
      }))
      .then(() => sendResponse?.({ ok: true }))
      .catch((error) => sendResponse?.({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (msg.type === 'SET_STREAM_MODE') {
    const sourceTabId = Number.isFinite(Number(msg.tabId)) ? Number(msg.tabId) : tabId;
    if (!sourceTabId) {
      sendResponse?.({ ok: false, error: 'no_source_tab' });
      return false;
    }
    setSingleStreamMode(sourceTabId, msg.enabled !== false)
      .then(() => {
        chrome.tabs.sendMessage(sourceTabId, { type: 'SET_STREAM_MODE', enabled: msg.enabled !== false }).catch(() => {});
        sendResponse?.({ ok: true });
      })
      .catch((error) => sendResponse?.({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (msg.type === 'GET_SELF_TAB_ID') {
    sendResponse?.({ ok: true, tabId: tabId || null });
    return false;
  }

  if (msg.type === 'STREAM_WINDOW_CLOSED') {
    const sourceTabId = Number.isFinite(Number(msg.tabId)) ? Number(msg.tabId) : tabId;
    if (!sourceTabId) return false;
    setSingleStreamMode(sourceTabId, false).catch(() => {});
    chrome.tabs.sendMessage(sourceTabId, { type: 'SET_STREAM_MODE', enabled: false }).catch(() => {});
    return false;
  }

  if (msg.type === 'STREAM_COMMAND') {
    const sourceTabId = Number.isFinite(Number(msg.tabId)) ? Number(msg.tabId) : null;
    const command = String(msg.command || '').trim();
    if (!sourceTabId || !command) {
      sendResponse?.({ ok: false, error: 'invalid_stream_command' });
      return false;
    }
    chrome.tabs.sendMessage(sourceTabId, { type: 'STREAM_COMMAND', command }, (response) => {
      if (chrome.runtime.lastError) {
        sendResponse?.({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse?.(response || { ok: true });
    });
    return true;
  }

  if (msg.type === 'ANALYZE') {
    const engine = msg.engine || selectedEngine;
    pendingTabId = tabId;
    pendingAnalysis = {
      sfen: msg.sfen,
      variant: msg.variant,
      multiPV: msg.multiPV,
      depth: msg.depth,
      engine,
    };

    log('ANALYZE from tab', tabId, '| engine:', engine, '| variant:', msg.variant, '| depth:', msg.depth);

    sendToOffscreen({
      type: 'HOST_ANALYZE',
      sfen: msg.sfen,
      variant: msg.variant,
      multiPV: msg.multiPV || 3,
      depth: msg.depth || 15,
      engine,
    }).then((ok) => {
      if (!ok && tabId) {
        chrome.tabs.sendMessage(tabId, {
          type: 'ANALYSIS_RESULT',
          moves: [],
          sfen: msg.sfen,
          engine,
          error: 'Offscreen document unavailable',
        }).catch(() => {});
      }
    });

    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'SET_ENGINE') {
    selectedEngine = msg.engine || 'yaneuraou';
    chrome.storage.local.set({ engineType: selectedEngine }).catch(() => {});
    sendToOffscreen({ type: 'HOST_SET_ENGINE', engine: selectedEngine }).catch(() => {});
    broadcastStatus();
    sendResponse({ ok: true, engine: selectedEngine });
    return false;
  }

  if (msg.type === 'GET_ENGINE_SETTINGS') {
    sendResponse({ engine: selectedEngine });
    return false;
  }

  if (msg.type === 'STOP_ANALYSIS') {
    log('STOP_ANALYSIS from tab', tabId);
    pendingTabId = null;
    sendToOffscreen({ type: 'HOST_STOP' });
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'SHOGI_UPDATE' && msg.data) {
    const payload = tabId ? { ...msg.data, tabId } : msg.data;
    const update = { shogiState: payload };
    if (tabId) update[`shogiState_tab_${tabId}`] = payload;
    chrome.storage.local.set(update);
    return false;
  }

  if (msg.type === 'GET_STATE') {
    const sourceTabId = Number.isFinite(Number(msg.tabId)) ? Number(msg.tabId) : tabId;
    const key = sourceTabId ? `shogiState_tab_${sourceTabId}` : 'shogiState';
    chrome.storage.local.get([key, 'shogiState'], (s) => sendResponse(s[key] || s.shogiState || null));
    return true;
  }

  if (msg.type === 'ENGINE_READY_CHECK') {
    sendResponse({ ready: engineReady, loading: engineLoading, engine: selectedEngine, error: lastEngineError });
    return false;
  }

  if (msg.type === 'ENGINE_LOG_DUMP') {
    sendToOffscreen({ type: 'HOST_STATUS_CHECK' }).catch(() => {});
    sendResponse({
      engineReady,
      engineLoading,
      offscreenCreated,
      selectedEngine,
      lastEngineError,
      pendingTabId,
      pendingAnalysis: pendingAnalysis ? pendingAnalysis.sfen?.substring(0, 40) : null,
      ...hostDebugState,
    });
    return false;
  }

  if (msg.type === 'SHOGI_CLICK_SEQUENCE') {
    handleShogiClickSequence(msg, sender).then(sendResponse);
    return true;
  }

  if (msg.type === 'SHOGI_DRAG_MOVE') {
    handleShogiDragMove(msg, sender).then(sendResponse);
    return true;
  }

  if (!tabId) {
    if (msg.type === 'ENGINE_STATUS') {
      engineReady = !!msg.ready;
      engineLoading = !!msg.loading;
      if (msg.engine) selectedEngine = msg.engine;
      lastEngineError = msg.error || null;
      log('ENGINE_STATUS ready:', engineReady, 'loading:', engineLoading, 'engine:', selectedEngine, msg.error ? '| error: ' + msg.error : '');

      broadcastStatus({ error: msg.error });
    }

    if (msg.type === 'ENGINE_RESULT') {
      log('ENGINE_RESULT moves:', msg.moves?.length, '| depth:', msg.depth, '| tabId:', pendingTabId);
      if (pendingTabId) {
        chrome.tabs.sendMessage(pendingTabId, {
          type: 'ANALYSIS_RESULT',
          moves: msg.moves || [],
          sfen: msg.sfen,
          depth: msg.depth,
          variant: msg.variant,
          engine: msg.engine || selectedEngine,
          error: msg.error,
        }).catch((e) => warn('Forward ANALYSIS_RESULT failed:', e?.message || e));
      } else {
        warn('ENGINE_RESULT but no pendingTabId');
      }
    }

    if (msg.type === 'ENGINE_HOST_STATE') {
      hostDebugState = {
        currentSfen: msg.currentSfen || null,
        currentVariant: msg.currentVariant || null,
        bestDepthSeen: msg.bestDepthSeen || 0,
        pvBufferDepths: Array.isArray(msg.pvBufferDepths) ? msg.pvBufferDepths : [],
        lastAnalyzeRequest: msg.lastAnalyzeRequest || null,
        lastEngineLines: Array.isArray(msg.lastEngineLines) ? msg.lastEngineLines : [],
      };
    }
  }
});

async function init() {
  await loadSettings();
  log('Init with engine:', selectedEngine);
  const ok = await ensureOffscreen();
  if (!ok) return;
  try {
    await chrome.runtime.sendMessage({ type: 'HOST_INIT', engine: selectedEngine });
  } catch (e) {
    log('HOST_INIT send failed while offscreen starts:', e?.message || e);
  }
}

chrome.runtime.onInstalled.addListener(() => { log('onInstalled'); init(); });
chrome.runtime.onStartup.addListener(() => { log('onStartup'); init(); });
self.addEventListener('activate', () => { log('SW activate'); init(); });
