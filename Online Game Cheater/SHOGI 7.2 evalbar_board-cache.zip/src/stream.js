'use strict';

const STREAM_SOURCE_KEY = 'shStreamSourceTabId';
const FALLBACK_STATE_KEY = 'shogiState';
const MIN_CELL = 34;
const MAX_CELL = 96;
const HAND_GAP = 9;
const DEFAULT_CELL = 62;
const ROWS = 'abcdefghijklmnopqrstuvwxyz';

let cellSize = DEFAULT_CELL;
let currentTabId = Number(new URLSearchParams(window.location.search).get('tabId')) || null;
let latestState = null;
let renderedSignature = '';
let boardApi = null;
let boardMetaKey = '';
let initialWindowFitted = false;
let fitTimer = 0;

const pieceCssEl = document.getElementById('streamPieceCss');
const boardAreaEl = document.getElementById('boardArea');
const boardClusterEl = document.getElementById('boardCluster');
const boardHostEl = document.getElementById('streamBoard');
const handTopEl = document.getElementById('streamHandTop');
const handBottomEl = document.getElementById('streamHandBottom');
const arrowEl = document.getElementById('streamArrow');

const sideEls = {
  tabPanelBtn: document.getElementById('tabPanelBtn'),
  tabSettingBtn: document.getElementById('tabSettingBtn'),
  panelTab: document.getElementById('panelTab'),
  settingTab: document.getElementById('settingTab'),
  sync: document.getElementById('spSync'),
  variant: document.getElementById('spVariant'),
  player: document.getElementById('spPlayer'),
  turn: document.getElementById('spTurn'),
  engine: document.getElementById('spEngine'),
  best: document.getElementById('spBest'),
  eval: document.getElementById('spEval'),
  hints: document.getElementById('spHints'),
  handSente: document.getElementById('spHandSente'),
  handGote: document.getElementById('spHandGote'),
  sfen: document.getElementById('spSfen'),
  fixPlayer: document.getElementById('spFixPlayer'),
  fixTurn: document.getElementById('spFixTurn'),
  boardSync: document.getElementById('boardSync'),
  exitStream: document.getElementById('btnExitStream'),
};

function stateKey(tabId) {
  return tabId ? `shogiState_tab_${tabId}` : FALLBACK_STATE_KEY;
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function parseDims(dims) {
  const [files, ranks] = String(dims || '9x9').split('x').map(Number);
  return {
    files: Number.isFinite(files) ? files : 9,
    ranks: Number.isFinite(ranks) ? ranks : 9,
  };
}

function getRolesForVariant(variant) {
  if (variant === 'dobutsu') return ['giraffe', 'elephant', 'chick'];
  return ['rook', 'bishop', 'gold', 'silver', 'knight', 'lance', 'pawn'];
}

function getPieceCssHref(variant) {
  const base = 'vendor/shogi-analysis/piece-css/';
  if (variant === 'dobutsu') return `${base}dobutsu/dobutsu.css`;
  if (variant === 'chushogi') return `${base}chushogi/ryoko_1kanji.css`;
  if (variant === 'kyotoshogi') return `${base}kyotoshogi/ryoko_1kanji.css`;
  return `${base}standard/ryoko_1kanji.css`;
}

function makeForsythAdapter(variant) {
  const standardMap = {
    p: 'pawn',
    l: 'lance',
    n: 'knight',
    s: 'silver',
    g: 'gold',
    b: 'bishop',
    r: 'rook',
    '+p': 'tokin',
    '+l': 'promotedlance',
    '+n': 'promotedknight',
    '+s': 'promotedsilver',
    '+b': 'horse',
    '+r': 'dragon',
    k: 'king',
  };
  const dobutsuMap = {
    l: 'king',
    g: 'giraffe',
    e: 'elephant',
    c: 'chick',
    h: 'hen',
  };
  const map = variant === 'dobutsu' ? dobutsuMap : standardMap;
  const reverse = Object.fromEntries(Object.entries(map).map(([key, value]) => [value, key]));
  return {
    fromForsyth(piece) {
      return map[String(piece || '').toLowerCase()];
    },
    toForsyth(role) {
      return reverse[role];
    },
  };
}

function colorLabel(color) {
  if (color === 'sente') return 'Sente';
  if (color === 'gote') return 'Gote';
  return '-';
}

function formatHandDisplay(hand) {
  const order = ['R', 'B', 'G', 'S', 'N', 'L', 'P', 'E', 'C', 'H'];
  return order.filter((piece) => hand?.[piece] > 0).map((piece) => `${piece}x${hand[piece]}`).join(' ') || '-';
}

function variantLabel(state) {
  const labels = {
    standard: '9x9 Standard',
    minishogi: '5x5 Minishogi',
    kyotoshogi: '5x5 Kyoto Shogi',
    dobutsu: '3x4 Dobutsu',
    annanshogi: '9x9 Annan Shogi',
    checkshogi: '9x9 Check Shogi',
    chushogi: '12x12 Chu Shogi',
  };
  return labels[state?.variant] || `${state?.boardDims || '9x9'} ${state?.variant || 'standard'}`;
}

function parseSfenParts(sfen) {
  const parts = String(sfen || '').trim().split(/\s+/);
  return {
    board: parts[0] || '',
    turn: parts[1] || 'b',
    hands: parts[2] || '-',
    move: parts[3] || '1',
  };
}

function parseUsiMove(usi) {
  const move = String(usi || '').trim();
  if (!move || move === 'resign' || move === 'win') return null;
  const drop = move.match(/^([A-Z])\*(\d+)([a-z])$/i);
  if (drop) {
    return {
      drop: drop[1].toUpperCase(),
      toCol: parseInt(drop[2], 10),
      toRow: ROWS.indexOf(drop[3].toLowerCase()) + 1,
      promote: false,
    };
  }
  const normal = move.match(/^(\d+)([a-z])(\d+)([a-z])(\+)?$/i);
  if (!normal) return null;
  return {
    fromCol: parseInt(normal[1], 10),
    fromRow: ROWS.indexOf(normal[2].toLowerCase()) + 1,
    toCol: parseInt(normal[3], 10),
    toRow: ROWS.indexOf(normal[4].toLowerCase()) + 1,
    promote: !!normal[5],
  };
}

function squareCenter(col, row, dims, orientation) {
  if (!Number.isFinite(col) || !Number.isFinite(row)) return null;
  const clusterRect = boardClusterEl.getBoundingClientRect();
  const rect = boardHostEl.getBoundingClientRect();
  const stepX = rect.width / dims.files;
  const stepY = rect.height / dims.ranks;
  const displayCol = orientation === 'gote' ? col - 1 : dims.files - col;
  const displayRow = orientation === 'gote' ? dims.ranks - row : row - 1;
  return {
    x: rect.left - clusterRect.left + displayCol * stepX + stepX / 2,
    y: rect.top - clusterRect.top + displayRow * stepY + stepY / 2,
    stepX,
  };
}

function getDropPieceClass(state, pieceLetter) {
  if (state?.variant === 'dobutsu') {
    if (pieceLetter === 'G') return 'giraffe';
    if (pieceLetter === 'E') return 'elephant';
    if (pieceLetter === 'C') return 'chick';
    if (pieceLetter === 'H') return 'hen';
    if (pieceLetter === 'L') return 'king';
  }
  return {
    R: 'rook',
    B: 'bishop',
    G: 'gold',
    S: 'silver',
    N: 'knight',
    L: 'lance',
    P: 'pawn',
  }[pieceLetter] || null;
}

function getHintColor(index) {
  return ['#48a4ff', '#ff7a5e', '#ffd166', '#63d191', '#d987ff', '#ffb26b'][index] || '#48a4ff';
}

function formatEval(move) {
  if (!move) return '-';
  if (move.mate != null) return move.mate > 0 ? `#${move.mate}` : `#-${Math.abs(move.mate)}`;
  if (move.cp != null) return `${move.cp > 0 ? '+' : ''}${move.cp}`;
  return '?';
}

function formatHintLines(state) {
  const moves = Array.isArray(state?.engineMoves) ? state.engineMoves : [];
  if (!state?.analysisOn) return 'Engine off';
  if (!moves.length) {
    if (state?.analysisState === 'loading') return `Loading ${state?.engineType || 'engine'}...`;
    if (state?.analysisState === 'error') return `Error: ${state?.engineType || 'engine'} unavailable`;
    return `Analyzing with ${state?.engineType || 'engine'}... (d${state?.analysisDepth || '?'})`;
  }
  return moves
    .slice(0, Math.max(1, state?.multiPV || 3))
    .map((move, index) => {
      const evalStr = formatEval(move);
      const firstMove = move?.pv?.[0] || '?';
      const pvText = move?.pv?.slice(0, 5).join(' ') || '';
      return `#${index + 1} ${evalStr}  ${firstMove}  ${pvText}  d${move?.depth || '?'}`;
    })
    .join('\n');
}

function clearArrows() {
  arrowEl.innerHTML = '';
}

function drawArrowLine(from, to, color, width, markerId, opacity) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const len = Math.hypot(dx, dy);
  if (!len) return null;
  const shrink = Math.min(15, len * 0.12) / len;
  const x2 = to.x - dx * shrink;
  const y2 = to.y - dy * shrink;
  const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', String(from.x));
  line.setAttribute('y1', String(from.y));
  line.setAttribute('x2', String(x2));
  line.setAttribute('y2', String(y2));
  line.setAttribute('stroke', color);
  line.setAttribute('stroke-width', String(width));
  line.setAttribute('stroke-linecap', 'round');
  line.setAttribute('marker-end', `url(#${markerId})`);
  line.setAttribute('opacity', String(opacity));
  return line;
}

function findHandAnchor(state, pieceLetter) {
  const pieceClass = getDropPieceClass(state, pieceLetter);
  if (!pieceClass) return null;
  const handEl = state.currentTurn === state.orientation ? handBottomEl : handTopEl;
  const candidate = Array.from(handEl.querySelectorAll(`piece.${pieceClass}`)).find((node) => {
    const wrap = node.closest('sg-hp-wrap');
    return wrap && parseInt(wrap.getAttribute('data-nb') || '0', 10) > 0;
  });
  const rect = candidate?.getBoundingClientRect();
  if (!rect) return null;
  const clusterRect = boardClusterEl.getBoundingClientRect();
  const edgeInset = Math.min(rect.width, rect.height) * 0.18;
  const isLeftHand = handEl === handTopEl;
  return {
    x: (isLeftHand ? rect.right - edgeInset : rect.left + edgeInset) - clusterRect.left,
    y: rect.top + rect.height / 2 - clusterRect.top,
  };
}

function drawArrows(state) {
  clearArrows();
  if (!state?.engineMoves?.length) return;
  const dims = parseDims(state.boardDims);
  const rect = boardClusterEl.getBoundingClientRect();
  if (!rect.width || !rect.height) return;

  arrowEl.setAttribute('viewBox', `0 0 ${rect.width} ${rect.height}`);
  const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
  const hintCount = Math.min(state.engineMoves.length, Math.max(1, state.multiPV || 3));
  defs.innerHTML = Array.from({ length: hintCount }, (_, index) => `
    <marker id="stream-arr-${index + 1}" markerWidth="5.6" markerHeight="5.6" refX="4.8" refY="2.8" orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L0,5.6 L5.6,2.8 z" fill="${getHintColor(index)}"></path>
    </marker>
  `).join('');
  arrowEl.appendChild(defs);

  for (let index = 0; index < hintCount; index += 1) {
    const move = state.engineMoves[index];
    const parsed = parseUsiMove(move?.pv?.[0]);
    if (!parsed) continue;
    const color = getHintColor(index);
    const width = Math.max(1.8, rect.width / dims.files * (0.034 - Math.min(index, 5) * 0.003));
    let from = null;
    let to = squareCenter(parsed.toCol, parsed.toRow, dims, state.orientation || 'sente');
    if (!to) continue;
    if (parsed.drop) {
      from = findHandAnchor(state, parsed.drop);
    } else {
      from = squareCenter(parsed.fromCol, parsed.fromRow, dims, state.orientation || 'sente');
    }
    if (!from) continue;
    const line = drawArrowLine(from, to, color, width, `stream-arr-${index + 1}`, index === 0 ? 0.94 : 0.8);
    if (!line) continue;
    arrowEl.appendChild(line);

    const target = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    target.setAttribute('cx', String(to.x));
    target.setAttribute('cy', String(to.y));
    target.setAttribute('r', String(Math.max(3.2, to.stepX * 0.075)));
    target.setAttribute('fill', color);
    target.setAttribute('opacity', index === 0 ? '0.94' : '0.82');
    arrowEl.appendChild(target);
  }
}

function applyBoardSize(state) {
  const dims = parseDims(state?.boardDims);
  const handSlots = getRolesForVariant(state?.variant).length || 7;
  document.body.style.setProperty('--files', String(dims.files));
  document.body.style.setProperty('--ranks', String(dims.ranks));
  document.body.style.setProperty('--hand-slots', String(handSlots));

  const handWidth = Math.max(42, Math.round(cellSize * 1.05));
  const boardWidth = Math.round(dims.files * cellSize);
  const boardHeight = Math.round(dims.ranks * cellSize * 12 / 11);
  const handHeight = Math.max(44, Math.round(boardHeight * Math.min(0.84, handSlots / dims.files)));
  const shellHeight = boardHeight;

  document.body.style.setProperty('--cell', `${cellSize}px`);
  document.body.style.setProperty('--hand-w', `${handWidth}px`);
  document.body.style.setProperty('--hand-h', `${handHeight}px`);
  document.body.style.setProperty('--board-w', `${boardWidth}px`);
  document.body.style.setProperty('--board-h', `${boardHeight}px`);
  document.body.style.setProperty('--shell-h', `${shellHeight}px`);
}

function maxCellForViewport(state) {
  const dims = parseDims(state?.boardDims);
  const sideWidth = document.querySelector('.sidepanel')?.getBoundingClientRect().width || 380;
  const workspaceStyle = getComputedStyle(document.querySelector('.workspace'));
  const appStyle = getComputedStyle(document.getElementById('app'));
  const topbarHeight = document.querySelector('.board-topbar')?.getBoundingClientRect().height || 62;
  const gap = parseFloat(workspaceStyle.columnGap || workspaceStyle.gap || '10');
  const padX = parseFloat(appStyle.paddingLeft || '0') + parseFloat(appStyle.paddingRight || '0');
  const padY = parseFloat(appStyle.paddingTop || '0') + parseFloat(appStyle.paddingBottom || '0');
  const handColumns = state?.variant === 'chushogi' ? 0 : 2.2;
  const widthAvail = Math.max(240, window.innerWidth - sideWidth - gap - padX - 8);
  const heightAvail = Math.max(240, window.innerHeight - topbarHeight - padY - 20);
  const byWidth = widthAvail / (dims.files + handColumns);
  const byHeight = heightAvail / (dims.ranks * 12 / 11);
  return Math.floor(Math.min(byWidth, byHeight));
}

function fitBoardToViewport(state) {
  const fitCell = maxCellForViewport(state);
  if (Number.isFinite(fitCell)) {
    cellSize = Math.max(MIN_CELL, Math.min(MAX_CELL, Math.min(cellSize, fitCell)));
    applyBoardSize(state);
  }
}

function fitWindowToContent(force = false) {
  if (!chrome?.windows?.getCurrent || !chrome?.windows?.update) return;
  const workspace = document.querySelector('.workspace');
  if (!workspace) return;
  const workspaceRect = workspace.getBoundingClientRect();
  if (!workspaceRect.width || !workspaceRect.height) return;

  const appStyle = getComputedStyle(document.getElementById('app'));
  const docW = Math.max(
    workspaceRect.width,
    document.documentElement.scrollWidth,
    document.body.scrollWidth
  );
  const docH = Math.max(
    workspaceRect.height,
    document.documentElement.scrollHeight,
    document.body.scrollHeight
  );
  const padX = parseFloat(appStyle.paddingLeft || '0') + parseFloat(appStyle.paddingRight || '0');
  const padY = parseFloat(appStyle.paddingTop || '0') + parseFloat(appStyle.paddingBottom || '0');
  const innerW = Math.ceil(docW + padX);
  const innerH = Math.ceil(docH + padY);
  const dw = window.outerWidth - window.innerWidth;
  const dh = window.outerHeight - window.innerHeight;
  const targetW = Math.max(320, innerW + dw);
  const targetH = Math.max(320, innerH + dh);
  const widthDelta = Math.abs(window.outerWidth - targetW);
  const heightDelta = Math.abs(window.outerHeight - targetH);
  if (!force && widthDelta < 6 && heightDelta < 6) return;

  chrome.windows.getCurrent((win) => {
    if (!win?.id) return;
    chrome.windows.update(win.id, { width: targetW, height: targetH }, () => {
      initialWindowFitted = true;
    });
  });
}

function scheduleFitWindow(force = false, delay = 60) {
  window.clearTimeout(fitTimer);
  fitTimer = window.setTimeout(() => fitWindowToContent(force), delay);
}

function ensureBoard(state) {
  const dims = parseDims(state.boardDims);
  const roles = getRolesForVariant(state.variant);
  const boardKey = [state.variant, state.boardDims, state.orientation].join('|');
  pieceCssEl.href = getPieceCssHref(state.variant);

  const sfen = parseSfenParts(state.sfen);
  const config = {
    dimensions: dims,
    orientation: state.orientation || 'sente',
    turnColor: state.currentTurn || (sfen.turn === 'w' ? 'gote' : 'sente'),
    viewOnly: true,
    coordinates: { enabled: true, files: 'numeric', ranks: 'numeric' },
    movable: { free: false, color: undefined, showDests: false },
    premovable: { enabled: false, showDests: false },
    predroppable: { enabled: false, showDests: false },
    draggable: { enabled: false, showGhost: false },
    selectable: { enabled: false },
    drawable: { enabled: false, visible: false },
    hands: { inlined: false, roles },
    sfen: { board: sfen.board, hands: sfen.hands },
    forsyth: makeForsythAdapter(state.variant),
    animation: { enabled: true, hands: true, duration: 180 },
  };

  if (!boardApi || boardMetaKey !== boardKey) {
    if (boardApi?.destroy) boardApi.destroy();
    boardHostEl.innerHTML = '';
    handTopEl.innerHTML = '';
    handBottomEl.innerHTML = '';
    boardApi = Shogiground(config, {
      board: boardHostEl,
      hands: { top: handTopEl, bottom: handBottomEl },
    });
    boardMetaKey = boardKey;
    return;
  }

  boardApi.set(config, false);
}

function renderState(state) {
  if (!state?.sfen) return;
  latestState = state;
  fitBoardToViewport(state);
  ensureBoard(state);
  drawArrows(state);

  const signature = JSON.stringify([
    state.sfen,
    state.variant,
    state.boardDims,
    state.orientation,
    state.currentTurn,
    state.engineType,
    state.engineMoves?.map((move) => move?.pv?.[0] || '').join('|'),
    state.timestamp || 0,
  ]);
  if (signature === renderedSignature) return;
  renderedSignature = signature;

  sideEls.variant.textContent = variantLabel(state);
  sideEls.player.textContent = state.myColor ? `${colorLabel(state.myColor)} (${state.myName || '?'})` : (state.myName || '-');
  sideEls.turn.textContent = state.currentTurn ? colorLabel(state.currentTurn) : '-';
  sideEls.engine.textContent = `${state.engineType || '-'} | ${state.analysisOn ? (state.analysisState || 'ready') : 'off'}`;
  sideEls.best.textContent = state.engineMoves?.[0]?.pv?.[0] || '-';
  sideEls.eval.textContent = formatEval(state.engineMoves?.[0]);
  sideEls.hints.textContent = formatHintLines(state);
  sideEls.handSente.textContent = formatHandDisplay(state.handSente);
  sideEls.handGote.textContent = formatHandDisplay(state.handGote);
  sideEls.sfen.textContent = state.sfen;
  sideEls.sync.textContent = `Updated ${new Date(state.timestamp || Date.now()).toLocaleTimeString()}`;
  sideEls.boardSync.textContent = `${variantLabel(state)} | ${state.orientation || 'sente'} orientation`;
  scheduleFitWindow(true, 50);
}

function activateTab(tabName) {
  const isPanel = tabName === 'panel';
  sideEls.tabPanelBtn.classList.toggle('active', isPanel);
  sideEls.tabSettingBtn.classList.toggle('active', !isPanel);
  sideEls.panelTab.classList.toggle('active', isPanel);
  sideEls.settingTab.classList.toggle('active', !isPanel);
}

function sendStreamCommand(command) {
  if (!currentTabId) return;
  chrome.runtime.sendMessage({ type: 'STREAM_COMMAND', tabId: currentTabId, command }, () => {
    readStateNow();
  });
}

async function readStateNow() {
  const key = stateKey(currentTabId);
  const result = await storageGet([key, FALLBACK_STATE_KEY, STREAM_SOURCE_KEY]);
  if (!currentTabId && Number(result?.[STREAM_SOURCE_KEY])) {
    currentTabId = Number(result[STREAM_SOURCE_KEY]);
  }
  const resolvedKey = stateKey(currentTabId);
  const state = result?.[resolvedKey] || result?.[FALLBACK_STATE_KEY];
  if (state?.sfen) renderState(state);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[STREAM_SOURCE_KEY] && !currentTabId) {
    currentTabId = Number(changes[STREAM_SOURCE_KEY].newValue) || null;
    readStateNow().catch(() => {});
    return;
  }
  const key = stateKey(currentTabId);
  if (changes[key]?.newValue?.sfen) {
    renderState(changes[key].newValue);
    return;
  }
  if (!currentTabId && changes[FALLBACK_STATE_KEY]?.newValue?.sfen) {
    renderState(changes[FALLBACK_STATE_KEY].newValue);
  }
});

(function initResize() {
  const handle = document.getElementById('boardResize');
  let drag = false;
  let startX = 0;
  let startSize = cellSize;

  const begin = (x) => {
    drag = true;
    startX = x;
    startSize = cellSize;
  };

  const move = (x) => {
    if (!drag || !latestState) return;
    cellSize = Math.max(MIN_CELL, Math.min(MAX_CELL, Math.round(startSize + (x - startX) / parseDims(latestState.boardDims).files)));
    applyBoardSize(latestState);
    if (boardApi) {
      boardApi.set({ animation: { enabled: false } }, false);
      renderState(latestState);
    }
  };

  const stop = () => {
    if (drag) scheduleFitWindow(true, 40);
    drag = false;
  };

  handle.addEventListener('mousedown', (event) => {
    event.preventDefault();
    begin(event.clientX);
  });
  document.addEventListener('mousemove', (event) => move(event.clientX));
  document.addEventListener('mouseup', stop);
})();

window.addEventListener('resize', () => {
  if (!latestState) return;
  fitBoardToViewport(latestState);
  renderState(latestState);
});

window.addEventListener('beforeunload', () => {
  if (!currentTabId) return;
  chrome.runtime.sendMessage({ type: 'STREAM_WINDOW_CLOSED', tabId: currentTabId }, () => {});
});

sideEls.tabPanelBtn.addEventListener('click', () => activateTab('panel'));
sideEls.tabPanelBtn.addEventListener('click', () => scheduleFitWindow(true, 30));
sideEls.tabSettingBtn.addEventListener('click', () => activateTab('setting'));
sideEls.tabSettingBtn.addEventListener('click', () => scheduleFitWindow(true, 30));
sideEls.fixPlayer.addEventListener('click', () => sendStreamCommand('toggle_player'));
sideEls.fixTurn.addEventListener('click', () => sendStreamCommand('toggle_turn'));
sideEls.exitStream.addEventListener('click', () => {
  if (currentTabId) {
    chrome.runtime.sendMessage({ type: 'SET_STREAM_MODE', tabId: currentTabId, enabled: false }, () => {});
  }
  window.close();
});

readStateNow().catch(() => {});
setInterval(() => readStateNow().catch(() => {}), 700);
setTimeout(() => scheduleFitWindow(true, 20), 40);
setTimeout(() => scheduleFitWindow(true, 20), 180);
