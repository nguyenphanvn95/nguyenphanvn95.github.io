/**
 * Lishogi Shogi Helper v2 — Content Script
 * - Board/SFEN/turn detection (giữ nguyên từ v1)
 * - Gửi SFEN lên background → nhận engine moves
 * - Vẽ SVG arrow overlay trên sg-board
 */
(function () {
  'use strict';

  const POLL_MS = 700;
  const STREAM_MODE_PREFIX = 'shStreamModeTab_';
  const ANALYSIS_DEBOUNCE = 800;  // ms sau khi SFEN thay đổi mới gửi lên engine

  // ── Piece → SFEN char ─────────────────────────────────────────────────────
  const PIECE_TO_SFEN = {
    'king': 'K', 'rook': 'R', 'bishop': 'B', 'gold': 'G',
    'silver': 'S', 'knight': 'N', 'lance': 'L', 'pawn': 'P',
    'dragon': '+R', 'horse': '+B',
    'promotedsilver': '+S', 'promotedknight': '+N',
    'promotedlance': '+L', 'tokin': '+P',
    'lion': 'L', 'elephant': 'E', 'giraffe': 'G', 'chick': 'C', 'hen': 'H',
  };

  function getVariantSfenChar(ptype) {
    if (state.variant === 'dobutsu') {
      if (ptype === 'king') return 'L';
      if (ptype === 'rook') return 'G';
      if (ptype === 'bishop') return 'E';
      if (ptype === 'pawn') return 'C';
      if (ptype === 'tokin') return 'H';
    }
    return PIECE_TO_SFEN[ptype] || null;
  }

  // ── State ────────────────────────────────────────────────────────────────
  let state = {
    variant: 'standard', boardDims: '9x9',
    myColor: null, myName: null, opponentName: null,
    orientation: 'sente', currentTurn: 'sente',
    moveNumber: 0, lastMove: null,
    sfen: '', lastSfen: '',
    handSente: {}, handGote: {},
    pageType: 'game',
    engineReady: false,
    analysisOn: true,
    engineMoves: [],   // [{rank, cp, mate, pv, depth}]
    analysisDepth: 15,
    multiPV: 3,
    engineType: 'yaneuraou',
    analysisState: 'idle',
    panelVisible: true,
    panelMinimized: false,
    handsCollapsed: true,
    sfenCollapsed: true,
    engineCollapsed: true,
    myColorOverride: null,
    currentTurnOverride: null,
    bestMoveHotkey: 'Space',
    autoMoveEnabled: false,
    autoMoveDelayMs: 250,
    streamMode: false,
  };

  const ENGINE_LABELS = {
    yaneuraou: 'YaneuraOu',
    stockfish: 'Fairy-Stockfish',
  };

  const ENGINE_VARIANT_FALLBACKS = {
    annanshogi: 'stockfish',
    chushogi: 'stockfish',
    checkshogi: 'stockfish',
    dobutsu: 'stockfish',
    kyotoshogi: 'stockfish',
    minishogi: 'stockfish',
  };

  const HINT_COLORS = [
    'rgba(70,160,255,0.95)',
    'rgba(235,90,90,0.92)',
    'rgba(245,205,70,0.92)',
    'rgba(120,210,150,0.9)',
    'rgba(210,135,255,0.9)',
    'rgba(255,150,90,0.9)',
  ];

  function getHintColor(index) {
    return HINT_COLORS[index] || HINT_COLORS[HINT_COLORS.length - 1];
  }

  function getHintMoveCount(engineMoves) {
    return Math.min(engineMoves.length, Math.max(1, state.multiPV || 1));
  }

  const ENGINE_LIMITS = {
    yaneuraou: {
      depth: { min: 6, max: 30, step: 1, defaultValue: 15 },
      multiPV: { min: 1, max: 6, step: 1, defaultValue: 3 },
    },
    stockfish: {
      depth: { min: 6, max: 24, step: 1, defaultValue: 15 },
      multiPV: { min: 1, max: 6, step: 1, defaultValue: 3 },
    },
  };

  function getEngineLimits(engineType) {
    return ENGINE_LIMITS[engineType] || ENGINE_LIMITS.yaneuraou;
  }

  function getCompatibleEngine(engineType, variant) {
    const fallback = ENGINE_VARIANT_FALLBACKS[variant];
    if (!fallback) return engineType;
    if (engineType === fallback) return engineType;
    return fallback;
  }

  function ensureCompatibleEngine({ persist = false, trigger = false } = {}) {
    const compatibleEngine = getCompatibleEngine(state.engineType, state.variant);
    if (compatibleEngine === state.engineType) return false;
    state.engineType = compatibleEngine;
    state.engineMoves = [];
    updateEngineControls();
    chrome.runtime.sendMessage({ type: 'SET_ENGINE', engine: state.engineType }).catch(() => {});
    if (persist) savePrefs();
    if (trigger && state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'ensure-compatible-engine');
    return true;
  }

  function clampSetting(value, config) {
    const parsed = parseInt(value, 10);
    if (Number.isNaN(parsed)) return config.defaultValue;
    return Math.max(config.min, Math.min(config.max, parsed));
  }

  function normalizeEngineSettings() {
    const limits = getEngineLimits(state.engineType);
    state.analysisDepth = clampSetting(state.analysisDepth, limits.depth);
    state.multiPV = clampSetting(state.multiPV, limits.multiPV);
  }

  function updateEngineControls() {
    const depthInput = document.getElementById('shDepth');
    const depthValue = document.getElementById('shDepthValue');
    const depthRange = document.getElementById('shDepthRange');
    const multiPVInput = document.getElementById('shMultiPV');
    const multiPVValue = document.getElementById('shMultiPVValue');
    const multiPVRange = document.getElementById('shMultiPVRange');
    if (!depthInput || !multiPVInput) return;

    normalizeEngineSettings();
    const limits = getEngineLimits(state.engineType);

    depthInput.min = String(limits.depth.min);
    depthInput.max = String(limits.depth.max);
    depthInput.step = String(limits.depth.step);
    depthInput.value = String(state.analysisDepth);
    if (depthValue) depthValue.textContent = String(state.analysisDepth);
    if (depthRange) depthRange.textContent = `${limits.depth.min}-${limits.depth.max}`;

    multiPVInput.min = String(limits.multiPV.min);
    multiPVInput.max = String(limits.multiPV.max);
    multiPVInput.step = String(limits.multiPV.step);
    multiPVInput.value = String(state.multiPV);
    if (multiPVValue) multiPVValue.textContent = String(state.multiPV);
    if (multiPVRange) multiPVRange.textContent = `${limits.multiPV.min}-${limits.multiPV.max}`;
  }

  function savePrefs() {
    chrome.storage.local.set({
      engineType: state.engineType,
      analysisDepth: state.analysisDepth,
      multiPV: state.multiPV,
      analysisOn: state.analysisOn,
      panelVisible: state.panelVisible,
      panelMinimized: state.panelMinimized,
      handsCollapsed: state.handsCollapsed,
      sfenCollapsed: state.sfenCollapsed,
      engineCollapsed: state.engineCollapsed,
      myColorOverride: state.myColorOverride,
      currentTurnOverride: state.currentTurnOverride,
      bestMoveHotkey: state.bestMoveHotkey,
      autoMoveEnabled: state.autoMoveEnabled,
      autoMoveDelayMs: state.autoMoveDelayMs,
    }).catch(() => {});
  }

  async function loadPrefs() {
    try {
      const data = await chrome.storage.local.get([
        'engineType',
        'analysisDepth',
        'multiPV',
        'analysisOn',
        'panelVisible',
        'panelMinimized',
        'handsCollapsed',
        'sfenCollapsed',
        'engineCollapsed',
        'myColorOverride',
        'currentTurnOverride',
        'bestMoveHotkey',
        'autoMoveEnabled',
        'autoMoveDelayMs',
      ]);
      if (data.engineType) state.engineType = data.engineType;
      if (data.analysisDepth) state.analysisDepth = data.analysisDepth;
      if (data.multiPV) state.multiPV = data.multiPV;
      if (typeof data.analysisOn === 'boolean') state.analysisOn = data.analysisOn;
      if (typeof data.panelVisible === 'boolean') state.panelVisible = data.panelVisible;
      if (typeof data.panelMinimized === 'boolean') state.panelMinimized = data.panelMinimized;
      if (typeof data.handsCollapsed === 'boolean') state.handsCollapsed = data.handsCollapsed;
      if (typeof data.sfenCollapsed === 'boolean') state.sfenCollapsed = data.sfenCollapsed;
      if (typeof data.engineCollapsed === 'boolean') state.engineCollapsed = data.engineCollapsed;
      if (data.myColorOverride === 'sente' || data.myColorOverride === 'gote') state.myColorOverride = data.myColorOverride;
      if (data.currentTurnOverride === 'sente' || data.currentTurnOverride === 'gote') state.currentTurnOverride = data.currentTurnOverride;
      if (['Space', 'Enter', 'KeyH', 'KeyB', 'Off'].includes(data.bestMoveHotkey)) state.bestMoveHotkey = data.bestMoveHotkey;
      if (typeof data.autoMoveEnabled === 'boolean') state.autoMoveEnabled = data.autoMoveEnabled;
      if (data.autoMoveDelayMs != null) state.autoMoveDelayMs = Math.max(0, Math.min(2000, parseInt(data.autoMoveDelayMs, 10) || 250));
    } catch (e) {}
  }

  // ── Helpers ──────────────────────────────────────────────────────────────
  let currentTabId = null;
  let streamMode = false;

  function streamModeKeyForTab(tabId) {
    return `${STREAM_MODE_PREFIX}${tabId}`;
  }

  function shouldRenderInlineHints() {
    return !streamMode && shouldShowHints();
  }

  function applyStreamMode(nextMode) {
    const value = !!nextMode;
    if (streamMode === value) return;
    streamMode = value;
    state.streamMode = value;
    if (streamMode) clearArrows();
    applyPanelVisibility();
    syncSiteHeaderToggle();
  }

  function initStreamMode() {
    chrome.runtime.sendMessage({ type: 'GET_SELF_TAB_ID' }, (response) => {
      currentTabId = Number(response?.tabId) || null;
      if (!currentTabId) return;
      const key = streamModeKeyForTab(currentTabId);
      chrome.storage.local.get([key], (result) => {
        applyStreamMode(result?.[key] === true);
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes[key]) return;
        applyStreamMode(changes[key].newValue === true);
      });
    });
  }

  function openStreamWindow() {
    if (!currentTabId) return;
    chrome.runtime.sendMessage({ type: 'SET_STREAM_MODE', tabId: currentTabId, enabled: true }, () => {});
    chrome.runtime.sendMessage({ type: 'OPEN_STREAM_WINDOW', tabId: currentTabId }, () => {});
  }

  function detectPageType() {
    const p = window.location.pathname;
    if (p.startsWith('/training') || p.startsWith('/puzzle')) return 'puzzle';
    if (p.startsWith('/tv')) return 'tv';
    if (p.includes('/analysis')) return 'analysis';
    return 'game';
  }

  function detectVariantAndDims() {
    const dv = document.querySelector('[data-variant]');
    if (dv) return dv.getAttribute('data-variant');
    const variantHref = document.querySelector('a.variant-link[href*="/variant/"]')?.getAttribute('href') || '';
    const hrefMatch = variantHref.match(/\/variant\/([a-z0-9-]+)/i);
    if (hrefMatch?.[1]) {
      const slug = hrefMatch[1].toLowerCase();
      if (slug === 'shogi') return 'standard';
      return slug;
    }
    const mainClass = Array.from(document.querySelector('main')?.classList || []).find((cls) => cls.startsWith('main-v-'));
    if (mainClass) {
      const slug = mainClass.slice('main-v-'.length).toLowerCase();
      if (slug === 'shogi') return 'standard';
      return slug;
    }
    const sgWrap = document.querySelector('.sg-wrap');
    if (sgWrap) {
      const m = sgWrap.className.match(/d-(\d+x\d+)/);
      if (m) {
        const dims = m[1];
        if (dims === '9x9') return 'standard';
        if (dims === '3x4') return 'dobutsu';
        if (dims === '5x5') {
          for (const p of sgWrap.querySelectorAll('sg-board piece')) {
            if (p.className.includes('tokin') || p.className.includes('knight')) return 'kyotoshogi';
          }
          return 'minishogi';
        }
      }
    }
    return 'standard';
  }

  function getBoardDims() {
    const sgWrap = document.querySelector('.sg-wrap');
    if (sgWrap) { const m = sgWrap.className.match(/d-(\d+x\d+)/); if (m) return m[1]; }
    return '9x9';
  }

  function getBoardOrientation() {
    const sgWrap = document.querySelector('.sg-wrap');
    if (sgWrap && sgWrap.classList.contains('orientation-gote')) return 'gote';
    return 'sente';
  }

  function isHomePage() {
    return window.location.pathname === '/';
  }

  function getBoardSquareElements() {
    return Array.from(document.querySelectorAll('sg-board sg-squares > sq'));
  }

  function parseTranslatePercent(transformText) {
    const text = String(transformText || '');
    const match = text.match(/translate\(\s*([-0-9.]+)%\s*,\s*([-0-9.]+)%\s*\)/i);
    if (!match) return null;
    return {
      xPct: parseFloat(match[1]),
      yPct: parseFloat(match[2]),
    };
  }

  function getBoardCoordLabels() {
    const board = document.querySelector('sg-board');
    if (!board) return null;

    const filesEl = board.querySelector('coords.files');
    const ranksEl = board.querySelector('coords.ranks');
    let colLabels = Array.from(board.querySelectorAll('coords.files coord'))
      .map((node) => parseInt(node.textContent?.trim() || '', 10))
      .filter((value) => Number.isFinite(value));
    let rowLabels = Array.from(board.querySelectorAll('coords.ranks coord'))
      .map((node) => parseInt(node.textContent?.trim() || '', 10))
      .filter((value) => Number.isFinite(value));

    // Lishogi uses flex direction to flip coordinate display.
    // We need visual left->right / top->bottom label order, not raw DOM order.
    if (filesEl?.classList.contains('gote')) {
      colLabels = colLabels.slice().reverse();
    }
    if (!ranksEl?.classList.contains('gote')) {
      rowLabels = rowLabels.slice().reverse();
    }

    if (!colLabels.length || !rowLabels.length) return null;
    return { colLabels, rowLabels };
  }

  function coordToSquareIndex(col, row, cols, rows, orientation) {
    const labelMap = getBoardCoordLabels();
    if (labelMap && labelMap.colLabels.length === cols && labelMap.rowLabels.length === rows) {
      const displayCol = labelMap.colLabels.indexOf(col);
      const displayRow = labelMap.rowLabels.indexOf(row);
      if (displayCol >= 0 && displayRow >= 0) {
        return displayRow * cols + displayCol;
      }
    }

    let displayCol;
    let displayRow;
    if (orientation === 'sente') {
      displayCol = cols - col;
      displayRow = row - 1;
    } else {
      displayCol = col - 1;
      displayRow = rows - row;
    }
    return displayRow * cols + displayCol;
  }

  function getBoardCellCenter(col, row, cols, rows, orientation) {
    const squares = getBoardSquareElements();
    const index = coordToSquareIndex(col, row, cols, rows, orientation);
    const square = squares[index];
    if (!square) return null;
    const rect = square.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
    };
  }

  function pointToBoardCoord(x, y, cols, rows, orientation) {
    const squares = getBoardSquareElements();
    let bestIndex = -1;
    let bestDistance = Infinity;
    for (let i = 0; i < squares.length; i++) {
      const rect = squares[i].getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = cx - x;
      const dy = cy - y;
      const distance = dx * dx + dy * dy;
      if (distance < bestDistance) {
        bestDistance = distance;
        bestIndex = i;
      }
    }
    if (bestIndex < 0) return null;

    const displayRow = Math.floor(bestIndex / cols);
    const displayCol = bestIndex % cols;
    const labelMap = getBoardCoordLabels();
    if (labelMap && labelMap.colLabels.length === cols && labelMap.rowLabels.length === rows) {
      const col = labelMap.colLabels[displayCol];
      const row = labelMap.rowLabels[displayRow];
      if (Number.isFinite(col) && Number.isFinite(row)) {
        return { col, row };
      }
    }

    if (orientation === 'sente') {
      return { col: cols - displayCol, row: displayRow + 1 };
    }
    return { col: cols - displayCol, row: rows - displayRow };
  }

  function detectMyName() {
    const ul = document.querySelector('a.user-link[href^="/"]');
    if (ul) return ul.textContent.trim();
    return null;
  }

  function detectPlayerInfo() {
    const result = { sente: null, gote: null };
    for (const el of document.querySelectorAll('.color-icon')) {
      const name = el.querySelector('.user-link, .anon, a, span.name')?.textContent?.trim();
      if (!name) continue;
      if (el.className.includes('is sente')) result.sente = name;
      else if (el.className.includes('is gote')) result.gote = name;
    }
    if (!result.sente && !result.gote) {
      const bottom = document.querySelector('.ruser-bottom .name, .ruser-bottom a.text, .ruser-bottom .anon');
      const top    = document.querySelector('.ruser-top .name, .ruser-top a.text, .ruser-top .anon');
      const orient = getBoardOrientation();
      result[orient === 'sente' ? 'sente' : 'gote'] = bottom?.textContent?.trim();
      result[orient === 'sente' ? 'gote' : 'sente'] = top?.textContent?.trim();
    }
    return result;
  }

  function getBottomPlayerName() {
    return document.querySelector('.ruser-bottom .name, .ruser-bottom .user-link, .ruser-bottom a.text, .ruser-bottom .anon')?.textContent?.trim() || null;
  }

  function getTopPlayerName() {
    return document.querySelector('.ruser-top .name, .ruser-top .user-link, .ruser-top a.text, .ruser-top .anon')?.textContent?.trim() || null;
  }

  function detectBottomBoardColor() {
    // Quy tắc đúng cho lishogi: màu ở dưới bàn phụ thuộc orientation / hand-bottom,
    // không phụ thuộc việc quân nào đang nằm thấp nhất trên bàn.
    const bottomHandPiece = document.querySelector('sg-hand-wrap.hand-bottom piece');
    if (bottomHandPiece) {
      const cls = String(bottomHandPiece.className || '').trim();
      const color = cls.split(/\s+/)[0];
      if (color === 'sente' || color === 'gote') return color;
    }

    const bottomPanel = document.querySelector('.ruser-bottom');
    if (bottomPanel) {
      const orient = getBoardOrientation();
      return orient === 'gote' ? 'gote' : 'sente';
    }

    const sgWrap = document.querySelector('.sg-wrap');
    if (sgWrap) {
      if (sgWrap.classList.contains('orientation-gote')) return 'gote';
      return 'sente';
    }

    return getBoardOrientation() === 'gote' ? 'gote' : 'sente';
  }

  function normalizePlayerName(name) {
    return (name || '').trim().toLowerCase();
  }

  function playerNamesMatch(a, b) {
    const left = normalizePlayerName(a);
    const right = normalizePlayerName(b);
    if (!left || !right) return false;
    return left === right || left.includes(right) || right.includes(left);
  }

  function getPlayerPanelCandidates() {
    const selectors = ['.ruser-top', '.ruser-bottom'];
    return selectors.map((selector) => {
      const element = document.querySelector(selector);
      const name = element?.querySelector('.name, .user-link, a.text, .anon')?.textContent?.trim();
      if (!element || !name) return null;
      return { element, name };
    }).filter(Boolean);
  }

  function detectMyNameFromLayout() {
    const board = document.querySelector('sg-board');
    if (!board) return null;

    const bottomName = getBottomPlayerName();
    if (bottomName) return bottomName;

    const boardRect = board.getBoundingClientRect();
    const candidates = getPlayerPanelCandidates();
    if (!candidates.length) return null;

    const scored = candidates.map((candidate) => {
      const rect = candidate.element.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const isBelowBoard = centerY >= boardRect.bottom - 12;
      const verticalDistance = Math.abs(rect.top - boardRect.bottom);
      const horizontalDistance = Math.abs(centerX - (boardRect.left + boardRect.width / 2));

      return {
        ...candidate,
        primaryScore: isBelowBoard ? 0 : 1,
        secondaryScore: verticalDistance,
        tertiaryScore: horizontalDistance,
      };
    });

    scored.sort((a, b) => {
      if (a.primaryScore !== b.primaryScore) return a.primaryScore - b.primaryScore;
      if (a.tertiaryScore !== b.tertiaryScore) return a.tertiaryScore - b.tertiaryScore;
      return a.secondaryScore - b.secondaryScore;
    });

    return scored[0]?.name || null;
  }

  function oppositeColor(color) {
    return color === 'gote' ? 'sente' : 'gote';
  }

  function getClockTurnSignal(bottomSide) {
    for (const cl of document.querySelectorAll('.rclock.running')) {
      if (cl.classList.contains('rclock-bottom')) {
        return {
          turn: bottomSide === 'gote' ? 'gote' : 'sente',
          source: 'clock-bottom',
        };
      }
      if (cl.classList.contains('rclock-top')) {
        return {
          turn: bottomSide === 'gote' ? 'sente' : 'gote',
          source: 'clock-top',
        };
      }
    }
    return null;
  }

  function isBottomClockRunning() {
    return !!document.querySelector('.rclock.rclock-bottom.running');
  }

  function hasClockElements() {
    return document.querySelectorAll('.rclock').length > 0;
  }

  function hasBothClockElements() {
    return document.querySelectorAll('.rclock.rclock-bottom').length > 0
      && document.querySelectorAll('.rclock.rclock-top').length > 0;
  }

  function isAnyClockRunning() {
    return !!document.querySelector('.rclock.running');
  }

  function getDisplayedMoveInfo(moves = []) {
    const activeIndex = moves.findIndex((move) => move.active);
    const displayedPly = activeIndex >= 0 ? activeIndex + 1 : moves.length;
    const displayedLastMove = displayedPly > 0 ? moves[displayedPly - 1] : null;
    return {
      activeIndex,
      displayedPly,
      displayedLastMove,
      isHistoricalView: activeIndex >= 0 && activeIndex !== moves.length - 1,
    };
  }

  function detectCurrentTurn(bottomSide, moves = [], displayedMoveInfo = null) {
    const info = displayedMoveInfo || getDisplayedMoveInfo(moves);
    const lastMove = info.displayedLastMove;
    if (lastMove?.color) {
      return oppositeColor(lastMove.color);
    }

    if (state.pageType === 'game' && !info.isHistoricalView) {
      const clockTurn = getClockTurnSignal(bottomSide);
      if (clockTurn?.turn) {
        return clockTurn.turn;
      }
    }

    return info.displayedPly % 2 === 0 ? 'sente' : 'gote';
  }

  function normalizeMoveColorByClock(move, clockTurn) {
    if (!move || !clockTurn?.turn) return move;
    const expectedLastMover = oppositeColor(clockTurn.turn);
    if (move.color === expectedLastMover) return move;
    return { ...move, color: expectedLastMover };
  }

  function parseMoveList() {
    const movesDiv = document.querySelector('.moves');
    if (!movesDiv) return [];
    const moves = [];
    let moveNum = 0;
    for (const node of movesDiv.childNodes) {
      if (node.nodeName === 'INDEX') { moveNum = parseInt(node.textContent.trim()) || moveNum; }
      else if (node.nodeName === 'M2') {
        const txt = node.textContent.trim();
        if (txt) {
          const color = moveNum > 0 && moveNum % 2 === 0 ? 'gote' : 'sente';
          moves.push({ moveNum, color, notation: txt, active: node.classList.contains('active') });
        }
      }
    }
    return moves;
  }

  function pixelToShogiCoord(xPct, yPct, cols, rows, orientation) {
    const colDisplay = Math.round(xPct / 50);
    const rowDisplay = Math.round(yPct / 50);
    let col, row;
    if (orientation === 'sente') { col = cols - colDisplay; row = rowDisplay + 1; }
    else { col = colDisplay + 1; row = rows - rowDisplay; }
    return { col, row };
  }

  const boardReadCache = {
    signature: '',
    boardData: null,
    pieceStateByEl: new WeakMap(),
    moveCandidate: null,
    coordPieceMap: Object.create(null),
  };

  function computeBoardDomSignature(sgBoard, dims, orientation) {
    const pieces = sgBoard.querySelectorAll('sg-pieces > piece');
    const parts = [dims, orientation, String(pieces.length)];
    for (const piece of pieces) {
      const cls = String(piece.className || '').trim();
      if (!cls || cls === 'ghost' || cls.includes('dragging') || !cls.includes(' ')) continue;
      parts.push(cls, piece.getAttribute('style') || '', piece.getAttribute('cgKey') || '', piece.getAttribute('data-key') || '');
    }
    return parts.join('|');
  }

  function readBoardFromDOM() {
    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return null;
    const dims = getBoardDims();
    const [cols, rows] = dims.split('x').map(Number);
    const orientation = getBoardOrientation();
    const signature = computeBoardDomSignature(sgBoard, dims, orientation);
    if (boardReadCache.signature === signature && boardReadCache.boardData) {
      return boardReadCache.boardData;
    }

    const board = {};
    const coordPieceMap = Object.create(null);
    let bestMoveCandidate = null;
    for (const piece of sgBoard.querySelectorAll('sg-pieces > piece')) {
      const cls = String(piece.className || '').trim();
      if (!cls || cls === 'ghost' || cls.includes('dragging') || !cls.includes(' ')) continue;
      const parts = cls.split(/\s+/);
      if (parts.length < 2) continue;
      const color = parts[0], ptype = parts.slice(1).join('');
      if (color !== 'sente' && color !== 'gote') continue;
      const rect = piece.getBoundingClientRect();
      const point = pointToBoardCoord(rect.left + rect.width / 2, rect.top + rect.height / 2, cols, rows, orientation);
      if (!point) continue;
      const { col, row } = point;
      if (col < 1 || col > cols || row < 1 || row > rows) continue;
      const sfenChar = getVariantSfenChar(ptype);
      if (!sfenChar) continue;
      const sfenPiece = color === 'gote'
        ? (sfenChar.startsWith('+') ? '+' + sfenChar[1].toLowerCase() : sfenChar.toLowerCase())
        : sfenChar;
      const key = `${col},${row}`;
      board[key] = sfenPiece;
      const current = {
        className: cls,
        transform: piece.style?.transform || '',
        color,
        ptype,
        col,
        row,
        area: rect.width * rect.height,
        element: piece,
      };
      coordPieceMap[key] = current;

      const prev = boardReadCache.pieceStateByEl.get(piece);
      boardReadCache.pieceStateByEl.set(piece, current);
      if (!prev) continue;
      if (prev.col === current.col && prev.row === current.row && prev.className === current.className && prev.transform === current.transform) continue;
      if (prev.col === current.col && prev.row === current.row) continue;

      const distance = Math.abs(prev.col - current.col) + Math.abs(prev.row - current.row);
      const moved = {
        color: current.color,
        fromCol: prev.col,
        fromRow: prev.row,
        toCol: current.col,
        toRow: current.row,
        notation: `${coordToUsiSquare(prev.col, prev.row)}-${coordToUsiSquare(current.col, current.row)}`,
        moveNum: null,
        distance,
        promoted: prev.className !== current.className,
      };
      if (moved.promoted) moved.notation += '+';
      if (!bestMoveCandidate || moved.distance >= bestMoveCandidate.distance) bestMoveCandidate = moved;
    }

    boardReadCache.signature = signature;
    boardReadCache.moveCandidate = bestMoveCandidate;
    boardReadCache.coordPieceMap = coordPieceMap;
    boardReadCache.boardData = { board, cols, rows, orientation };
    return boardReadCache.boardData;
  }

  function coordToUsiSquare(col, row) {
    const rank = String.fromCharCode(96 + Number(row));
    return `${col}${rank}`;
  }

  function getLastDestCoord(cols, rows, orientation) {
    const lastDestSquare = document.querySelector('sg-board sg-squares > sq.last-dest');
    if (!lastDestSquare) return null;
    const squares = getBoardSquareElements();
    const index = squares.indexOf(lastDestSquare);
    if (index < 0) return null;
    const displayRow = Math.floor(index / cols);
    const displayCol = index % cols;
    const labelMap = getBoardCoordLabels();
    if (labelMap && labelMap.colLabels.length === cols && labelMap.rowLabels.length === rows) {
      const col = labelMap.colLabels[displayCol];
      const row = labelMap.rowLabels[displayRow];
      if (Number.isFinite(col) && Number.isFinite(row)) return { col, row };
    }
    if (orientation === 'sente') {
      return { col: cols - displayCol, row: displayRow + 1 };
    }
    return { col: displayCol + 1, row: rows - displayRow };
  }

  function getPieceAtCoordFromDom(col, row, cols, rows, orientation) {
    const cached = boardReadCache.coordPieceMap?.[`${col},${row}`];
    if (cached) return cached;
    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return null;
    let best = null;
    for (const piece of sgBoard.querySelectorAll('sg-pieces > piece')) {
      const cls = String(piece.className || '').trim();
      const parts = cls.split(/\s+/);
      if (parts.length < 2) continue;
      const color = parts[0];
      if (color !== 'sente' && color !== 'gote') continue;
      const rect = piece.getBoundingClientRect();
      const point = pointToBoardCoord(rect.left + rect.width / 2, rect.top + rect.height / 2, cols, rows, orientation);
      if (!point || point.col !== col || point.row !== row) continue;
      const area = rect.width * rect.height;
      if (!best || area > best.area) {
        best = {
          color,
          ptype: parts.slice(1).join(''),
          element: piece,
          area,
        };
      }
    }
    return best;
  }

  function detectLastMoveFromLastDest(cols, rows, orientation, domMovedPiece) {
    const dest = getLastDestCoord(cols, rows, orientation);
    if (!dest) return null;
    const pieceAtDest = getPieceAtCoordFromDom(dest.col, dest.row, cols, rows, orientation);
    if (!pieceAtDest?.color) return null;

    if (domMovedPiece && domMovedPiece.toCol === dest.col && domMovedPiece.toRow === dest.row) {
      return {
        ...domMovedPiece,
        color: pieceAtDest.color,
      };
    }

    return {
      color: pieceAtDest.color,
      fromCol: null,
      fromRow: null,
      toCol: dest.col,
      toRow: dest.row,
      notation: coordToUsiSquare(dest.col, dest.row),
      moveNum: null,
      distance: 0,
      viaLastDest: true,
    };
  }

  function detectDomMovedPiece(cols, rows, orientation) {
    void cols; void rows; void orientation;
    return boardReadCache.moveCandidate || null;
  }

  const handReadCache = {
    signature: '',
    data: null,
  };

  function computeHandDomSignature() {
    const parts = [];
    for (const wrap of document.querySelectorAll('sg-hand-wrap')) {
      parts.push(wrap.className || '', wrap.getAttribute('class') || '');
      for (const hp of wrap.querySelectorAll('sg-hp-wrap')) {
        parts.push(hp.getAttribute('data-nb') || '0', hp.querySelector('piece')?.className || '');
      }
    }
    return parts.join('|');
  }

  function readHandFromDOM() {
    const signature = computeHandDomSignature();
    if (handReadCache.signature === signature && handReadCache.data) return handReadCache.data;

    const handSente = {}, handGote = {};
    for (const wrap of document.querySelectorAll('sg-hand-wrap')) {
      for (const hp of wrap.querySelectorAll('sg-hp-wrap')) {
        const nb = parseInt(hp.getAttribute('data-nb') || '0');
        if (nb === 0) continue;
        const pieceEl = hp.querySelector('piece');
        if (!pieceEl) continue;
        const parts = (pieceEl.className || '').trim().split(/\s+/);
        if (parts.length < 2) continue;
        const color = parts[0], ptype = parts[1];
        const sfenBase = (getVariantSfenChar(ptype) || '?')[0];
        if (sfenBase === '?' || sfenBase === '+') continue;
        if (color === 'sente') handSente[sfenBase] = (handSente[sfenBase] || 0) + nb;
        else if (color === 'gote') handGote[sfenBase] = (handGote[sfenBase] || 0) + nb;
      }
    }
    handReadCache.signature = signature;
    handReadCache.data = { handSente, handGote };
    return handReadCache.data;
  }

  function generateSFEN(boardData, handSente, handGote, currentTurn, moveNumber) {
    const { board, cols, rows } = boardData;
    let boardStr = '';
    for (let row = 1; row <= rows; row++) {
      let empty = 0, rowStr = '';
      for (let col = cols; col >= 1; col--) {
        const piece = board[`${col},${row}`];
        if (!piece) { empty++; }
        else { if (empty > 0) { rowStr += empty; empty = 0; } rowStr += piece; }
      }
      if (empty > 0) rowStr += empty;
      boardStr += (row > 1 ? '/' : '') + rowStr;
    }
    const turnChar = currentTurn === 'sente' ? 'b' : 'w';
    const handOrder = state.variant === 'dobutsu'
      ? ['G', 'E', 'C']
      : ['R','B','G','S','N','L','P'];
    let handStr = '';
    for (const p of handOrder) { const n = handSente[p] || 0; if (n > 0) handStr += (n > 1 ? n : '') + p; }
    for (const p of handOrder) { const n = handGote[p] || 0;  if (n > 0) handStr += (n > 1 ? n : '') + p.toLowerCase(); }
    if (!handStr) handStr = '-';
    return `${boardStr} ${turnChar} ${handStr} ${moveNumber + 1}`;
  }

  // ── Arrow Overlay ─────────────────────────────────────────────────────────
  // USI move format: "7g7f" (fromCol fromRow toCol toRow) or "B*3e" (drop)
  // Shogi col: 1-9 (right to left visually), row: a-i

  const ROW_CHAR = { a:1, b:2, c:3, d:4, e:5, f:6, g:7, h:8, i:9 };
  const analysisMoveCore = window.ShogiAnalysisMoveCore || null;

  function parseUSIMove(usi) {
    if (!usi || usi === 'resign' || usi === 'win') return null;
    // Drop: "B*3e"
    const dropM = usi.match(/^([RBGSNLPCEH])\*(\d)([a-i])$/);
    if (dropM) return { drop: dropM[1], toCol: parseInt(dropM[2]), toRow: ROW_CHAR[dropM[3]], promote: false };
    // Normal: "7g7f" or "7g7f+"
    const moveM = usi.match(/^(\d)([a-i])(\d)([a-i])\+?$/);
    if (moveM) return {
      fromCol: parseInt(moveM[1]), fromRow: ROW_CHAR[moveM[2]],
      toCol:   parseInt(moveM[3]), toRow:   ROW_CHAR[moveM[4]],
      promote: usi.endsWith('+'),
    };
    return null;
  }

  function isStandardAnalysisMoveSupported() {
    return !!analysisMoveCore && state.variant === 'standard' && state.boardDims === '9x9';
  }

  function buildCurrentStandardSfen(boardData, handData, currentTurn) {
    return generateSFEN(
      boardData,
      handData?.handSente || {},
      handData?.handGote || {},
      currentTurn,
      state.moveNumber || 0
    );
  }

  function validateUsiMoveWithAnalysisCore(usi, options = {}) {
    if (!isStandardAnalysisMoveSupported()) {
      return { ok: false, reason: 'analysis_core_unavailable', result: null };
    }

    try {
      const boardData = options.boardData || readBoardFromDOM();
      const handData = options.handData || readHandFromDOM();
      const currentTurn = options.currentTurn || getEffectiveCurrentTurn();
      if (!boardData || !handData || !currentTurn) {
        return { ok: false, reason: 'position_unavailable', result: null };
      }
      const sfen = buildCurrentStandardSfen(boardData, handData, currentTurn);
      const result = analysisMoveCore.processEngineMove({
        state: sfen,
        usi,
        options: {
          autoForcePromotion: true,
          enforceNifu: true,
        },
      });
      if (!result?.ok) {
        return {
          ok: false,
          reason: (result?.errors || []).join(' | ') || 'analysis_core_rejected_move',
          result,
        };
      }
      return { ok: true, reason: 'ok', result };
    } catch (e) {
      return { ok: false, reason: String(e?.message || e), result: null };
    }
  }

  function isMoveWithinBoard(parsed, cols, rows) {
    if (!parsed) return false;
    if (parsed.drop) {
      return parsed.toCol >= 1 && parsed.toCol <= cols && parsed.toRow >= 1 && parsed.toRow <= rows;
    }
    return parsed.fromCol >= 1 && parsed.fromCol <= cols
      && parsed.toCol >= 1 && parsed.toCol <= cols
      && parsed.fromRow >= 1 && parsed.fromRow <= rows
      && parsed.toRow >= 1 && parsed.toRow <= rows;
  }

  function getPieceColorFromSfenPiece(piece) {
    if (!piece) return null;
    const base = piece.startsWith('+') ? piece.slice(1) : piece;
    if (!base) return null;
    return base === base.toUpperCase() ? 'sente' : 'gote';
  }

  function validateUsiMoveForPosition(usi, options = {}) {
    const parsed = parseUSIMove(usi);
    if (!parsed) return { valid: false, reason: 'parse_failed', parsed: null };

    const boardData = options.boardData || readBoardFromDOM();
    if (!boardData) return { valid: false, reason: 'board_unavailable', parsed };

    const currentTurn = options.currentTurn || getEffectiveCurrentTurn();
    if (currentTurn !== 'sente' && currentTurn !== 'gote') {
      return { valid: false, reason: 'turn_unknown', parsed, boardData };
    }

    if (!isMoveWithinBoard(parsed, boardData.cols, boardData.rows)) {
      return { valid: false, reason: 'out_of_board', parsed, boardData };
    }

    const board = boardData.board || {};
    if (parsed.drop) {
      const handData = options.handData || readHandFromDOM();
      const hand = currentTurn === 'sente' ? handData.handSente : handData.handGote;
      const count = hand?.[parsed.drop] || 0;
      if (count <= 0) {
        return { valid: false, reason: 'drop_piece_missing_in_hand', parsed, boardData, handData };
      }
      if (board[`${parsed.toCol},${parsed.toRow}`]) {
        return { valid: false, reason: 'drop_destination_occupied', parsed, boardData, handData };
      }
      return { valid: true, reason: 'ok', parsed, boardData, handData, moveColor: currentTurn };
    }

    const fromPiece = board[`${parsed.fromCol},${parsed.fromRow}`];
    if (!fromPiece) {
      return { valid: false, reason: 'source_empty', parsed, boardData };
    }
    const sourceColor = getPieceColorFromSfenPiece(fromPiece);
    if (sourceColor !== currentTurn) {
      return { valid: false, reason: `source_color_${sourceColor || 'unknown'}_turn_${currentTurn}`, parsed, boardData };
    }

    const toPiece = board[`${parsed.toCol},${parsed.toRow}`];
    const destColor = getPieceColorFromSfenPiece(toPiece);
    if (destColor === currentTurn) {
      return { valid: false, reason: 'destination_has_friendly_piece', parsed, boardData };
    }

    return { valid: true, reason: 'ok', parsed, boardData, moveColor: currentTurn, fromPiece, toPiece };
  }

  function getValidatedEngineMoves(engineMoves, options = {}) {
    if (!Array.isArray(engineMoves) || engineMoves.length === 0) return [];
    const boardData = options.boardData || readBoardFromDOM();
    const handData = options.handData || readHandFromDOM();
    const currentTurn = options.currentTurn || getEffectiveCurrentTurn();
    return engineMoves.filter((move) => {
      const usi = move?.pv?.[0];
      const validation = validateUsiMoveForPosition(usi, { boardData, handData, currentTurn });
      if (!validation.valid) {
        logAction(`hint rejected: ${usi || '(none)'} | ${validation.reason}`);
      }
      return validation.valid;
    });
  }

  let autoMoveInFlight = false;
  let autoMoveTimer = null;

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function hotkeyMatches(event, hotkey) {
    if (!hotkey || hotkey === 'Off') return false;
    if (event.code === hotkey) return true;
    if (hotkey === 'Space' && (event.key === ' ' || event.key === 'Spacebar')) return true;
    if (hotkey === 'Enter' && event.key === 'Enter') return true;
    if (hotkey === 'KeyH' && (event.key === 'h' || event.key === 'H')) return true;
    if (hotkey === 'KeyB' && (event.key === 'b' || event.key === 'B')) return true;
    return false;
  }

  function logAction(msg) {
    addEngLog(`[assist] ${msg}`);
  }

  function describeEventTarget(target) {
    if (!target) return '(none)';
    const tag = String(target.tagName || target.nodeName || 'unknown').toLowerCase();
    const id = target.id ? `#${target.id}` : '';
    const cls = typeof target.className === 'string'
      ? '.' + target.className.trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.')
      : '';
    return `${tag}${id}${cls}`;
  }

  function shouldHandleHotkey(event) {
    const target = event.target;
    if (target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(target.tagName))) {
      logAction(`hotkey ignored: focus on ${describeEventTarget(target)}`);
      return false;
    }
    const matched = hotkeyMatches(event, state.bestMoveHotkey);
    if (!matched) {
      logAction(`hotkey ignored: key=${event.key || '(none)'} code=${event.code || '(none)'} expected=${state.bestMoveHotkey}`);
    }
    return matched;
  }

  function dispatchPointerSequence(target, clientX, clientY) {
    if (!target) return;
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      clientX,
      clientY,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: 'mouse',
      isPrimary: true,
      view: window,
    };
    try { target.dispatchEvent(new PointerEvent('pointerdown', init)); } catch (e) {}
    try { target.dispatchEvent(new MouseEvent('mousedown', init)); } catch (e) {}
    try { target.dispatchEvent(new PointerEvent('pointerup', { ...init, buttons: 0 })); } catch (e) {}
    try { target.dispatchEvent(new MouseEvent('mouseup', { ...init, buttons: 0 })); } catch (e) {}
    try { target.dispatchEvent(new MouseEvent('click', { ...init, buttons: 0 })); } catch (e) {}
  }

  function clickAtPoint(x, y, preferredTarget) {
    const target = preferredTarget || document.elementFromPoint(x, y) || document.querySelector('sg-board');
    if (!target) {
      logAction(`click failed: no target at (${Math.round(x)}, ${Math.round(y)})`);
      return false;
    }
    logAction(`clicking ${describeEventTarget(target)} at (${Math.round(x)}, ${Math.round(y)})`);
    dispatchPointerSequence(target, x, y);
    return true;
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve(resp || { ok: false, error: 'no_response' });
        });
      } catch (e) {
        resolve({ ok: false, error: String(e?.message || e) });
      }
    });
  }

  async function executeDebuggerClickSequence(points, opts = {}) {
    const cleanPoints = (points || []).filter((pt) => pt && Number.isFinite(pt.x) && Number.isFinite(pt.y));
    if (!cleanPoints.length) return { ok: false, error: 'no_points' };
    logAction(`debugger click sequence: ${cleanPoints.map((pt) => `(${Math.round(pt.x)},${Math.round(pt.y)})`).join(' -> ')}`);
    const result = await sendRuntimeMessage({
      type: 'SHOGI_CLICK_SEQUENCE',
      points: cleanPoints,
      delayMinMs: opts.delayMinMs ?? 70,
      delayMaxMs: opts.delayMaxMs ?? 110,
    });
    logAction(`debugger click sequence result: ${result.ok}${result.error ? ` | ${result.error}` : ''}`);
    return result;
  }

  async function executeDebuggerDragMove(fromPoint, toPoint, opts = {}) {
    if (!fromPoint || !toPoint) return { ok: false, error: 'missing_drag_points' };
    logAction(`debugger drag move: (${Math.round(fromPoint.x)},${Math.round(fromPoint.y)}) -> (${Math.round(toPoint.x)},${Math.round(toPoint.y)})`);
    const result = await sendRuntimeMessage({
      type: 'SHOGI_DRAG_MOVE',
      fromX: fromPoint.x,
      fromY: fromPoint.y,
      toX: toPoint.x,
      toY: toPoint.y,
      intermediates: Array.isArray(opts.intermediates) ? opts.intermediates : [],
    });
    logAction(`debugger drag result: ${result.ok}${result.error ? ` | ${result.error}` : ''}`);
    return result;
  }

  function getBoardPieceAt(col, row) {
    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return null;
    const dims = getBoardDims();
    const [cols, rows] = dims.split('x').map(Number);
    const orientation = getBoardOrientation();
    for (const piece of sgBoard.querySelectorAll('sg-pieces > piece')) {
      const rect = piece.getBoundingClientRect();
      const point = pointToBoardCoord(rect.left + rect.width / 2, rect.top + rect.height / 2, cols, rows, orientation);
      if (point && point.col === col && point.row === row) return piece;
    }
    return null;
  }

  function getBoardSquareElementAt(col, row, cols, rows, orientation) {
    const squares = getBoardSquareElements();
    const index = coordToSquareIndex(col, row, cols, rows, orientation);
    return index >= 0 ? squares[index] || null : null;
  }

  function dispatchPointerLike(target, type, init) {
    try { target.dispatchEvent(new PointerEvent(type, init)); } catch (e) {}
    const mouseTypeMap = {
      pointerdown: 'mousedown',
      pointermove: 'mousemove',
      pointerup: 'mouseup',
    };
    const mouseType = mouseTypeMap[type];
    if (mouseType) {
      try { target.dispatchEvent(new MouseEvent(mouseType, init)); } catch (e) {}
    }
  }

  async function dragAtPoints(fromPoint, toPoint, opts = {}) {
    if (!fromPoint || !toPoint) return false;
    const sgBoard = document.querySelector('sg-board');
    const startTarget = opts.startTarget || document.elementFromPoint(fromPoint.x, fromPoint.y) || sgBoard;
    const endTarget = opts.endTarget || document.elementFromPoint(toPoint.x, toPoint.y) || sgBoard;
    if (!startTarget || !endTarget) return false;

    const base = {
      bubbles: true,
      cancelable: true,
      composed: true,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: 'mouse',
      isPrimary: true,
      view: window,
    };

    dispatchPointerLike(startTarget, 'pointerdown', { ...base, clientX: fromPoint.x, clientY: fromPoint.y });
    await sleep(24);

    const steps = opts.steps || 8;
    for (let i = 1; i <= steps; i++) {
      const x = fromPoint.x + (toPoint.x - fromPoint.x) * (i / steps);
      const y = fromPoint.y + (toPoint.y - fromPoint.y) * (i / steps);
      const moveTarget = document.elementFromPoint(x, y) || sgBoard || endTarget;
      dispatchPointerLike(moveTarget, 'pointermove', { ...base, clientX: x, clientY: y });
      await sleep(12);
    }

    dispatchPointerLike(endTarget, 'pointerup', { ...base, buttons: 0, clientX: toPoint.x, clientY: toPoint.y });
    try {
      endTarget.dispatchEvent(new MouseEvent('click', {
        ...base,
        buttons: 0,
        clientX: toPoint.x,
        clientY: toPoint.y,
      }));
    } catch (e) {}
    return true;
  }

  async function clickSequenceAtTargets(steps, delayMs = 70) {
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      if (!step || !Number.isFinite(step.x) || !Number.isFinite(step.y)) return false;
      const ok = clickAtPoint(step.x, step.y, step.target);
      if (!ok) return false;
      if (i < steps.length - 1) await sleep(delayMs);
    }
    return true;
  }

  async function choosePromotion(promote) {
    const point = getPromotionChoicePoint(promote);
    if (!point) return false;
    return clickAtPoint(point.x, point.y, point.target);
  }

  function getPromotionChoicePoint(promote) {
    const promotionEl = document.querySelector('sg-promotion');
    if (!promotionEl || promotionEl.style.display === 'none') return null;
    const options = Array.from(promotionEl.querySelectorAll('piece'));
    if (options.length < 2) return null;
    let target = null;
    if (promote) {
      target = options.find((pieceEl) => {
        const classes = String(pieceEl.className || '').split(/\s+/);
        return classes.some((cls) => Object.values(PROMOTES_TO_CLASS).includes(cls));
      }) || options[0];
    } else {
      target = options.find((pieceEl) => {
        const classes = String(pieceEl.className || '').split(/\s+/);
        return !classes.some((cls) => Object.values(PROMOTES_TO_CLASS).includes(cls));
      }) || options[options.length - 1];
    }
    const rect = target.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
      target,
    };
  }

  async function waitForSfenChange(beforeSfen, timeout = 2200) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (state.sfen && state.sfen !== beforeSfen) {
        logAction(`board changed after ${Date.now() - start}ms: ${beforeSfen || '(none)'} -> ${state.sfen}`);
        return true;
      }
      await sleep(60);
    }
    logAction(`board did not change within ${timeout}ms; current sfen=${state.sfen || '(none)'}`);
    return false;
  }

  async function handlePromotionChoice(parsed, opts = {}) {
    const promotionEl = document.querySelector('sg-promotion');
    if (!promotionEl || promotionEl.style.display === 'none') return { ok: true, skipped: true };

    logAction(`promotion chooser visible: promote=${!!parsed.promote} via ${opts.preferDebugger ? 'debugger' : 'dom'}`);
    const promotionPoint = getPromotionChoicePoint(!!parsed.promote);
    if (!promotionPoint) {
      return { ok: false, error: 'promotion_target_missing' };
    }

    if (!opts.preferDebugger) {
      const domOk = clickAtPoint(promotionPoint.x, promotionPoint.y, promotionPoint.target);
      if (domOk) {
        await sleep(120);
        return { ok: true, mode: 'dom' };
      }
    }

    const debuggerResult = await executeDebuggerClickSequence([promotionPoint], { delayMinMs: 40, delayMaxMs: 60 });
    return { ok: !!debuggerResult.ok, mode: 'debugger', error: debuggerResult.error || null };
  }

  async function executeBestMoveViaDebugger(parsed, boardData) {
    const cols = boardData.cols;
    const rows = boardData.rows;
    const orientation = boardData.orientation;

    if (parsed.drop) {
      const anchor = findHandPieceAnchor(getEffectiveCurrentTurn(), parsed.drop);
      if (!anchor) {
        return { ok: false, error: `no hand piece anchor for drop ${parsed.drop}` };
      }
      const anchorRect = anchor.getBoundingClientRect();
      const anchorPoint = {
        x: anchorRect.left + anchorRect.width / 2,
        y: anchorRect.top + anchorRect.height / 2,
      };
      const destPoint = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orientation);
      if (!destPoint) {
        return { ok: false, error: `no destination point for drop ${parsed.toCol}${parsed.toRow}` };
      }
      logAction(`debugger fallback drop: ${parsed.drop} -> ${parsed.toCol}${parsed.toRow}`);
      const dropResult = await executeDebuggerClickSequence([anchorPoint, destPoint], { delayMinMs: 90, delayMaxMs: 140 });
      if (!dropResult.ok) {
        return { ok: false, error: dropResult.error || 'debugger_drop_failed' };
      }
      await sleep(120);
      return { ok: true, mode: 'debugger-click' };
    }

    const sourcePiece = getBoardPieceAt(parsed.fromCol, parsed.fromRow);
    const sourcePoint = getBoardCellCenter(parsed.fromCol, parsed.fromRow, cols, rows, orientation);
    if (!sourcePoint) {
      return { ok: false, error: `no source point for ${parsed.fromCol}${parsed.fromRow}` };
    }
    const destPoint = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orientation);
    if (!destPoint) {
      return { ok: false, error: `no destination point for ${parsed.toCol}${parsed.toRow}` };
    }
    logAction(`debugger fallback board move from ${parsed.fromCol}${parsed.fromRow} to ${parsed.toCol}${parsed.toRow} via ${describeEventTarget(sourcePiece)}`);
    const dragResult = await executeDebuggerDragMove(sourcePoint, destPoint);
    if (!dragResult.ok) {
      logAction(`debugger drag fallback failed; trying debugger click sequence | ${dragResult.error || 'unknown_error'}`);
      const clickResult = await executeDebuggerClickSequence([sourcePoint, destPoint], { delayMinMs: 80, delayMaxMs: 120 });
      if (!clickResult.ok) {
        return { ok: false, error: clickResult.error || 'debugger_click_fallback_failed' };
      }
      await sleep(120);
      return { ok: true, mode: 'debugger-click' };
    }

    await sleep(120);
    return { ok: true, mode: 'debugger-drag' };
  }

  async function executeBestMoveViaAnalysisDom(usi, parsed, boardData, handData) {
    const coreValidation = validateUsiMoveWithAnalysisCore(usi, {
      boardData,
      handData,
      currentTurn: getEffectiveCurrentTurn(),
    });
    if (!coreValidation.ok) {
      return { ok: false, error: coreValidation.reason, mode: 'analysis-core' };
    }

    const cols = boardData.cols;
    const rows = boardData.rows;
    const orientation = boardData.orientation;

    if (parsed.drop) {
      const anchor = findHandPieceAnchor(getEffectiveCurrentTurn(), parsed.drop);
      const destPoint = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orientation);
      const destSquare = getBoardSquareElementAt(parsed.toCol, parsed.toRow, cols, rows, orientation);
      if (!anchor || !destPoint || !destSquare) {
        return { ok: false, error: 'drop_dom_targets_missing', mode: 'analysis-dom' };
      }

      const anchorRect = anchor.getBoundingClientRect();
      const anchorPoint = {
        x: anchorRect.left + anchorRect.width / 2,
        y: anchorRect.top + anchorRect.height / 2,
      };

      logAction(`analysis-style drop attempt: ${parsed.drop} -> ${parsed.toCol}${parsed.toRow}`);
      const clicked = await clickSequenceAtTargets([
        { ...anchorPoint, target: anchor },
        { ...destPoint, target: destSquare },
      ], 85);
      if (!clicked) {
        return { ok: false, error: 'drop_dom_click_failed', mode: 'analysis-dom' };
      }
      await sleep(120);
      return { ok: true, mode: 'analysis-dom-click' };
    }

    const sourcePiece = getBoardPieceAt(parsed.fromCol, parsed.fromRow);
    const sourceSquare = getBoardSquareElementAt(parsed.fromCol, parsed.fromRow, cols, rows, orientation);
    const destSquare = getBoardSquareElementAt(parsed.toCol, parsed.toRow, cols, rows, orientation);
    const sourcePoint = getBoardCellCenter(parsed.fromCol, parsed.fromRow, cols, rows, orientation);
    const destPoint = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orientation);

    if (!sourcePoint || !destPoint || !destSquare) {
      return { ok: false, error: 'move_dom_targets_missing', mode: 'analysis-dom' };
    }

    logAction(`analysis-style board move attempt: ${parsed.fromCol}${parsed.fromRow} -> ${parsed.toCol}${parsed.toRow}`);
    const clicked = await clickSequenceAtTargets([
      { ...sourcePoint, target: sourcePiece || sourceSquare },
      { ...destPoint, target: destSquare },
    ], 80);
    if (clicked) {
      await sleep(120);
      return { ok: true, mode: 'analysis-dom-click' };
    }

    const dragged = await dragAtPoints(sourcePoint, destPoint, {
      startTarget: sourcePiece || sourceSquare,
      endTarget: destSquare,
    });
    if (!dragged) {
      return { ok: false, error: 'move_dom_drag_failed', mode: 'analysis-dom' };
    }

    await sleep(120);
    return { ok: true, mode: 'analysis-dom-drag' };
  }

  // Convert shogi col/row → display pixel percent
  // orientation=sente: col 9 → 0%, col 1 → 400% (for 9x9, step 50%)
  // orientation=gote:  col 1 → 0%, col 9 → 400%
  function shogiToDisplay(col, row, cols, rows, orientation) {
    const stepX = 100 / (cols - 1);  // 50 for 9x9, 50 for 5x5
    const stepY = 100 / (rows - 1);
    let dispCol, dispRow;
    if (orientation === 'sente') {
      dispCol = (cols - col) * stepX;
      dispRow = (row - 1) * stepY;
    } else {
      dispCol = (col - 1) * stepX;
      dispRow = (rows - row) * stepY;
    }
    return { x: dispCol, y: dispRow };  // in %
  }

  // ── SVG overlay injected into sg-board ────────────────────────────────────
  let arrowSvg = null;
  let handHintLayer = null;

  const DROP_PIECE_TO_CLASS = {
    R: 'rook',
    B: 'bishop',
    G: 'gold',
    S: 'silver',
    N: 'knight',
    L: 'lance',
    P: 'pawn',
    E: 'elephant',
    C: 'chick',
    H: 'hen',
  };

  function getDropPieceClass(pieceLetter) {
    if (state.variant === 'dobutsu') {
      if (pieceLetter === 'G') return 'rook';
      if (pieceLetter === 'E') return 'bishop';
      if (pieceLetter === 'C') return 'pawn';
      if (pieceLetter === 'H') return 'tokin';
      if (pieceLetter === 'L') return 'king';
    }
    return DROP_PIECE_TO_CLASS[pieceLetter] || null;
  }

  const PROMOTES_TO_CLASS = {
    pawn: 'tokin',
    lance: 'promotedlance',
    knight: 'promotedknight',
    silver: 'promotedsilver',
    bishop: 'horse',
    rook: 'dragon',
    chick: 'hen',
  };

  function ensureArrowSvg() {
    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return null;
    if (arrowSvg && sgBoard.contains(arrowSvg)) return arrowSvg;
    // Remove old
    const old = sgBoard.querySelector('.sh-arrows-svg');
    if (old) old.remove();
    // Create SVG with pixel coordinates — NO viewBox/preserveAspectRatio distortion
    arrowSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    arrowSvg.setAttribute('class', 'sh-arrows-svg');
    arrowSvg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1000;overflow:visible;';
    // Marker size in pixels (will be referenced by markerUnits=strokeWidth default)
    arrowSvg.innerHTML = `<defs>
      <marker id="sh-arr-1" markerWidth="2.5" markerHeight="2.5" refX="2.15" refY="1.25" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L0,2.5 L2.5,1.25 z" fill="rgba(255,200,0,0.95)"/>
      </marker>
      <marker id="sh-arr-2" markerWidth="2.5" markerHeight="2.5" refX="2.15" refY="1.25" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L0,2.5 L2.5,1.25 z" fill="rgba(100,200,255,0.85)"/>
      </marker>
      <marker id="sh-arr-3" markerWidth="2.5" markerHeight="2.5" refX="2.15" refY="1.25" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L0,2.5 L2.5,1.25 z" fill="rgba(100,200,255,0.65)"/>
      </marker>
    </defs><g class="sh-arrow-group"></g>`;
    sgBoard.appendChild(arrowSvg);
    return arrowSvg;
  }

  function clearArrows() {
    const svg = document.querySelector('.sh-arrows-svg');
    if (svg) { const g = svg.querySelector('.sh-arrow-group'); if (g) g.innerHTML = ''; }
    clearHandHints();
  }

  function ensureHandHintLayer() {
    if (handHintLayer && document.body.contains(handHintLayer)) return handHintLayer;
    handHintLayer = document.createElement('div');
    handHintLayer.className = 'sh-hand-hint-layer';
    document.body.appendChild(handHintLayer);
    return handHintLayer;
  }

  function clearHandHints() {
    const layer = handHintLayer || document.querySelector('.sh-hand-hint-layer');
    if (layer) layer.innerHTML = '';
  }

  function createRingMarker({ left, top, size, background, opacity = 1, className = 'sh-hand-hint' }) {
    const marker = document.createElement('div');
    marker.className = className;
    marker.style.width = `${size}px`;
    marker.style.height = `${size}px`;
    marker.style.left = `${left}px`;
    marker.style.top = `${top}px`;
    marker.style.background = background;
    marker.style.opacity = String(opacity);

    const hole = document.createElement('div');
    hole.className = 'sh-hand-hint-hole';
    marker.appendChild(hole);
    return marker;
  }

  function buildHintGradient(colors) {
    if (!colors || colors.length === 0) return HINT_COLORS[0];
    if (colors.length === 1) return colors[0];
    const step = 100 / colors.length;
    return `conic-gradient(${colors.map((color, index) => {
      const start = (index * step).toFixed(4);
      const end = ((index + 1) * step).toFixed(4);
      return `${color} ${start}% ${end}%`;
    }).join(', ')})`;
  }

  function findHandPieceAnchor(color, pieceLetter) {
    const pieceClass = getDropPieceClass(pieceLetter);
    if (!pieceClass) return null;
    const selector = `sg-hand-wrap sg-hp-wrap piece.${color}.${pieceClass}`;
    const pieceEl = Array.from(document.querySelectorAll(selector)).find((node) => {
      const wrap = node.closest('sg-hp-wrap');
      return wrap && parseInt(wrap.getAttribute('data-nb') || '0', 10) > 0;
    });
    return pieceEl ? pieceEl.closest('sg-hp-wrap') || pieceEl : null;
  }

  function drawHandHints(engineMoves) {
    const validMoves = getValidatedEngineMoves(engineMoves);
    if (!validMoves.length) return;
    const layer = ensureHandHintLayer();
    if (!layer) return;
    layer.innerHTML = '';
    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return;

    const boardRect = sgBoard.getBoundingClientRect();
    const dims = getBoardDims();
    const [cols, rows] = dims.split('x').map(Number);
    const orient = getBoardOrientation();
    const stepX = boardRect.width / cols;
    const stepY = boardRect.height / rows;
    const dropColor = getEffectiveCurrentTurn() === 'gote' ? 'gote' : 'sente';

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'sh-hand-arrow-svg');
    svg.setAttribute('width', String(window.innerWidth));
    svg.setAttribute('height', String(window.innerHeight));
    svg.setAttribute('viewBox', `0 0 ${window.innerWidth} ${window.innerHeight}`);
    svg.style.cssText = 'position:fixed;inset:0;overflow:visible;pointer-events:none;';

    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const hintCount = Math.min(1, getHintMoveCount(validMoves));
    defs.innerHTML = Array.from({ length: hintCount }, (_, i) => `
      <marker id="sh-hand-arr-${i + 1}" markerWidth="3.6" markerHeight="3.6" refX="2.9" refY="1.8" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L0,3.6 L3.6,1.8 z" fill="${getHintColor(i)}"/>
      </marker>
    `).join('');
    svg.appendChild(defs);

    for (let i = 0; i < hintCount; i++) {
      const move = validMoves[i];
      const usi = move?.pv?.[0];
      const parsed = parseUSIMove(usi);
      if (!parsed?.drop) continue;

      const anchor = findHandPieceAnchor(dropColor, parsed.drop);
      if (!anchor) continue;

      const anchorRect = anchor.getBoundingClientRect();
      const from = {
        x: anchorRect.left + anchorRect.width / 2,
        y: anchorRect.top + anchorRect.height / 2,
      };
      const to = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orient);
      if (!to) continue;
      const dx = to.x - from.x;
      const dy = to.y - from.y;
      const len = Math.sqrt(dx * dx + dy * dy);
      if (len < 1) continue;
      const shrink = Math.min(stepX * 0.23, len * 0.15) / len;
      const x2 = to.x - dx * shrink;
      const y2 = to.y - dy * shrink;

      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', String(from.x));
      line.setAttribute('y1', String(from.y));
      line.setAttribute('x2', String(x2));
      line.setAttribute('y2', String(y2));
      line.setAttribute('stroke', getHintColor(i));
      line.setAttribute('stroke-width', String(Math.max(1.2, stepX * (0.055 - Math.min(i, 5) * 0.0045))));
      line.setAttribute('stroke-linecap', 'round');
      line.setAttribute('marker-end', `url(#sh-hand-arr-${i + 1})`);
      svg.appendChild(line);

      const target = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      target.setAttribute('cx', String(to.x));
      target.setAttribute('cy', String(to.y));
      target.setAttribute('r', String(Math.max(4, stepX * 0.1)));
      target.setAttribute('fill', getHintColor(i));
      target.setAttribute('opacity', i === 0 ? '0.9' : '0.78');
      svg.appendChild(target);
    }

    layer.appendChild(svg);
  }

  function drawPromotionHints(engineMoves) {
    const validMoves = getValidatedEngineMoves(engineMoves);
    if (!validMoves.length) return;
    const layer = ensureHandHintLayer();
    if (!layer) return;
    const promotionEl = document.querySelector('sg-promotion');
    if (!promotionEl || promotionEl.style.display === 'none') return;

    const optionPieces = Array.from(promotionEl.querySelectorAll('piece'));
    if (optionPieces.length < 2) return;

    for (let i = 0; i < Math.min(1, getHintMoveCount(validMoves)); i++) {
      const move = validMoves[i];
      const usi = move?.pv?.[0];
      if (!usi) continue;
      const parsed = parseUSIMove(usi);
      if (!parsed || parsed.drop || !parsed.promote) continue;

      const targetPiece = optionPieces.find((pieceEl) => {
        const classes = (pieceEl.className || '').split(/\s+/);
        return classes.some((cls) => Object.values(PROMOTES_TO_CLASS).includes(cls));
      });
      if (!targetPiece) continue;

      const rect = targetPiece.getBoundingClientRect();
      const size = Math.max(26, Math.min(rect.width, rect.height) * 0.9);
      const marker = createRingMarker({
        left: rect.left + rect.width / 2 - size / 2,
        top: rect.top + rect.height / 2 - size / 2,
        size,
        background: getHintColor(i),
        opacity: 0.5,
        className: 'sh-choice-hint',
      });
      layer.appendChild(marker);
    }
  }

  function drawArrows(engineMoves) {
    const validMoves = getValidatedEngineMoves(engineMoves);
    const svg = ensureArrowSvg();
    if (!svg) return;
    const g = svg.querySelector('.sh-arrow-group');
    if (!g) return;
    g.innerHTML = '';
    // Hand/promotion hints live on a separate layer, so clear them before rendering a new hint set.
    clearHandHints();
    if (!validMoves.length) return;

    const sgBoard = document.querySelector('sg-board');
    if (!sgBoard) return;
    const rect = sgBoard.getBoundingClientRect();
    const boardW = rect.width;
    const boardH = rect.height;

    const dims = getBoardDims();
    const [cols, rows] = dims.split('x').map(Number);
    const orient = getBoardOrientation();
    const stepX = boardW / cols;   // cell width in px
    const stepY = boardH / rows;   // cell height in px

    const hintCount = Math.min(1, getHintMoveCount(validMoves));
    const ARROW_STYLES = Array.from({ length: hintCount }, (_, i) => ({
      stroke: getHintColor(i),
      fill: getHintColor(i),
      marker: `url(#sh-arr-${i + 1})`,
      width: Math.max(1.25, stepX * (0.058 - Math.min(i, 5) * 0.0045)),
    }));
    const defs = svg.querySelector('defs');
    if (defs) {
      defs.innerHTML = ARROW_STYLES.map((style, i) => `
        <marker id="sh-arr-${i + 1}" markerWidth="2.5" markerHeight="2.5" refX="2.15" refY="1.25" orient="auto" markerUnits="strokeWidth">
          <path d="M0,0 L0,2.5 L2.5,1.25 z" fill="${style.fill}"/>
        </marker>
      `).join('');
    }

    for (let i = 0; i < hintCount; i++) {
      const m = validMoves[i];
      if (!m.pv || m.pv.length === 0) continue;
      const firstMove = m.pv[0];
      const parsed = parseUSIMove(firstMove);
      if (!parsed) continue;

      const style = ARROW_STYLES[i] || ARROW_STYLES[ARROW_STYLES.length - 1];

      if (parsed.drop) {
        continue;
      } else {
        // Normal move: draw arrow from→to
        const fromPoint = getBoardCellCenter(parsed.fromCol, parsed.fromRow, cols, rows, orient);
        const toPoint = getBoardCellCenter(parsed.toCol, parsed.toRow, cols, rows, orient);
        if (!fromPoint || !toPoint) continue;
        const from = { x: fromPoint.x - rect.left, y: fromPoint.y - rect.top };
        const to = { x: toPoint.x - rect.left, y: toPoint.y - rect.top };

        // Shorten arrow slightly so head doesn't overlap piece
        const dx = to.x - from.x, dy = to.y - from.y;
        const len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1) continue;
        const shrink = Math.min(stepX * 0.23, len * 0.17) / len;
        const x2 = to.x - dx * shrink;
        const y2 = to.y - dy * shrink;

        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', from.x);
        line.setAttribute('y1', from.y);
        line.setAttribute('x2', x2);
        line.setAttribute('y2', y2);
        line.setAttribute('stroke', style.stroke);
        line.setAttribute('stroke-width', style.width);
        line.setAttribute('stroke-linecap', 'round');
        line.setAttribute('marker-end', style.marker);
        g.appendChild(line);

        const target = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        target.setAttribute('cx', to.x);
        target.setAttribute('cy', to.y);
        target.setAttribute('r', Math.max(4, stepX * 0.11));
        target.setAttribute('fill', style.fill);
        target.setAttribute('opacity', i === 0 ? '0.95' : '0.82');
        g.appendChild(target);

        // Eval label on first move only
        if (i === 0) {
          const evalTxt = m.mate != null
            ? (m.mate > 0 ? `M${m.mate}` : `M-${Math.abs(m.mate)}`)
            : (m.cp != null ? (m.cp > 0 ? `+${m.cp}` : `${m.cp}`) : '');
          if (evalTxt) {
            const mid = { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 };
            const fs = Math.max(10, stepX * 0.28);
            const pad = fs * 0.5;
            const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            bg.setAttribute('x', mid.x - fs); bg.setAttribute('y', mid.y - fs * 0.7);
            bg.setAttribute('width', fs * 2); bg.setAttribute('height', fs * 1.3);
            bg.setAttribute('rx', 3); bg.setAttribute('fill', 'rgba(0,0,0,0.7)');
            g.appendChild(bg);
            const txt = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            txt.setAttribute('x', mid.x); txt.setAttribute('y', mid.y + fs * 0.4);
            txt.setAttribute('text-anchor', 'middle');
            txt.setAttribute('font-size', fs);
            txt.setAttribute('font-family', 'monospace');
            txt.setAttribute('font-weight', 'bold');
            txt.setAttribute('fill', ARROW_STYLES[0].fill);
            txt.textContent = evalTxt;
            g.appendChild(txt);
          }
        }
      }
    }

    drawHandHints(engineMoves);
    drawPromotionHints(engineMoves);
  }

  // ── Engine Panel UI ───────────────────────────────────────────────────────
  let overlayEl = null;
  let evalBarWrapEl = null;
  let evalBarFillEl = null;
  let evalBarLabelEl = null;

  function variantLabel(v, dims) {
    const m = { standard:'9×9 Standard', minishogi:'5×5 Minishogi', kyotoshogi:'5×5 Kyotoshogi', dobutsu:'3×4 Dobutsu', annanshogi:'9×9 Annanshogi', checkshogi:'9×9 Checkshogi', chushogi:'12×12 Chushogi' };
    return m[v] || `${dims} ${v}`;
  }

  function colorLabel(c) {
    if (c === 'sente') return '▲ Sente'; if (c === 'gote') return '△ Gote'; return '–';
  }

  function handToString(hand) {
    const order = ['R','B','G','S','N','L','P'];
    return order.filter(p => hand[p] > 0).map(p => `${p}×${hand[p]}`).join(' ') || '–';
  }

  function formatEval(m) {
    if (m.mate != null) return m.mate > 0 ? `#${m.mate}` : `#-${Math.abs(m.mate)}`;
    if (m.cp != null) return (m.cp > 0 ? '+' : '') + m.cp;
    return '?';
  }

  function clampEvalBar(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function normalizeEvalBarScore(score) {
    if (!score || (score.cp == null && score.mate == null)) {
      return { cp: 0, mate: null, pov: 'sente' };
    }
    return {
      cp: typeof score.cp === 'number' ? score.cp : null,
      mate: typeof score.mate === 'number' ? score.mate : null,
      pov: score.pov === 'gote' ? 'gote' : 'sente',
    };
  }

  function getEvalBarWinningChances(score) {
    const normalized = normalizeEvalBarScore(score);
    let chances = 0;
    if (typeof normalized.mate === 'number') {
      if (normalized.mate === 0) chances = 0;
      else chances = normalized.mate > 0 ? 1 : -1;
    } else {
      const cp = clampEvalBar(Number(normalized.cp) || 0, -1000, 1000);
      chances = 2 / (1 + Math.exp(-0.00368208 * cp)) - 1;
    }
    return normalized.pov === 'gote' ? -chances : chances;
  }

  function getEvalBarGoteHeight(score) {
    const chances = getEvalBarWinningChances(score);
    return clampEvalBar(100 - (chances + 1) * 50, 0, 100);
  }

  function formatEvalBarLabel(score, fallbackText) {
    if (fallbackText) return fallbackText;
    const normalized = normalizeEvalBarScore(score);
    if (typeof normalized.mate === 'number') {
      if (normalized.mate === 0) return '#0';
      return normalized.mate > 0 ? `#${normalized.mate}` : `#-${Math.abs(normalized.mate)}`;
    }
    const pawns = (Number(normalized.cp) || 0) / 100;
    return pawns > 0 ? `+${pawns.toFixed(1)}` : pawns.toFixed(1);
  }

  function ensureEvalBar() {
    if (!overlayEl) return null;
    if (evalBarWrapEl && overlayEl.contains(evalBarWrapEl)) return evalBarWrapEl;

    evalBarWrapEl = document.createElement('div');
    evalBarWrapEl.className = 'sh-evalbar-wrap';
    evalBarWrapEl.innerHTML = `
      <div class="sh-evalbar">
        <div class="sh-evalbar__gote"></div>
        <div class="sh-evalbar__tick" style="top:12.5%"></div>
        <div class="sh-evalbar__tick" style="top:25%"></div>
        <div class="sh-evalbar__tick" style="top:37.5%"></div>
        <div class="sh-evalbar__tick zero" style="top:50%"></div>
        <div class="sh-evalbar__tick" style="top:62.5%"></div>
        <div class="sh-evalbar__tick" style="top:75%"></div>
        <div class="sh-evalbar__tick" style="top:87.5%"></div>
      </div>
      <div class="sh-evalbar__label">0.0</div>
    `;
    overlayEl.appendChild(evalBarWrapEl);
    evalBarFillEl = evalBarWrapEl.querySelector('.sh-evalbar__gote');
    evalBarLabelEl = evalBarWrapEl.querySelector('.sh-evalbar__label');
    return evalBarWrapEl;
  }

  function syncEvalBarState(status = state.analysisState) {
    const wrap = ensureEvalBar();
    if (!wrap || !evalBarFillEl || !evalBarLabelEl) return;

    const shouldShow = !!overlayEl && state.panelVisible && !streamMode;
    wrap.style.display = shouldShow ? '' : 'none';
    if (!shouldShow) return;

    wrap.classList.toggle('reverse', getBoardOrientation() === 'gote');
    wrap.classList.toggle('minimized', !!state.panelMinimized);

    let score = null;
    let fallbackText = '';
    if (!state.analysisOn) {
      fallbackText = 'off';
    } else if (Array.isArray(state.engineMoves) && state.engineMoves.length > 0) {
      const topMove = state.engineMoves[0] || {};
      score = {
        cp: typeof topMove.cp === 'number' ? topMove.cp : 0,
        mate: typeof topMove.mate === 'number' ? topMove.mate : null,
        pov: getEffectiveCurrentTurn() === 'gote' ? 'gote' : 'sente',
      };
    } else if (status === 'loading') {
      fallbackText = '...';
    } else if (status === 'error') {
      fallbackText = 'err';
    }

    evalBarFillEl.style.height = `${getEvalBarGoteHeight(score)}%`;
    evalBarLabelEl.textContent = formatEvalBarLabel(score, fallbackText);
  }

  function displayColorLabel(c) {
    if (c === 'sente') return 'Sente';
    if (c === 'gote') return 'Gote';
    return '-';
  }

  function formatHandDisplay(hand) {
    const order = ['R','B','G','S','N','L','P'];
    return order.filter((p) => hand[p] > 0).map((p) => `${p}x${hand[p]}`).join(' ') || '-';
  }

  function getEffectiveMyColor() {
    return state.myColorOverride || state.myColor;
  }

  function getEffectiveCurrentTurn() {
    return state.currentTurnOverride || state.currentTurn;
  }

  function toggleColorValue(value) {
    return value === 'gote' ? 'sente' : 'gote';
  }

  function applyManualFix(type) {
    if (type === 'side') {
      state.myColorOverride = toggleColorValue(getEffectiveMyColor() || 'sente');
      savePrefs();
      updateOverlay();
      broadcastState();
      return;
    }
    if (type === 'turn') {
      state.currentTurnOverride = toggleColorValue(getEffectiveCurrentTurn() || 'sente');
      savePrefs();
      lastSfenCache = '';
      runScan();
    }
  }

  function shouldShowHints() {
    const playerSide = getEffectiveMyColor();
    const currentTurn = getEffectiveCurrentTurn();
    return !!playerSide && !!currentTurn && playerSide === currentTurn;
  }

  function shouldRequestHintAnalysis() {
    return !!state.analysisOn;
    if (!state.analysisOn) return false;
    const hintsVisible = shouldShowHints();
    if (!hintsVisible) return false;

    if (!hasClockElements()) return true;

    if (isBottomClockRunning()) return true;

    // Một số ván trên mobile có đồng hồ nhưng cả hai bên chưa "running"
    // trước nước đầu tiên. Khi đó vẫn cho engine tính nếu side === turn.
    if (hasBothClockElements() && !isAnyClockRunning()) {
      return true;
    }

    return false;
  }

  function requestHintAnalysisIfAllowed(sfen, reason = 'unknown') {
    if (!sfen) return false;
    const clockState = `hasClock=${hasClockElements()} bothClocks=${hasBothClockElements()} anyClockRunning=${isAnyClockRunning()} bottomClockRunning=${isBottomClockRunning()}`;
    if (!shouldRequestHintAnalysis()) {
      logAction(`analysis blocked (${reason}): ${clockState} turn=${state.currentTurn} side=${state.myColor}`);
      clearTimeout(analysisPending);
      state.analysisState = 'idle';
      updateEvalLines([], 'idle');
      clearArrows();
      return false;
    }
    logAction(`analysis allowed (${reason}): ${clockState} turn=${state.currentTurn} side=${state.myColor}`);
    triggerAnalysis(sfen);
    return true;
  }

  async function playBestMove(force = false) {
    logAction(`playBestMove start: force=${force} auto=${state.autoMoveEnabled} moves=${state.engineMoves.length} turn=${state.currentTurn} side=${state.myColor}`);
    if (!state.engineMoves.length) {
      logAction('playBestMove aborted: no engine moves available');
      return false;
    }
    if (!force && !state.autoMoveEnabled) {
      logAction('playBestMove aborted: auto move disabled and force=false');
      return false;
    }
    if (!shouldShowHints()) {
      logAction(`playBestMove aborted: hints hidden for side=${state.myColor} turn=${state.currentTurn}`);
      return false;
    }

    const boardData = readBoardFromDOM();
    const handData = readHandFromDOM();
    const validMoves = getValidatedEngineMoves(state.engineMoves, {
      boardData,
      handData,
      currentTurn: getEffectiveCurrentTurn(),
    });
    if (!validMoves.length) {
      logAction('playBestMove aborted: no valid engine move for current position');
      clearArrows();
      if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'invalid-bestmove');
      return false;
    }

    const usi = validMoves[0]?.pv?.[0];
    const validation = validateUsiMoveForPosition(usi, {
      boardData,
      handData,
      currentTurn: getEffectiveCurrentTurn(),
    });
    const parsed = validation.parsed;
    if (!validation.valid || !parsed) {
      logAction(`playBestMove aborted: invalid PV move ${usi || '(none)'} | ${validation.reason}`);
      return false;
    }
    logAction(`playBestMove parsed move: ${usi} -> ${JSON.stringify(parsed)}`);

    const beforeSfen = state.sfen;
    let execution = null;
    if (isStandardAnalysisMoveSupported()) {
      execution = await executeBestMoveViaAnalysisDom(usi, parsed, boardData, handData);
      logAction(`analysis-style execution result: ${execution.ok}${execution.error ? ` | ${execution.error}` : ''}${execution.mode ? ` | mode=${execution.mode}` : ''}`);
    } else {
      logAction(`analysis-style execution skipped: variant=${state.variant} dims=${state.boardDims} core=${!!analysisMoveCore}`);
    }

    const promotionAfterDom = document.querySelector('sg-promotion');
    if (execution?.ok && promotionAfterDom && promotionAfterDom.style.display !== 'none') {
      const promotionResult = await handlePromotionChoice(parsed, { preferDebugger: false });
      logAction(`promotion choice after analysis-style move: ${promotionResult.ok}${promotionResult.error ? ` | ${promotionResult.error}` : ''}`);
      if (!promotionResult.ok) execution = { ok: false, error: promotionResult.error || 'promotion_choice_failed', mode: execution.mode };
    }

    let changed = execution?.ok ? await waitForSfenChange(beforeSfen, 900) : false;
    if (!changed) {
      if (execution?.ok) {
        logAction('analysis-style execution did not change SFEN; falling back to debugger');
      } else {
        logAction(`analysis-style execution unavailable/failed; falling back to debugger${execution?.error ? ` | ${execution.error}` : ''}`);
      }

      const debuggerResult = await executeBestMoveViaDebugger(parsed, boardData);
      if (!debuggerResult.ok) {
        logAction(`playBestMove aborted: debugger fallback failed | ${debuggerResult.error || 'unknown_error'}`);
        return false;
      }

      const promotionResult = await handlePromotionChoice(parsed, { preferDebugger: true });
      logAction(`promotion choice after debugger fallback: ${promotionResult.ok}${promotionResult.error ? ` | ${promotionResult.error}` : ''}`);
      if (!promotionResult.ok) return false;

      changed = await waitForSfenChange(beforeSfen);
    }

    logAction(`playBestMove finished: changed=${changed}`);
    return changed;
  }

  function scheduleAutoMove() {
    clearTimeout(autoMoveTimer);
    logAction(`autoMove schedule check: enabled=${state.autoMoveEnabled} delay=${state.autoMoveDelayMs} moves=${state.engineMoves.length} showHints=${shouldShowHints()} inFlight=${autoMoveInFlight}`);
    if (!state.autoMoveEnabled) {
      logAction('autoMove skipped: disabled');
      return;
    }
    if (!state.engineMoves.length) {
      logAction('autoMove skipped: no engine moves available');
      return;
    }
    if (!shouldShowHints()) {
      logAction(`autoMove skipped: not player turn or hints hidden (side=${state.myColor}, turn=${state.currentTurn})`);
      return;
    }
    autoMoveTimer = setTimeout(() => {
      logAction(`autoMove timer fired after ${state.autoMoveDelayMs || 0}ms`);
      if (autoMoveInFlight) {
        logAction('autoMove skipped: another move execution is already in flight');
        return;
      }
      autoMoveInFlight = true;
      logAction('autoMove executing best move');
      playBestMove(true)
        .then((ok) => logAction(`autoMove execution result: ${ok}`))
        .catch((err) => logAction(`autoMove execution error: ${err?.message || err}`))
        .finally(() => {
          autoMoveInFlight = false;
          logAction('autoMove execution finished');
        });
    }, state.autoMoveDelayMs || 0);
    logAction(`autoMove timer scheduled: ${state.autoMoveDelayMs || 0}ms`);
  }

  function updatePanelButtons() {
    const hideBtn = document.getElementById('shHidePanel');
    const toggleBtn = document.getElementById('shToggle');
    const handsBtn = document.getElementById('shHandsToggle');
    const sfenBtn = document.getElementById('shSfenToggle');
    const engineSectionBtn = document.getElementById('shEngineToggle');
    if (hideBtn) hideBtn.title = state.panelVisible ? 'Hide panel' : 'Show panel';
    if (toggleBtn) {
      toggleBtn.textContent = state.panelMinimized ? '+' : '–';
      toggleBtn.title = state.panelMinimized ? 'Expand panel' : 'Minimize panel';
    }
    if (handsBtn) {
      handsBtn.textContent = state.handsCollapsed ? '▸' : '▾';
      handsBtn.title = state.handsCollapsed ? 'Show hand pieces' : 'Hide hand pieces';
    }
    if (sfenBtn) {
      sfenBtn.textContent = state.sfenCollapsed ? '▸' : '▾';
      sfenBtn.title = state.sfenCollapsed ? 'Show SFEN' : 'Hide SFEN';
    }
  }

  function applyPanelVisibility() {
    if (!overlayEl) return;
    overlayEl.style.display = state.panelVisible && !streamMode ? '' : 'none';
    syncEvalBarState();
    syncSiteHeaderToggle();
  }

  function applyPanelMinimized() {
    const body = document.getElementById('shBody');
    if (body) body.style.display = state.panelMinimized ? 'none' : '';
    syncEvalBarState();
    updatePanelButtons();
    const toggleBtn = document.getElementById('shToggle');
    if (toggleBtn) toggleBtn.textContent = state.panelMinimized ? '+' : '-';
  }

  function applySectionVisibility() {
    const handsBody = document.getElementById('shHandsBody');
    const sfenBody = document.getElementById('shSfenBody');
    const engineBody = document.getElementById('shEngineBody');
    if (handsBody) handsBody.style.display = state.handsCollapsed ? 'none' : '';
    if (sfenBody) sfenBody.style.display = state.sfenCollapsed ? 'none' : '';
    if (engineBody) engineBody.style.display = state.engineCollapsed ? 'none' : '';
    updatePanelButtons();
    const handsBtn = document.getElementById('shHandsToggle');
    const sfenBtn = document.getElementById('shSfenToggle');
    const engineSectionBtn = document.getElementById('shEngineToggle');
    if (handsBtn) handsBtn.textContent = state.handsCollapsed ? '>' : 'v';
    if (sfenBtn) sfenBtn.textContent = state.sfenCollapsed ? '>' : 'v';
    if (engineSectionBtn) engineSectionBtn.textContent = state.engineCollapsed ? '>' : 'v';
  }

  function syncPanelUi() {
    applyPanelVisibility();
    applyPanelMinimized();
    applySectionVisibility();
  }

  function syncSiteHeaderToggle() {
    const button = document.getElementById('shSitePanelToggle');
    if (!button) return;
    button.classList.toggle('active', !!state.panelVisible);
    button.setAttribute('aria-label', state.panelVisible ? 'Hide Shogi Helper panel' : 'Show Shogi Helper panel');
    button.title = state.panelVisible ? 'Hide Shogi Helper panel' : 'Show Shogi Helper panel';
    button.style.display = streamMode ? 'none' : '';
  }

  function ensureSiteHeaderToggle() {
    const siteButtons = document.querySelector('header#top .site-buttons');
    const searchRoot = siteButtons?.querySelector('#clinput');
    if (!siteButtons || !searchRoot) return;

    let button = document.getElementById('shSitePanelToggle');
    if (!button) {
      button = document.createElement('a');
      button.id = 'shSitePanelToggle';
      button.className = 'link sh-site-toggle';
      button.href = '#';
      button.setAttribute('role', 'button');
      button.setAttribute('aria-label', 'Toggle Shogi Helper panel');
      button.innerHTML = `<img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Shogi Helper">`;
      button.addEventListener('click', (event) => {
        event.preventDefault();
        setPanelVisible(!state.panelVisible);
      });
    }

    if (button.parentElement !== siteButtons || button.nextElementSibling !== searchRoot) {
      siteButtons.insertBefore(button, searchRoot);
    }

    syncSiteHeaderToggle();
  }

  function updateAnalysisButton() {
    const btn = document.getElementById('shToggleEng');
    if (!btn) return;
    if (state.autoMoveEnabled) {
      btn.textContent = 'Auto Move On';
      btn.style.color = '#7dff8a';
    } else {
      btn.textContent = 'Auto Move Off';
      btn.style.color = '#ffb060';
    }
  }

  function createOverlay() {
    if (overlayEl) return;
    overlayEl = document.createElement('div');
    overlayEl.id = 'shogi-helper';
    overlayEl.innerHTML = `
      <div class="sh-header">
        <span class="sh-title">♟ Shogi Helper</span>
        <span class="sh-badge" id="shVariant">–</span>
        <button class="sh-toggle" id="shToggle">–</button>
      </div>
      <div class="sh-body" id="shBody">
        <div class="sh-row"><span class="sh-label">Bạn:</span><span class="sh-val" id="shPlayer">–</span></div>
        <div class="sh-row"><span class="sh-label">Lượt:</span><span class="sh-val" id="shTurn">–</span></div>
        <div class="sh-row"><span class="sh-label">Nước #:</span><span class="sh-val" id="shMove">–</span></div>
        <div class="sh-row"><span class="sh-label">Nước cuối:</span><span class="sh-val" id="shLast">–</span></div>
        <div class="sh-section">Tay (Komadai)</div>
        <div class="sh-hand-wrap">
          <div class="sh-hand-block"><div class="sh-hand-title">▲ Sente</div><div class="sh-hand-pieces" id="shHandSente">–</div></div>
          <div class="sh-hand-block"><div class="sh-hand-title">△ Gote</div><div class="sh-hand-pieces" id="shHandGote">–</div></div>
        </div>
        <div class="sh-section">SFEN Position</div>
        <textarea id="shSfen" class="sh-sfen" readonly rows="3"></textarea>
        <div class="sh-section">
          <span>Engine Analysis</span>
          <span id="shEngStatus" style="float:right;font-size:9px;color:#806040;">●</span>
        </div>
        <div class="sh-engine-ctrl">
          <label class="sh-ctrl-row">
            <span class="sh-label">Engine:</span>
            <select id="shEngine" class="sh-num-input">
              <option value="yaneuraou">YaneuraOu</option>
              <option value="stockfish">Fairy-Stockfish</option>
            </select>
          </label>
          <label class="sh-ctrl-row">
            <span class="sh-label">Depth:</span>
            <div class="sh-slider-wrap">
              <div class="sh-slider-meta">
                <span id="shDepthValue">${state.analysisDepth}</span>
                <span id="shDepthRange"></span>
              </div>
              <input id="shDepth" type="range" min="6" max="30" step="1" value="${state.analysisDepth}" class="sh-range-input">
            </div>
          </label>
          <label class="sh-ctrl-row">
            <span class="sh-label">PV Line:</span>
            <div class="sh-slider-wrap">
              <div class="sh-slider-meta">
                <span id="shMultiPVValue">${state.multiPV}</span>
                <span id="shMultiPVRange"></span>
              </div>
              <input id="shMultiPV" type="range" min="1" max="5" step="1" value="${state.multiPV}" class="sh-range-input">
            </div>
          </label>
          <label class="sh-ctrl-row">
            <span class="sh-label">Arrows:</span>
            <input id="shArrows" type="checkbox" checked class="sh-checkbox">
          </label>
        </div>
        <div id="shEvalLines" class="sh-eval-lines"></div>
        <div class="sh-section">Lịch sử</div>
        <div class="sh-actions">
          <button id="shToggleEng" style="color:#ffb060">Auto Move Off</button>
          <button id="shCopy">📋 Copy SFEN</button>
          <button id="shClearLog">🗑 Clear</button>
          <button id="shDumpEng">🔧 Debug</button>
        </div>
        <div class="sh-section" id="shEngLogSection" style="display:none">Engine Log <span style="float:right;cursor:pointer;color:#f08060" id="shEngLogClose">✕</span></div>
        <div id="shEngLog" class="sh-log" style="display:none;max-height:120px;font-size:9px;color:#aaa;"></div>
      </div>
    `;
    document.body.appendChild(overlayEl);
    ensureEvalBar();
    const header = overlayEl.querySelector('.sh-header');
    const title = overlayEl.querySelector('.sh-title');
    const toggleBtn = document.getElementById('shToggle');
    if (title) {
      title.innerHTML = `<img class="sh-brand-icon" src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Shogi Helper">`;
    }
    if (header && toggleBtn && !document.getElementById('shHidePanel')) {
      const streamBtn = document.createElement('button');
      streamBtn.className = 'sh-toggle';
      streamBtn.id = 'shOpenStream';
      streamBtn.title = 'Open stream mode';
      streamBtn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16v10H4z M9 20h6 M12 16v4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      header.insertBefore(streamBtn, toggleBtn);

      const hideBtn = document.createElement('button');
      hideBtn.className = 'sh-toggle';
      hideBtn.id = 'shHidePanel';
      hideBtn.title = 'Hide panel';
      hideBtn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v10H4z M8 7v10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      header.insertBefore(hideBtn, toggleBtn);
    }

    const bodyEl = document.getElementById('shBody');
    const sectionEls = Array.from(bodyEl.querySelectorAll(':scope > .sh-section'));
    const handSection = sectionEls.find((node) => node.textContent.includes('Hand'));
    const sfenSection = sectionEls.find((node) => node.textContent.includes('SFEN'));
    const handWrap = overlayEl.querySelector('.sh-hand-wrap');
    const sfenBox = document.getElementById('shSfen');

    if (handSection && handWrap && !document.getElementById('shHandsBody')) {
      handSection.classList.add('sh-section-toggle');
      handSection.innerHTML = '<span>Tay (Komadai)</span><button class="sh-section-btn" id="shHandsToggle">â–¸</button>';
      const handBody = document.createElement('div');
      handBody.id = 'shHandsBody';
      handWrap.parentNode.insertBefore(handBody, handWrap);
      handBody.appendChild(handWrap);
    }

    if (sfenSection && sfenBox && !document.getElementById('shSfenBody')) {
      sfenSection.classList.add('sh-section-toggle');
      sfenSection.innerHTML = '<span>SFEN Position</span><button class="sh-section-btn" id="shSfenToggle">â–¸</button>';
      const sfenBody = document.createElement('div');
      sfenBody.id = 'shSfenBody';
      sfenBox.parentNode.insertBefore(sfenBody, sfenBox);
      sfenBody.appendChild(sfenBox);
    }
    const engineSection = Array.from(bodyEl.querySelectorAll(':scope > .sh-section')).find((node) => node.textContent.includes('Engine'));
    const engineControls = overlayEl.querySelector('.sh-engine-ctrl');
    const evalLines = document.getElementById('shEvalLines');
    if (engineSection && engineControls && evalLines && !document.getElementById('shEngineBody')) {
      engineSection.classList.add('sh-section-toggle');
      engineSection.innerHTML = '<span>Engine Analysis</span><button class="sh-section-btn" id="shEngineToggle">></button>';
      const statusEl = document.getElementById('shEngStatus');
      if (statusEl) engineSection.insertBefore(statusEl, engineSection.querySelector('#shEngineToggle'));
      const engineBody = document.createElement('div');
      engineBody.id = 'shEngineBody';
      engineControls.parentNode.insertBefore(engineBody, engineControls);
      engineBody.appendChild(engineControls);
      engineBody.appendChild(evalLines);
    }

    const rowLabels = overlayEl.querySelectorAll('.sh-row .sh-label');
    if (rowLabels[0]) rowLabels[0].textContent = 'Side:';
    if (rowLabels[1]) rowLabels[1].textContent = 'Turn:';
    if (rowLabels[2]) rowLabels[2].textContent = 'Move #:';
    if (rowLabels[3]) rowLabels[3].textContent = 'Last Move:';

    const handTitles = overlayEl.querySelectorAll('.sh-hand-title');
    if (handTitles[0]) handTitles[0].textContent = 'Sente';
    if (handTitles[1]) handTitles[1].textContent = 'Gote';

    const playerRow = document.getElementById('shPlayer')?.closest('.sh-row');
    const turnRow = document.getElementById('shTurn')?.closest('.sh-row');
    if (playerRow && !document.getElementById('shFixSide')) {
      const btn = document.createElement('button');
      btn.className = 'sh-inline-fix';
      btn.id = 'shFixSide';
      btn.type = 'button';
      btn.textContent = 'Fix';
      playerRow.appendChild(btn);
    }
    if (turnRow && !document.getElementById('shFixTurn')) {
      const btn = document.createElement('button');
      btn.className = 'sh-inline-fix';
      btn.id = 'shFixTurn';
      btn.type = 'button';
      btn.textContent = 'Fix';
      turnRow.appendChild(btn);
    }

    const sectionNodes = Array.from(bodyEl.querySelectorAll(':scope > .sh-section'));
    if (sectionNodes[0]) sectionNodes[0].childNodes[0].textContent = 'Hand Pieces';
    const actionsEl = overlayEl.querySelector('.sh-actions');
    const historySection = actionsEl?.previousElementSibling;
    if (historySection?.classList.contains('sh-section')) historySection.style.display = 'none';

    const actionTexts = { shToggleEng: 'Auto Move Off', shCopy: 'Copy SFEN', shClearLog: 'Clear Debug', shDumpEng: 'Debug' };
    Object.entries(actionTexts).forEach(([id, text]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    });

    updateAnalysisButton();
    syncPanelUi();
    syncEvalBarState();

    document.getElementById('shToggle').addEventListener('click', () => {
      const body = document.getElementById('shBody');
      const btn  = document.getElementById('shToggle');
      const hidden = body.style.display === 'none';
      body.style.display = hidden ? '' : 'none';
      btn.textContent = hidden ? '–' : '+';
    });

    document.getElementById('shCopy').addEventListener('click', () => {
      const sfen = document.getElementById('shSfen').value;
      if (sfen) navigator.clipboard.writeText(sfen).then(() => flash('shCopy', '✅ Đã copy!'));
    });

    document.getElementById('shClearLog').addEventListener('click', () => {
      const engLog = document.getElementById('shEngLog');
      if (engLog) engLog.innerHTML = '';
    });

    document.getElementById('shDumpEng').addEventListener('click', () => {
      const section = document.getElementById('shEngLogSection');
      const logEl = document.getElementById('shEngLog');
      section.style.display = '';
      logEl.style.display = '';
      // Query background for engine state
      chrome.runtime.sendMessage({ type: 'ENGINE_LOG_DUMP' }, (resp) => {
        if (chrome.runtime.lastError || !resp) {
          addEngLog('❌ Cannot reach SW: ' + (chrome.runtime.lastError?.message || 'no response'));
          return;
        }
        addEngLog('engineReady: ' + resp.engineReady);
        addEngLog('engineLoading: ' + resp.engineLoading);
        addEngLog('selectedEngine: ' + (resp.selectedEngine || state.engineType));
        addEngLog('lastEngineError: ' + (resp.lastEngineError || '(none)'));
        addEngLog('pendingTabId: ' + resp.pendingTabId);
        addEngLog('bestDepthSeen: ' + resp.bestDepthSeen);
        addEngLog('pvBufferDepths: [' + (resp.pvBufferDepths || []).join(', ') + ']');
        addEngLog('currentSfen: ' + (resp.currentSfen || '(none)'));
        addEngLog('currentVariant: ' + (resp.currentVariant || '(none)'));
        if (resp.lastAnalyzeRequest) addEngLog('lastAnalyzeRequest: ' + JSON.stringify(resp.lastAnalyzeRequest));
        if (Array.isArray(resp.lastEngineLines) && resp.lastEngineLines.length) {
          resp.lastEngineLines.slice(-8).forEach((line) => addEngLog('host> ' + line));
        }
        addEngLog('content analysisOn: ' + state.analysisOn);
        addEngLog('content engineMoves: ' + state.engineMoves.length);
        addEngLog('content sfen: ' + (state.sfen ? state.sfen.substring(0,40) : '(none)'));
      });
    });

    document.getElementById('shEngLogClose').addEventListener('click', () => {
      document.getElementById('shEngLogSection').style.display = 'none';
      document.getElementById('shEngLog').style.display = 'none';
    });

    document.getElementById('shToggleEng').addEventListener('click', toggleAutoMove);
    document.getElementById('shEngine').value = state.engineType;
    updateEngineControls();
    document.getElementById('shEngine').addEventListener('change', (e) => {
      state.engineType = e.target.value || 'yaneuraou';
      state.analysisState = 'loading';
      state.engineMoves = [];
      updateEngineControls();
      savePrefs();
      chrome.runtime.sendMessage({ type: 'SET_ENGINE', engine: state.engineType }).catch(() => {});
      updateEvalLines([], 'loading');
      if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'engine-change');
    });

    document.getElementById('shDepth').addEventListener('input', (e) => {
      state.analysisDepth = clampSetting(e.target.value, getEngineLimits(state.engineType).depth);
      updateEngineControls();
      savePrefs();
      if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'depth-change');
    });

    document.getElementById('shMultiPV').addEventListener('input', (e) => {
      state.multiPV = clampSetting(e.target.value, getEngineLimits(state.engineType).multiPV);
      updateEngineControls();
      savePrefs();
      if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'multipv-change');
    });

    document.getElementById('shArrows').addEventListener('change', (e) => {
      if (!e.target.checked) clearArrows();
      else if (shouldRenderInlineHints() && state.engineMoves.length) drawArrows(state.engineMoves);
    });

    const oldToggleBtn = document.getElementById('shToggle');
    if (oldToggleBtn) {
      const freshToggleBtn = oldToggleBtn.cloneNode(true);
      oldToggleBtn.replaceWith(freshToggleBtn);
      freshToggleBtn.addEventListener('click', () => {
        setPanelMinimized(!state.panelMinimized);
      });
    }

    document.getElementById('shOpenStream')?.addEventListener('click', () => {
      openStreamWindow();
    });

    document.getElementById('shHidePanel')?.addEventListener('click', () => {
      setPanelVisible(false);
    });

    document.getElementById('shHandsToggle')?.addEventListener('click', () => {
      setSectionCollapsed('hands', !state.handsCollapsed);
    });

    document.getElementById('shSfenToggle')?.addEventListener('click', () => {
      setSectionCollapsed('sfen', !state.sfenCollapsed);
    });

    document.getElementById('shEngineToggle')?.addEventListener('click', () => {
      setSectionCollapsed('engine', !state.engineCollapsed);
    });

    document.getElementById('shFixSide')?.addEventListener('click', () => {
      applyManualFix('side');
    });

    document.getElementById('shFixTurn')?.addEventListener('click', () => {
      applyManualFix('turn');
    });

    syncPanelUi();
    updateAnalysisButton();
    syncEvalBarState();

    makeDraggable(overlayEl);
  }

  function setAnalysisEnabled(enabled, options = {}) {
    const { persist = true, trigger = true } = options;
    state.analysisOn = !!enabled;
    state.analysisState = state.analysisOn ? 'loading' : 'idle';
    clearTimeout(autoMoveTimer);
    updateAnalysisButton();
    if (persist) savePrefs();
    if (state.analysisOn) {
      if (trigger && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'set-analysis-enabled');
    } else {
      clearTimeout(analysisPending);
      chrome.runtime.sendMessage({ type: 'STOP_ANALYSIS' }).catch(() => {});
      state.engineMoves = [];
      clearArrows();
      const evalEl = document.getElementById('shEvalLines');
      if (evalEl) evalEl.innerHTML = '';
    }
    updateEvalLines(state.engineMoves, state.analysisState);
    syncEvalBarState(state.analysisState);
    updateAnalysisButton();
  }

  function setPanelVisible(visible, persist = true) {
    state.panelVisible = !!visible;
    applyPanelVisibility();
    if (persist) savePrefs();
  }

  function setPanelMinimized(minimized, persist = true) {
    state.panelMinimized = !!minimized;
    applyPanelMinimized();
    if (persist) savePrefs();
  }

  function setSectionCollapsed(sectionKey, collapsed, persist = true) {
    if (sectionKey === 'hands') state.handsCollapsed = !!collapsed;
    if (sectionKey === 'sfen') state.sfenCollapsed = !!collapsed;
    if (sectionKey === 'engine') state.engineCollapsed = !!collapsed;
    applySectionVisibility();
    if (persist) savePrefs();
  }

  function toggleAutoMove() {
    state.autoMoveEnabled = !state.autoMoveEnabled;
    clearTimeout(autoMoveTimer);
    updateAnalysisButton();
    savePrefs();
    if (state.autoMoveEnabled) {
      logAction('panel autoMove enabled');
      scheduleAutoMove();
    } else {
      logAction('panel autoMove disabled');
    }
    return state.autoMoveEnabled;
    state.analysisOn = !state.analysisOn;
    const btn = document.getElementById('shToggleEng');
    if (state.analysisOn) {
      btn.textContent = '⏹ Dừng Engine';
      btn.style.color = '#ff8060';
      state.analysisState = 'loading';
      savePrefs();
      if (state.sfen) triggerAnalysis(state.sfen);
    } else {
      btn.textContent = '▶ Bật Engine';
      btn.style.color = '';
      state.analysisState = 'idle';
      savePrefs();
      chrome.runtime.sendMessage({ type: 'STOP_ANALYSIS' });
      clearArrows();
      document.getElementById('shEvalLines').innerHTML = '';
    }
  }

  let analysisPending = null;
  let analysisWatchdog = null;
  function triggerAnalysis(sfen) {
    clearTimeout(analysisPending);
    clearTimeout(autoMoveTimer);
    clearTimeout(analysisWatchdog);
    state.analysisState = state.engineReady ? 'analyzing' : 'loading';
    state.engineMoves = [];
    updateEvalLines([], state.analysisState);
    analysisPending = setTimeout(() => {
      console.log('[SH-CONTENT] Sending ANALYZE — variant:', state.variant, 'depth:', state.analysisDepth, 'sfen:', sfen.substring(0,40));
      chrome.runtime.sendMessage({
        type: 'ANALYZE',
        sfen,
        variant: state.variant,
        depth: state.analysisDepth,
        multiPV: state.multiPV,
        engine: state.engineType,
      }).catch((e) => {
        console.error('[SH-CONTENT] ANALYZE sendMessage failed:', e);
        state.analysisState = 'error';
        updateEvalLines([], 'error');
      });
      analysisWatchdog = setTimeout(() => {
        if (state.analysisState === 'loading' || state.analysisState === 'analyzing') {
          logAction('analysis watchdog fired: no result received in time');
          state.analysisState = 'error';
          updateEvalLines([], 'error');
          clearArrows();
        }
      }, 7000);
    }, ANALYSIS_DEBOUNCE);
  }

  function updateEngineStatus() {
    const el = document.getElementById('shEngStatus');
    if (!el) return;
    chrome.runtime.sendMessage({ type: 'ENGINE_READY_CHECK' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        el.textContent = '● offline'; el.style.color = '#f06060';
        console.warn('[SH-CONTENT] ENGINE_READY_CHECK: offline/no response');
        return;
      }
      const wasReady = state.engineReady;
      state.engineReady = resp.ready;
      if (resp.engine) state.engineType = resp.engine;
      if (resp.loading) {
        state.analysisState = 'loading';
        el.textContent = '● loading…'; el.style.color = '#f0c060';
        if (state.analysisOn && state.engineMoves.length === 0) updateEvalLines([], 'loading');
      } else if (resp.ready) {
        el.textContent = '● ready'; el.style.color = '#60cc60';
        // Engine just became ready — trigger analysis if we haven't got results yet
        if (!wasReady && state.analysisOn && state.sfen && state.engineMoves.length === 0) {
          console.log('[SH-CONTENT] Engine just became ready — triggering analysis');
          requestHintAnalysisIfAllowed(state.sfen, 'engine-ready-poll');
        }
      } else {
        el.textContent = '● –'; el.style.color = '#806040';
      }
    });
  }

  function updateEvalLines(moves, status) {
    const el = document.getElementById('shEvalLines');
    if (!el) return;
    if (!state.analysisOn) {
      el.innerHTML = '<div class="sh-eval-empty">Engine off</div>';
      syncEvalBarState(status);
      return;
    }
    if (!moves || moves.length === 0) {
      if (status === 'loading') {
        el.innerHTML = `<div class="sh-eval-empty">Loading ${ENGINE_LABELS[state.engineType] || 'engine'}...</div>`;
      } else if (status === 'error') {
        el.innerHTML = `<div class="sh-eval-empty" style="color:#f08080">Error: ${ENGINE_LABELS[state.engineType] || 'engine'} unavailable</div>`;
      } else {
        el.innerHTML = `<div class="sh-eval-empty">Analyzing with ${ENGINE_LABELS[state.engineType] || 'engine'}... (d${state.analysisDepth})</div>`;
      }
      syncEvalBarState(status);
      return;
    }
    if (!state.analysisOn) {
      el.innerHTML = '<div class="sh-eval-empty">Engine tắt — bấm "Bật Engine"</div>';
      return;
    }
    if (!moves || moves.length === 0) {
      if (status === 'loading') {
        el.innerHTML = '<div class="sh-eval-empty">⏳ Đang tải engine…</div>';
      } else if (status === 'error') {
        el.innerHTML = '<div class="sh-eval-empty" style="color:#f08080">❌ Lỗi engine — xem Console SW</div>';
      } else {
        el.innerHTML = '<div class="sh-eval-empty">🔍 Đang phân tích… (d' + state.analysisDepth + ')</div>';
      }
      return;
    }
    el.innerHTML = moves.slice(0, state.multiPV).map((m, i) => {
      const evalStr = formatEval(m);
      const firstMove = m.pv?.[0] || '?';
      const pv2 = m.pv?.slice(0, 5).join(' ') || '';
      const rankColor = getHintColor(i);
      return `<div class="sh-eval-line">
        <span class="sh-eval-rank" style="color:${rankColor}">#${i+1}</span>
        <span class="sh-eval-score" style="color:${rankColor}">${evalStr}</span>
        <span class="sh-eval-move">${firstMove}</span>
        <span class="sh-eval-pv">${pv2}</span>
        <span class="sh-eval-depth">d${m.depth||'?'}</span>
      </div>`;
    }).join('');
    syncEvalBarState(status);
  }

  function updateOverlay() {
    if (!overlayEl) return;
    const effectiveMyColor = getEffectiveMyColor();
    const effectiveCurrentTurn = getEffectiveCurrentTurn();
    const isMyTurn = state.myColor && state.currentTurn === state.myColor;
    document.getElementById('shVariant').textContent = variantLabel(state.variant, state.boardDims);
    document.getElementById('shPlayer').textContent = state.myColor ? `${colorLabel(state.myColor)} (${state.myName || '?'})` : (state.myName || '–');
    const turnEl = document.getElementById('shTurn');
    turnEl.textContent = colorLabel(state.currentTurn) + (isMyTurn ? ' ← LƯỢT BẠN' : '');
    turnEl.className = 'sh-val' + (isMyTurn ? ' myturn' : '');
    document.getElementById('shMove').textContent = state.moveNumber;
    document.getElementById('shLast').textContent = state.lastMove ? `${state.lastMove.color === 'sente' ? '▲' : '△'} ${state.lastMove.notation}` : '–';
    document.getElementById('shHandSente').textContent = handToString(state.handSente);
    document.getElementById('shHandGote').textContent  = handToString(state.handGote);
    const fixedIsMyTurn = effectiveMyColor && effectiveCurrentTurn === effectiveMyColor;
    document.getElementById('shPlayer').textContent = effectiveMyColor ? `${displayColorLabel(effectiveMyColor)} (${state.myName || '?'})` : (state.myName || '-');
    turnEl.textContent = displayColorLabel(effectiveCurrentTurn) + (fixedIsMyTurn ? ' <- YOUR TURN' : '');
    turnEl.className = 'sh-val' + (fixedIsMyTurn ? ' myturn' : '');
    document.getElementById('shLast').textContent = state.lastMove ? `${displayColorLabel(state.lastMove.color)} ${state.lastMove.notation}` : '-';
    document.getElementById('shHandSente').textContent = formatHandDisplay(state.handSente);
    document.getElementById('shHandGote').textContent  = formatHandDisplay(state.handGote);
    document.getElementById('shSfen').value = state.sfen;
    const engineSelect = document.getElementById('shEngine');
    if (engineSelect && engineSelect.value !== state.engineType) engineSelect.value = state.engineType;
    updateEngineControls();
    syncPanelUi();
    updateAnalysisButton();
    updateAnalysisButton();
    syncEvalBarState();
    if (state.sfen && state.sfen !== state.lastSfen && state.moveNumber > 0) {
      if (state.lastMove) addLog(`#${state.moveNumber} ${state.lastMove.color === 'sente' ? '▲' : '△'} ${state.lastMove.notation}`);
      state.lastSfen = state.sfen;
    }
    updateEvalLines(state.engineMoves);
    const showArrows = document.getElementById('shArrows')?.checked !== false;
    if (showArrows && shouldRenderInlineHints() && state.engineMoves.length > 0) drawArrows(state.engineMoves);
    else clearArrows();
  }

  function addLog(msg) {
    const log = document.getElementById('shLog');
    if (!log) return;
    const item = document.createElement('div');
    item.className = 'sh-log-item';
    item.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
    log.insertBefore(item, log.firstChild);
    while (log.children.length > 80) log.removeChild(log.lastChild);
  }

  function addEngLog(msg) {
    const log = document.getElementById('shEngLog');
    if (!log) return;
    const item = document.createElement('div');
    item.style.cssText = 'border-bottom:1px solid #333;padding:1px 0;';
    item.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
    log.insertBefore(item, log.firstChild);
    while (log.children.length > 50) log.removeChild(log.lastChild);
    console.log('[SH-CONTENT]', msg);
  }

  function flash(id, txt) {
    const el = document.getElementById(id);
    if (!el) return;
    const orig = el.textContent;
    el.textContent = txt;
    setTimeout(() => el.textContent = orig, 1500);
  }

  function makeDraggable(el) {
    let ox = 0, oy = 0, drag = false;
    el.querySelector('.sh-header').addEventListener('mousedown', e => {
      drag = true; ox = e.clientX - el.getBoundingClientRect().left; oy = e.clientY - el.getBoundingClientRect().top; e.preventDefault();
    });
    document.addEventListener('mousemove', e => {
      if (!drag) return;
      el.style.left = (e.clientX - ox) + 'px'; el.style.top = (e.clientY - oy) + 'px';
      el.style.right = 'auto'; el.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => drag = false);
  }

  // ── Engine message from background ───────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SET_STREAM_MODE') {
      applyStreamMode(msg.enabled !== false);
    }
    if (msg.type === 'STREAM_COMMAND') {
      const command = String(msg.command || '');
      if (command === 'toggle_player') {
        applyManualFix('side');
      } else if (command === 'toggle_turn') {
        applyManualFix('turn');
      }
    }
    if (msg.type === 'ENGINE_STATUS_UPDATE') {
      state.engineReady = msg.ready;
      if (msg.engine) state.engineType = msg.engine;
      const el = document.getElementById('shEngStatus');
      if (!el) return;
      if (msg.loading) {
        state.analysisState = 'loading';
        el.textContent = '● loading…'; el.style.color = '#f0c060';
        if (state.analysisOn && state.engineMoves.length === 0) updateEvalLines([], 'loading');
      } else if (msg.ready) {
        el.textContent = '● ready'; el.style.color = '#60cc60';
        console.log('[SH-CONTENT] Engine now ready — triggering analysis');
        if (state.analysisOn && state.sfen && state.engineMoves.length === 0) {
          requestHintAnalysisIfAllowed(state.sfen, 'engine-ready');
        }
      } else if (msg.error) {
        state.analysisState = 'error';
        el.textContent = '● error'; el.style.color = '#f06060';
        console.error('[SH-CONTENT] Engine error:', msg.error);
        if (state.analysisOn) updateEvalLines([], 'error');
      }
      broadcastState();
    }
    if (msg.type === 'POPUP_SYNC_PREFS') {
      logAction(`prefs sync: analysis=${msg.analysisOn} autoMove=${msg.autoMoveEnabled} delay=${msg.autoMoveDelayMs} hotkey=${msg.bestMoveHotkey} engine=${msg.engineType || state.engineType}`);
      if (typeof msg.analysisOn === 'boolean') {
        setAnalysisEnabled(msg.analysisOn, { trigger: msg.analysisOn });
      }
      if (typeof msg.panelVisible === 'boolean') {
        setPanelVisible(msg.panelVisible);
      }
      if (typeof msg.panelMinimized === 'boolean') {
        setPanelMinimized(msg.panelMinimized);
      }
      if (typeof msg.handsCollapsed === 'boolean') {
        setSectionCollapsed('hands', msg.handsCollapsed);
      }
      if (typeof msg.sfenCollapsed === 'boolean') {
        setSectionCollapsed('sfen', msg.sfenCollapsed);
      }
      if (typeof msg.autoMoveEnabled === 'boolean') {
        state.autoMoveEnabled = msg.autoMoveEnabled;
        if (!state.autoMoveEnabled) {
          clearTimeout(autoMoveTimer);
          logAction('autoMove timer cleared because setting was disabled');
        }
      }
      if (msg.autoMoveDelayMs != null) {
        state.autoMoveDelayMs = Math.max(0, Math.min(2000, parseInt(msg.autoMoveDelayMs, 10) || 250));
        logAction(`autoMove delay updated: ${state.autoMoveDelayMs}ms`);
      }
      if (['Space', 'Enter', 'KeyH', 'KeyB', 'Off'].includes(msg.bestMoveHotkey)) {
        state.bestMoveHotkey = msg.bestMoveHotkey;
        logAction(`hotkey updated: ${state.bestMoveHotkey}`);
      }
      if (msg.engineType) {
        state.engineType = msg.engineType;
        state.engineMoves = [];
        updateEngineControls();
        savePrefs();
        ensureCompatibleEngine();
        chrome.runtime.sendMessage({ type: 'SET_ENGINE', engine: state.engineType }).catch(() => {});
      }
      if (msg.analysisDepth != null) {
        state.analysisDepth = clampSetting(msg.analysisDepth, getEngineLimits(state.engineType).depth);
      }
      if (msg.multiPV != null) {
        state.multiPV = clampSetting(msg.multiPV, getEngineLimits(state.engineType).multiPV);
      }
      updateEngineControls();
      savePrefs();
      if (state.analysisOn && msg.triggerAnalysis !== false && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'popup-sync');
      updateOverlay();
      if (state.autoMoveEnabled) scheduleAutoMove();
      else {
        clearTimeout(autoMoveTimer);
        logAction('autoMove timer cleared after prefs sync');
      }
    }
    if (msg.type === 'ANALYSIS_RESULT') {
      clearTimeout(analysisWatchdog);
      const moves = msg.moves || [];
      console.log('[SH-CONTENT] ANALYSIS_RESULT received — moves:', moves.length, '| depth:', msg.depth, '| error:', msg.error || 'none');
      if (msg.error) {
        console.warn('[SH-CONTENT] Engine error:', msg.error);
      }
      if (msg.sfen !== state.sfen) {
        logAction('analysis result ignored: stale SFEN');
        if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'stale-result');
        return;
        console.log('[SH-CONTENT] SFEN mismatch (stale result) — showing anyway');
        console.log('[SH-CONTENT]   result sfen:', msg.sfen?.substring(0,40));
        console.log('[SH-CONTENT]   state  sfen:', state.sfen?.substring(0,40));
      }
      if (moves.length > 0) {
        console.log('[SH-CONTENT] Top move:', moves[0].pv?.[0], '| eval:', moves[0].cp ?? ('mate '+moves[0].mate));
      }
      state.analysisState = msg.error ? 'error' : 'ready';
      const boardData = readBoardFromDOM();
      const handData = readHandFromDOM();
      const validatedMoves = getValidatedEngineMoves(moves, {
        boardData,
        handData,
        currentTurn: getEffectiveCurrentTurn(),
      });
      if (moves.length > 0 && validatedMoves.length === 0) {
        logAction(`analysis result rejected: ${moves[0]?.pv?.[0] || '(none)'} does not match current board/turn`);
        state.engineMoves = [];
        updateEvalLines([], 'loading');
        clearArrows();
        if (state.analysisOn && state.sfen) requestHintAnalysisIfAllowed(state.sfen, 'invalid-result');
        return;
      }
      state.engineMoves = validatedMoves;
      const [cols, rows] = getBoardDims().split('x').map(Number);
      const firstParsed = parseUSIMove(state.engineMoves[0]?.pv?.[0]);
      if (state.engineMoves.length > 0 && !isMoveWithinBoard(firstParsed, cols, rows)) {
        const switched = ensureCompatibleEngine({ trigger: true });
        if (switched) {
          console.warn('[SH-CONTENT] Engine move does not fit current board; switched engine and retriggered analysis.');
          return;
        }
      }
      updateEvalLines(state.engineMoves, msg.error ? 'error' : 'ok');
      const showArrows = document.getElementById('shArrows')?.checked !== false;
      if (showArrows && shouldRenderInlineHints() && state.engineMoves.length > 0) drawArrows(state.engineMoves);
      else clearArrows();
      scheduleAutoMove();
      broadcastState();
    }
  });

  // ── Communication ─────────────────────────────────────────────────────────
  function broadcastState() {
    try {
      chrome.runtime.sendMessage({ type: 'SHOGI_UPDATE', data: { ...state, timestamp: Date.now() } });
    } catch (e) {}
  }

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg.type === 'GET_STATE') {
      reply({ ...state });
      return true;
    }
    if (msg.type === 'SET_STREAM_MODE') {
      applyStreamMode(msg.enabled !== false);
      reply({ ok: true, streamMode });
      return true;
    }
    if (msg.type === 'STREAM_COMMAND') {
      const command = String(msg.command || '');
      if (command === 'toggle_player') {
        applyManualFix('side');
        reply({ ok: true });
        return true;
      }
      if (command === 'toggle_turn') {
        applyManualFix('turn');
        reply({ ok: true });
        return true;
      }
      reply({ ok: false, error: 'unknown_stream_command' });
      return true;
    }
    return true;
  });

  // ── Main Scan ─────────────────────────────────────────────────────────────
  let lastSfenCache = '';
  let scanTimer = null;

  function moveSignature(move) {
    if (!move) return '';
    return `${move.moveNum || 0}:${move.color || '-'}:${move.notation || '-'}`;
  }

  function runScan() {
    try {
      const sgBoard = document.querySelector('sg-board');
      ensureSiteHeaderToggle();
      if (isHomePage()) {
        clearArrows();
        return;
      }
      if (!sgBoard) return;
      state.variant    = detectVariantAndDims();
      state.boardDims  = getBoardDims();
      state.pageType   = detectPageType();
      state.orientation = getBoardOrientation();
      ensureCompatibleEngine();

      const players = detectPlayerInfo();
      const bottomName = getBottomPlayerName();
      const topName = getTopPlayerName();
      const layoutName = detectMyNameFromLayout();
      const detectedName = detectMyName();
      const bottomColor = detectBottomBoardColor();
      const topColor = oppositeColor(bottomColor);

      state.myName = bottomName || layoutName || detectedName || state.myName;
      if (state.myColorOverride && state.myColorOverride !== bottomColor) {
        logAction(`side override cleared: override=${state.myColorOverride} bottomColor=${bottomColor}`);
        state.myColorOverride = null;
        savePrefs();
      }
      state.myColor = state.myColorOverride || bottomColor;

      if (!players[bottomColor] && bottomName) players[bottomColor] = bottomName;
      if (!players[topColor] && topName) players[topColor] = topName;

      if (!state.myName) {
        state.myName = players[bottomColor] || players[topColor] || state.myName;
      }

      if (state.myName) {
        if (playerNamesMatch(players.sente, state.myName) || playerNamesMatch(players.gote, state.myName)) {
          logAction(`side anchored to bottom board orientation: bottomColor=${bottomColor} bottomName=${bottomName || '(none)'}`);
        }
      }
      state.opponentName = state.myColor === 'sente' ? players.gote : players.sente;

      const boardData = readBoardFromDOM();
      if (!boardData) return;
      const moves = parseMoveList();
      const previousMoveSig = moveSignature(state.lastMove);
      const displayedMoveInfo = getDisplayedMoveInfo(moves);
      const latestMove = displayedMoveInfo.displayedLastMove;
      const latestMoveSig = moveSignature(latestMove);
      const domMovedPiece = detectDomMovedPiece(boardData.cols, boardData.rows, boardData.orientation);
      const lastDestMove = detectLastMoveFromLastDest(boardData.cols, boardData.rows, boardData.orientation, domMovedPiece);
      const clockTurn = getClockTurnSignal(bottomColor);
      const inferredDomMoveRaw = lastDestMove || domMovedPiece;
      const canTrustClockTurn = state.pageType === 'game' && !displayedMoveInfo.isHistoricalView;
      const trustedClockTurn = canTrustClockTurn ? clockTurn : null;
      const inferredDomMove = normalizeMoveColorByClock(inferredDomMoveRaw, trustedClockTurn);
      const normalizedLatestMove = normalizeMoveColorByClock(latestMove, trustedClockTurn);
      const domMoveSig = moveSignature(inferredDomMove);
      const latestMoveSigNormalized = moveSignature(normalizedLatestMove);
      const useDomMove = !displayedMoveInfo.isHistoricalView
        && !!inferredDomMove
        && (!latestMoveSigNormalized || latestMoveSigNormalized === previousMoveSig);

      state.moveNumber = displayedMoveInfo.displayedPly;
      state.lastMove = useDomMove
        ? { moveNum: state.moveNumber || null, color: inferredDomMove.color, notation: inferredDomMove.notation }
        : (normalizedLatestMove ? { moveNum: normalizedLatestMove.moveNum, color: normalizedLatestMove.color, notation: normalizedLatestMove.notation } : null);

      let detectedTurn = useDomMove
        ? oppositeColor(inferredDomMove.color)
        : detectCurrentTurn(bottomColor, moves, displayedMoveInfo);

      if (!trustedClockTurn && state.pageType === 'puzzle' && displayedMoveInfo.displayedPly === 0 && !inferredDomMove) {
        const bottomHandPiece = document.querySelector('sg-hand-wrap.hand-bottom piece');
        const bottomHandColor = String(bottomHandPiece?.className || '').trim().split(/\s+/)[0];
        if (bottomHandColor === state.myColor) {
          detectedTurn = state.myColor;
          logAction(`turn anchored to puzzle side: ${detectedTurn}`);
        } else {
          logAction(`puzzle turn anchor skipped: side=${state.myColor} bottomHandColor=${bottomHandColor || '(none)'}`);
        }
      }

      if (useDomMove) {
        logAction(`DOM move detected: ${inferredDomMove.color} ${inferredDomMove.notation}${lastDestMove ? ' via last-dest' : ' via transform'}`);
      }
      if (trustedClockTurn?.source) {
        logAction(`turn forced by ${trustedClockTurn.source}: ${trustedClockTurn.turn}`);
        if (state.currentTurnOverride && state.currentTurnOverride !== trustedClockTurn.turn) {
          logAction(`turn override cleared: override=${state.currentTurnOverride} clockTurn=${trustedClockTurn.turn}`);
          state.currentTurnOverride = null;
          savePrefs();
        }
      } else if (clockTurn?.source && displayedMoveInfo.isHistoricalView) {
        logAction(`clock ignored in historical view: ${clockTurn.source}=${clockTurn.turn} ply=${displayedMoveInfo.displayedPly}`);
      }

      const changedMoveSig = latestMoveSigNormalized && latestMoveSigNormalized !== previousMoveSig
        ? latestMoveSigNormalized
        : (useDomMove && domMoveSig !== previousMoveSig ? domMoveSig : '');
      if (state.currentTurnOverride && changedMoveSig) {
        logAction(`turn override cleared after new move: ${previousMoveSig || '(none)'} -> ${changedMoveSig}`);
        state.currentTurnOverride = null;
        savePrefs();
      }
      state.currentTurn = state.currentTurnOverride || detectedTurn;
      if (state.currentTurn !== detectedTurn && state.currentTurnOverride) {
        logAction(`turn override active: detected=${detectedTurn} override=${state.currentTurnOverride}`);
      }

      const { handSente, handGote } = readHandFromDOM();
      state.handSente = handSente;
      state.handGote  = handGote;

      const newSfen = generateSFEN(boardData, handSente, handGote, state.currentTurn, state.moveNumber);
      if (newSfen !== lastSfenCache) {
        lastSfenCache = newSfen;
        state.sfen = newSfen;
        broadcastState();
        // Trigger engine if analysis is on
        requestHintAnalysisIfAllowed(newSfen, 'new-sfen');
      }
      if (!shouldShowHints()) clearTimeout(autoMoveTimer);
      updateOverlay();
    } catch (e) { console.error('[ShogiHelper]', e); }
  }

  // ── Observer ──────────────────────────────────────────────────────────────
  function setupObserver() {
    const targets = [
      document.querySelector('sg-board'),
      document.querySelector('.moves'),
      document.querySelector('sg-hand-wrap'),
    ].filter(Boolean);
    if (targets.length === 0) {
      const obs = new MutationObserver(() => { if (document.querySelector('sg-board')) { obs.disconnect(); initOnGamePage(); } });
      obs.observe(document.body, { childList: true, subtree: true });
      return;
    }
    const obs = new MutationObserver(() => { clearTimeout(scanTimer); scanTimer = setTimeout(runScan, 200); });
    for (const t of targets) obs.observe(t, { childList: true, subtree: true, characterData: true, attributes: true });
  }

  async function initOnGamePage() {
    if (isHomePage()) return;
    await loadPrefs();
    initStreamMode();
    if (!window.__shogiHelperHotkeyBound) {
      window.__shogiHelperHotkeyBound = true;
      document.addEventListener('keydown', (event) => {
        logAction(`keydown detected: key=${event.key || '(none)'} code=${event.code || '(none)'} target=${describeEventTarget(event.target)}`);
        if (!shouldHandleHotkey(event)) return;
        if (autoMoveInFlight) {
          logAction('hotkey ignored: move execution already in flight');
          return;
        }
        event.preventDefault();
        logAction(`hotkey accepted: ${state.bestMoveHotkey}`);
        autoMoveInFlight = true;
        playBestMove(true)
          .then((ok) => logAction(`hotkey execution result: ${ok}`))
          .catch((err) => logAction(`hotkey execution error: ${err?.message || err}`))
          .finally(() => {
            autoMoveInFlight = false;
            logAction('hotkey execution finished');
          });
      });
    }
    createOverlay();
    ensureSiteHeaderToggle();
    setupObserver();
    runScan();
    setInterval(runScan, POLL_MS);
    setInterval(updateEngineStatus, 3000);
    console.log('[SH-CONTENT] Shogi Helper v3 Ready — variant:', detectVariantAndDims(), '| analysisOn:', state.analysisOn);
    // Auto-trigger analysis on first load if engine is on
    if (state.analysisOn && state.sfen) {
      console.log('[SH-CONTENT] Auto-starting analysis on init');
      requestHintAnalysisIfAllowed(state.sfen, 'init');
    }
    // Show loading state immediately
    updateEvalLines([], 'loading');
  }

  function init() {
    if (isHomePage()) return;
    if (document.querySelector('sg-board')) initOnGamePage();
    else {
      const obs = new MutationObserver(() => {
        if (!isHomePage() && document.querySelector('sg-board')) {
          obs.disconnect();
          initOnGamePage();
        }
      });
      obs.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
