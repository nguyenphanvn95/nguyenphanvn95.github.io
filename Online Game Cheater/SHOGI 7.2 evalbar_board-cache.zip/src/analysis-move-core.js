/*!
 * analysis-move-core.js
 *
 * Standalone, documented move-processing module extracted conceptually from
 * the move handling flow used by /analysis in this project.
 *
 * Goal:
 * engine move string (USI) -> parse -> validate -> apply to state -> compare.
 *
 * This file is intentionally written for learning and reuse.
 * It targets standard 9x9 shogi SFEN/USI.
 */
(function (globalFactory) {
  if (typeof module !== "undefined" && module.exports) {
    module.exports = globalFactory();
  } else {
    window.ShogiAnalysisMoveCore = globalFactory();
  }
})(function () {
  "use strict";

  const COLORS = ["sente", "gote"];
  const EMPTY_HANDS = () => ({
    sente: createEmptyHand(),
    gote: createEmptyHand(),
  });

  const SFEN_TO_ROLE = {
    P: "pawn",
    L: "lance",
    N: "knight",
    S: "silver",
    G: "gold",
    B: "bishop",
    R: "rook",
    K: "king",
  };

  const DROP_CODE_TO_ROLE = {
    P: "pawn",
    L: "lance",
    N: "knight",
    S: "silver",
    G: "gold",
    B: "bishop",
    R: "rook",
  };

  const ROLE_TO_SFEN = {
    pawn: "P",
    lance: "L",
    knight: "N",
    silver: "S",
    gold: "G",
    bishop: "B",
    rook: "R",
    king: "K",
    proPawn: "+P",
    proLance: "+L",
    proKnight: "+N",
    proSilver: "+S",
    horse: "+B",
    dragon: "+R",
  };

  const PROMOTE_MAP = {
    pawn: "proPawn",
    lance: "proLance",
    knight: "proKnight",
    silver: "proSilver",
    bishop: "horse",
    rook: "dragon",
  };

  const UNPROMOTE_MAP = {
    proPawn: "pawn",
    proLance: "lance",
    proKnight: "knight",
    proSilver: "silver",
    horse: "bishop",
    dragon: "rook",
  };

  function createEmptyHand() {
    return {
      pawn: 0,
      lance: 0,
      knight: 0,
      silver: 0,
      gold: 0,
      bishop: 0,
      rook: 0,
    };
  }

  function clonePiece(piece) {
    return piece ? { color: piece.color, role: piece.role } : null;
  }

  function cloneHands(hands) {
    return {
      sente: { ...createEmptyHand(), ...(hands?.sente || {}) },
      gote: { ...createEmptyHand(), ...(hands?.gote || {}) },
    };
  }

  function cloneState(state) {
    const board = {};
    for (const [square, piece] of Object.entries(state.board || {})) {
      board[square] = clonePiece(piece);
    }
    return {
      board,
      hands: cloneHands(state.hands),
      turn: state.turn,
      moveNumber: state.moveNumber,
      lastMove: state.lastMove ? { ...state.lastMove } : null,
    };
  }

  function oppositeColor(color) {
    return color === "sente" ? "gote" : "sente";
  }

  function squareToCoords(square) {
    if (!/^[1-9][a-i]$/.test(square)) {
      throw new Error(`Invalid square: ${square}`);
    }
    return {
      file: Number(square[0]),
      rank: square[1],
      rankIndex: square.charCodeAt(1) - 97,
    };
  }

  function isPromotionZone(color, square) {
    const { rankIndex } = squareToCoords(square);
    return color === "sente" ? rankIndex <= 2 : rankIndex >= 6;
  }

  function canPromote(role) {
    return Boolean(PROMOTE_MAP[role]);
  }

  function promoteRole(role) {
    return PROMOTE_MAP[role] || role;
  }

  function unpromoteRole(role) {
    return UNPROMOTE_MAP[role] || role;
  }

  function convertCapturedPieceToHandRole(piece) {
    return unpromoteRole(piece.role);
  }

  function isForcedPromotion(role, color, destinationSquare) {
    const { rankIndex } = squareToCoords(destinationSquare);
    if (role === "pawn" || role === "lance") {
      return color === "sente" ? rankIndex === 0 : rankIndex === 8;
    }
    if (role === "knight") {
      return color === "sente" ? rankIndex <= 1 : rankIndex >= 7;
    }
    return false;
  }

  function isPromotionLegal(piece, fromSquare, toSquare) {
    return (
      canPromote(piece.role) &&
      (isPromotionZone(piece.color, fromSquare) ||
        isPromotionZone(piece.color, toSquare))
    );
  }

  function hasUnpromotedPawnOnFile(state, color, fileNumber) {
    const targetFile = String(fileNumber);
    return Object.entries(state.board).some(([square, piece]) => {
      return (
        square[0] === targetFile &&
        piece.color === color &&
        piece.role === "pawn"
      );
    });
  }

  function parseSfenBoard(boardPart) {
    const board = {};
    const ranks = boardPart.split("/");
    if (ranks.length !== 9) {
      throw new Error(`Invalid SFEN board: ${boardPart}`);
    }

    ranks.forEach((rankText, rankIndex) => {
      let file = 9;
      for (let i = 0; i < rankText.length; i += 1) {
        const char = rankText[i];
        if (/\d/.test(char)) {
          file -= Number(char);
          continue;
        }

        let promoted = false;
        let pieceChar = char;
        if (char === "+") {
          promoted = true;
          i += 1;
          pieceChar = rankText[i];
        }

        const isSente = pieceChar === pieceChar.toUpperCase();
        const baseRole = SFEN_TO_ROLE[pieceChar.toUpperCase()];
        if (!baseRole) {
          throw new Error(`Unknown SFEN piece: ${pieceChar}`);
        }

        const role = promoted ? promoteRole(baseRole) : baseRole;
        const square = `${file}${String.fromCharCode(97 + rankIndex)}`;
        board[square] = {
          color: isSente ? "sente" : "gote",
          role,
        };
        file -= 1;
      }

      if (file !== 0) {
        throw new Error(`Invalid rank width in SFEN rank: ${rankText}`);
      }
    });

    return board;
  }

  function parseSfenHands(handsPart) {
    const hands = EMPTY_HANDS();
    if (!handsPart || handsPart === "-") {
      return hands;
    }

    let countBuffer = "";
    for (const char of handsPart) {
      if (/\d/.test(char)) {
        countBuffer += char;
        continue;
      }

      const count = countBuffer ? Number(countBuffer) : 1;
      countBuffer = "";

      const role = DROP_CODE_TO_ROLE[char.toUpperCase()];
      if (!role) {
        throw new Error(`Unknown hand piece in SFEN: ${char}`);
      }

      const color = char === char.toUpperCase() ? "sente" : "gote";
      hands[color][role] += count;
    }

    return hands;
  }

  function parseSfen(sfen) {
    const parts = String(sfen || "").trim().split(/\s+/);
    if (parts.length < 4) {
      throw new Error(`Invalid SFEN: ${sfen}`);
    }

    return {
      board: parseSfenBoard(parts[0]),
      hands: parseSfenHands(parts[2]),
      turn: parts[1] === "w" ? "gote" : "sente",
      moveNumber: Number(parts[3]) || 1,
      lastMove: null,
    };
  }

  function pieceToSfenCode(piece) {
    const sfenRole = ROLE_TO_SFEN[piece.role];
    if (!sfenRole) {
      throw new Error(`Unsupported role for SFEN export: ${piece.role}`);
    }
    return piece.color === "sente" ? sfenRole : sfenRole.toLowerCase();
  }

  function handsToSfen(hands) {
    let output = "";
    const order = ["rook", "bishop", "gold", "silver", "knight", "lance", "pawn"];
    for (const color of COLORS) {
      for (const role of order) {
        const count = hands[color][role] || 0;
        if (!count) {
          continue;
        }
        const code = ROLE_TO_SFEN[role];
        const coloredCode = color === "sente" ? code : code.toLowerCase();
        output += `${count > 1 ? count : ""}${coloredCode}`;
      }
    }
    return output || "-";
  }

  function stateToSfen(state) {
    const ranks = [];
    for (let rankIndex = 0; rankIndex < 9; rankIndex += 1) {
      let empty = 0;
      let rankText = "";
      for (let file = 9; file >= 1; file -= 1) {
        const square = `${file}${String.fromCharCode(97 + rankIndex)}`;
        const piece = state.board[square];
        if (!piece) {
          empty += 1;
          continue;
        }
        if (empty) {
          rankText += String(empty);
          empty = 0;
        }
        rankText += pieceToSfenCode(piece);
      }
      if (empty) {
        rankText += String(empty);
      }
      ranks.push(rankText);
    }

    return [
      ranks.join("/"),
      state.turn === "gote" ? "w" : "b",
      handsToSfen(state.hands),
      state.moveNumber || 1,
    ].join(" ");
  }

  function parseUsiMove(usi) {
    const text = String(usi || "").trim();
    if (/^[PLNSGBR]\*[1-9][a-i]$/.test(text)) {
      return {
        kind: "drop",
        role: DROP_CODE_TO_ROLE[text[0]],
        to: text.slice(2),
        promote: false,
        raw: text,
      };
    }

    if (/^[1-9][a-i][1-9][a-i]\+?$/.test(text)) {
      return {
        kind: "move",
        from: text.slice(0, 2),
        to: text.slice(2, 4),
        promote: text.endsWith("+"),
        raw: text,
      };
    }

    throw new Error(`Unsupported USI move: ${usi}`);
  }

  function validateDrop(state, move, options) {
    const errors = [];
    const targetPiece = state.board[move.to];
    const count = state.hands[state.turn]?.[move.role] || 0;

    if (targetPiece) {
      errors.push(`Destination ${move.to} is not empty`);
    }

    if (count <= 0) {
      errors.push(`No ${move.role} in hand for ${state.turn}`);
    }

    if (options.enforceNifu && move.role === "pawn") {
      const { file } = squareToCoords(move.to);
      if (hasUnpromotedPawnOnFile(state, state.turn, file)) {
        errors.push(`Nifu: ${state.turn} already has an unpromoted pawn on file ${file}`);
      }
    }

    if (move.role === "pawn" || move.role === "lance") {
      const { rankIndex } = squareToCoords(move.to);
      const deadRank = state.turn === "sente" ? 0 : 8;
      if (rankIndex === deadRank) {
        errors.push(`${move.role} cannot be dropped on the last rank`);
      }
    }

    if (move.role === "knight") {
      const { rankIndex } = squareToCoords(move.to);
      if (state.turn === "sente" && rankIndex <= 1) {
        errors.push("Knight cannot be dropped on the last two ranks");
      }
      if (state.turn === "gote" && rankIndex >= 7) {
        errors.push("Knight cannot be dropped on the last two ranks");
      }
    }

    return {
      ok: errors.length === 0,
      errors,
    };
  }

  function validateBoardMove(state, move) {
    const errors = [];
    const movingPiece = state.board[move.from];
    const targetPiece = state.board[move.to];

    if (!movingPiece) {
      errors.push(`No piece at ${move.from}`);
    } else {
      if (movingPiece.color !== state.turn) {
        errors.push(`It is ${state.turn}'s turn, not ${movingPiece.color}'s turn`);
      }
      if (targetPiece && targetPiece.color === movingPiece.color) {
        errors.push(`Destination ${move.to} contains your own piece`);
      }
      if (move.promote && !isPromotionLegal(movingPiece, move.from, move.to)) {
        errors.push(`Promotion is not legal for ${movingPiece.role} from ${move.from} to ${move.to}`);
      }
      if (
        !move.promote &&
        isForcedPromotion(movingPiece.role, movingPiece.color, move.to)
      ) {
        errors.push(`Promotion is mandatory for ${movingPiece.role} to ${move.to}`);
      }
    }

    return {
      ok: errors.length === 0,
      errors,
    };
  }

  function validateMoveAgainstList(usi, expectedMoves) {
    if (!Array.isArray(expectedMoves) || expectedMoves.length === 0) {
      return { ok: true, errors: [] };
    }

    return expectedMoves.includes(usi)
      ? { ok: true, errors: [] }
      : {
          ok: false,
          errors: [`Move ${usi} is not in expected move list`],
        };
  }

  function validateParsedMove(state, parsedMove, options) {
    return parsedMove.kind === "drop"
      ? validateDrop(state, parsedMove, options)
      : validateBoardMove(state, parsedMove);
  }

  function normalizePromotionChoice(state, parsedMove, options) {
    if (parsedMove.kind !== "move" || !options.autoForcePromotion) {
      return parsedMove;
    }

    const movingPiece = state.board[parsedMove.from];
    if (
      movingPiece &&
      !parsedMove.promote &&
      isForcedPromotion(movingPiece.role, movingPiece.color, parsedMove.to)
    ) {
      return { ...parsedMove, promote: true };
    }

    return parsedMove;
  }

  function applyDropUnsafe(nextState, move) {
    nextState.board[move.to] = {
      color: nextState.turn,
      role: move.role,
    };
    nextState.hands[nextState.turn][move.role] -= 1;
    nextState.lastMove = {
      kind: "drop",
      color: nextState.turn,
      role: move.role,
      to: move.to,
      capture: null,
      usi: move.raw,
    };
  }

  function applyBoardMoveUnsafe(nextState, move) {
    const movingPiece = clonePiece(nextState.board[move.from]);
    const captured = clonePiece(nextState.board[move.to]);

    if (move.promote) {
      movingPiece.role = promoteRole(movingPiece.role);
    }

    delete nextState.board[move.from];
    nextState.board[move.to] = movingPiece;

    if (captured) {
      const handRole = convertCapturedPieceToHandRole(captured);
      nextState.hands[nextState.turn][handRole] += 1;
    }

    nextState.lastMove = {
      kind: "move",
      color: nextState.turn,
      from: move.from,
      to: move.to,
      promote: move.promote,
      piece: movingPiece.role,
      capture: captured,
      usi: move.raw,
    };
  }

  function finishMove(nextState) {
    nextState.turn = oppositeColor(nextState.turn);
    nextState.moveNumber = (nextState.moveNumber || 1) + 1;
    return nextState;
  }

  function applyParsedMove(state, parsedMove, options) {
    const nextState = cloneState(state);

    if (parsedMove.kind === "drop") {
      applyDropUnsafe(nextState, parsedMove);
    } else {
      applyBoardMoveUnsafe(nextState, parsedMove);
    }

    return finishMove(nextState);
  }

  function diffStates(beforeState, afterState) {
    const changes = {
      removed: [],
      added: [],
      moved: [],
      handChanges: [],
    };

    for (const [square, beforePiece] of Object.entries(beforeState.board)) {
      const afterPiece = afterState.board[square];
      if (!afterPiece) {
        changes.removed.push({ square, piece: beforePiece });
      } else if (
        beforePiece.color !== afterPiece.color ||
        beforePiece.role !== afterPiece.role
      ) {
        changes.removed.push({ square, piece: beforePiece });
        changes.added.push({ square, piece: afterPiece });
      }
    }

    for (const [square, afterPiece] of Object.entries(afterState.board)) {
      if (!beforeState.board[square]) {
        changes.added.push({ square, piece: afterPiece });
      }
    }

    const lastMove = afterState.lastMove;
    if (lastMove?.kind === "move") {
      changes.moved.push({
        from: lastMove.from,
        to: lastMove.to,
        promote: lastMove.promote,
        capture: lastMove.capture,
      });
    }

    for (const color of COLORS) {
      const beforeHand = beforeState.hands[color];
      const afterHand = afterState.hands[color];
      for (const role of Object.keys(createEmptyHand())) {
        const beforeCount = beforeHand[role] || 0;
        const afterCount = afterHand[role] || 0;
        if (beforeCount !== afterCount) {
          changes.handChanges.push({
            color,
            role,
            before: beforeCount,
            after: afterCount,
          });
        }
      }
    }

    return changes;
  }

  function processEngineMove(input) {
    const options = {
      autoForcePromotion: true,
      enforceNifu: true,
      expectedMoves: null,
      ...input.options,
    };

    const currentState =
      typeof input.state === "string" ? parseSfen(input.state) : cloneState(input.state);

    const parsedMove = normalizePromotionChoice(
      currentState,
      parseUsiMove(input.usi),
      options
    );
    const validation = validateParsedMove(currentState, parsedMove, options);
    const comparison = validateMoveAgainstList(input.usi, options.expectedMoves);

    const errors = [...validation.errors, ...comparison.errors];
    if (errors.length > 0) {
      return {
        ok: false,
        errors,
        parsedMove,
        stateBefore: currentState,
      };
    }

    const stateAfter = applyParsedMove(currentState, parsedMove, options);

    return {
      ok: true,
      parsedMove,
      stateBefore: currentState,
      stateAfter,
      nextSfen: stateToSfen(stateAfter),
      diff: diffStates(currentState, stateAfter),
    };
  }

  function describeMoveFlow() {
    return [
      "1. parseUsiMove(usi): tách USI engine trả về thành move/drop",
      "2. validateParsedMove(state, move): kiểm tra ô nguồn, ô đích, hand, promotion",
      "3. applyParsedMove(state, move): cập nhật board/hands/lastMove",
      "4. diffStates(before, after): lấy chênh lệch để animate/render UI khác",
      "5. stateToSfen(state): xuất state mới thành SFEN để lưu hoặc đối chiếu",
    ];
  }

  return {
    parseSfen,
    stateToSfen,
    parseUsiMove,
    validateParsedMove,
    applyParsedMove,
    processEngineMove,
    diffStates,
    describeMoveFlow,
    helpers: {
      cloneState,
      oppositeColor,
      promoteRole,
      unpromoteRole,
      isPromotionLegal,
      isForcedPromotion,
      hasUnpromotedPawnOnFile,
    },
    originalLishogiMapping: {
      os: "applyBoardMoveUnsafe",
      ns: "applyDropUnsafe",
      Ll: "finish board move + flip turn",
      Rl: "finish drop move + flip turn",
      wn: "try/apply board move",
      bn: "try/apply hand drop",
      ss: "build promoted piece",
      _o: "can board move to destination",
      Ko: "can drop to destination",
    },
  };
});
