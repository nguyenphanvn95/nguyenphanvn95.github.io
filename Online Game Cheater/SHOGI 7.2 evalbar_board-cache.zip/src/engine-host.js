/**
 * engine-host.js - Offscreen engine host
 *
 * Loads the selected engine in a DOM-capable offscreen document and relays
 * USI analysis output back to the service worker.
 */

console.log('[SH-ENGINE-HOST] Starting...');

let engine = null;
let engineReady = false;
let engineLoading = false;
let activeEngineType = 'yaneuraou';
let activeEngineConfig = null;

let pvBuffer = {};
let bestDepthSeen = 0;
let currentSfen = null;
let currentVariant = 'standard';
let lastAnalyzeRequest = null;
let lastEngineLines = [];

const VARIANT_USI = {
  standard: 'shogi',
  minishogi: 'minishogi',
  kyotoshogi: 'kyotoshogi',
  dobutsu: 'dobutsu',
  annanshogi: 'annanshogi',
  checkshogi: 'checkshogi',
  chushogi: 'chushogi',
};

const ENGINE_CATALOG = {
  yaneuraou: {
    label: 'YaneuraOu',
    script: 'src/yaneuraou.k-p.js',
    globalName: 'YaneuraOu_K_P',
    locateFile(file) {
      return chrome.runtime.getURL(`src/${file}`);
    },
  },
  stockfish: {
    label: 'Fairy-Stockfish',
    script: 'src/stockfish.js',
    globalName: 'Stockfish',
    locateFile(file) {
      return chrome.runtime.getURL(`src/${file}`);
    },
  },
};

let loadAttempts = 0;

function log(...args) { console.log('[SH-ENGINE-HOST]', ...args); }
function warn(...args) { console.warn('[SH-ENGINE-HOST]', ...args); }
function err(...args) { console.error('[SH-ENGINE-HOST]', ...args); }

function pushEngineLine(line) {
  if (!line) return;
  lastEngineLines.push(String(line));
  if (lastEngineLines.length > 30) lastEngineLines = lastEngineLines.slice(-30);
}

function sendHostState(extra = {}) {
  chrome.runtime.sendMessage({
    type: 'ENGINE_HOST_STATE',
    engine: activeEngineType,
    ready: engineReady,
    loading: engineLoading,
    currentSfen,
    currentVariant,
    bestDepthSeen,
    pvBufferDepths: Object.keys(pvBuffer).map((key) => parseInt(key, 10)).filter(Number.isFinite).sort((a, b) => a - b),
    lastAnalyzeRequest,
    lastEngineLines,
    ...extra,
  });
}

function notifyStatus(extra = {}) {
  chrome.runtime.sendMessage({
    type: 'ENGINE_STATUS',
    ready: engineReady,
    loading: engineLoading,
    engine: activeEngineType,
    ...extra,
  });
}

async function injectScriptOnce(src, marker) {
  if (window[marker]) return;
  await new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(src);
    script.onload = () => {
      window[marker] = true;
      resolve();
    };
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });
}

async function setEngineType(engineType) {
  const nextType = ENGINE_CATALOG[engineType] ? engineType : 'yaneuraou';
  if (nextType === activeEngineType && (engine || engineLoading || engineReady)) return;

  if (engine?.terminate) {
    try {
      engine.terminate();
    } catch (e) {
      warn('terminate failed:', e?.message || e);
    }
  }

  engine = null;
  engineReady = false;
  engineLoading = false;
  activeEngineType = nextType;
  activeEngineConfig = ENGINE_CATALOG[nextType];
  loadAttempts = 0;
  pvBuffer = {};
  bestDepthSeen = 0;
}

async function loadEngine(preferredType = activeEngineType) {
  await setEngineType(preferredType);
  if (engineReady || engineLoading) return;

  if (loadAttempts >= 3) {
    notifyStatus({ ready: false, loading: false, error: `Max retries exceeded for ${activeEngineType}` });
    return;
  }

  loadAttempts += 1;
  engineLoading = true;
  notifyStatus({ ready: false, loading: true });
  log(`Loading ${activeEngineConfig.label} (attempt ${loadAttempts})`);
  log('SharedArrayBuffer available:', typeof SharedArrayBuffer !== 'undefined');
  log('crossOriginIsolated:', self.crossOriginIsolated);

  try {
    await injectScriptOnce(activeEngineConfig.script, `__${activeEngineType}Loaded`);
    const factory = globalThis[activeEngineConfig.globalName];
    if (typeof factory !== 'function') {
      throw new Error(`${activeEngineConfig.globalName} is not available`);
    }

    engine = await factory({
      locateFile: (file) => {
        const url = activeEngineConfig.locateFile(file);
        log('locateFile:', file, '->', url);
        return url;
      },
    });

    engine.addMessageListener(onEngineMessage);
    engine.postMessage('usi');
  } catch (e) {
    engineLoading = false;
    const errorMessage = e?.message || String(e);
    err('Engine load failed:', errorMessage);
    if (activeEngineType === 'yaneuraou') {
      warn('Falling back to Fairy-Stockfish');
      notifyStatus({ ready: false, loading: false, error: `YaneuraOu failed, fallback to Fairy-Stockfish: ${errorMessage}` });
      await setEngineType('stockfish');
      loadEngine('stockfish');
      return;
    }
    notifyStatus({ ready: false, loading: false, error: errorMessage });
    if (loadAttempts < 3) {
      setTimeout(() => loadEngine(activeEngineType), 2000);
    }
  }
}

function onEngineMessage(line) {
  if (!line) return;
  pushEngineLine(line);

  if (line.startsWith('info ') && line.includes('depth')) {
    console.debug('[SH-ENG]', line.substring(0, 140));
  } else {
    log('[SH-ENG]', line);
  }

  if (line === 'usiok' || line.startsWith('usiok')) {
    engine.postMessage('isready');
    return;
  }

  if (line === 'readyok') {
    engineReady = true;
    engineLoading = false;
    notifyStatus({ ready: true, loading: false });
    return;
  }

  if (line.startsWith('info ') && line.includes(' pv ')) {
    const depthM = line.match(/\bdepth (\d+)/);
    const pvM = line.match(/\bmultipv (\d+)/);
    const cpM = line.match(/\bscore cp (-?\d+)/);
    const mateM = line.match(/\bscore mate (-?\d+)/);
    const pvMovM = line.match(/\bpv (.+)$/);
    const pvIdx = pvM ? parseInt(pvM[1], 10) : 1;
    const depth = depthM ? parseInt(depthM[1], 10) : 1;
    if (!pvBuffer[depth]) pvBuffer[depth] = {};
    pvBuffer[depth][pvIdx] = {
      rank: pvIdx,
      cp: cpM ? parseInt(cpM[1], 10) : null,
      mate: mateM ? parseInt(mateM[1], 10) : null,
      pv: pvMovM ? pvMovM[1].trim().split(/\s+/) : [],
      depth,
    };
    if (depth > bestDepthSeen) bestDepthSeen = depth;
    return;
  }

  if (line.startsWith('bestmove')) {
    let moves = [];
    for (let depth = bestDepthSeen; depth >= 1; depth -= 1) {
      if (pvBuffer[depth] && Object.keys(pvBuffer[depth]).length > 0) {
        moves = Object.values(pvBuffer[depth]).sort((a, b) => a.rank - b.rank);
        break;
      }
    }

    chrome.runtime.sendMessage({
      type: 'ENGINE_RESULT',
      moves,
      sfen: currentSfen,
      depth: bestDepthSeen,
      variant: currentVariant,
      engine: activeEngineType,
      error: moves.length === 0 ? 'No moves in pvBuffer' : null,
    });

    pvBuffer = {};
    bestDepthSeen = 0;
    sendHostState();
  }
}

async function analyze(sfen, variant, multiPV, depth, engineType) {
  if (engineType && engineType !== activeEngineType) {
    await setEngineType(engineType);
  }

  if (!engineReady) {
    await loadEngine(engineType || activeEngineType);
    if (!engineReady) {
      chrome.runtime.sendMessage({
        type: 'ENGINE_RESULT',
        moves: [],
        sfen,
        depth: 0,
        variant,
        engine: activeEngineType,
        error: 'Engine failed to initialize',
      });
      return;
    }
  }

  log('analyze engine:', activeEngineType, 'variant:', variant, 'depth:', depth, 'multiPV:', multiPV);
  currentSfen = sfen;
  currentVariant = variant;
  lastAnalyzeRequest = {
    sfen,
    variant,
    multiPV: multiPV || 3,
    depth: depth || 15,
    engine: activeEngineType,
    at: Date.now(),
  };
  pvBuffer = {};
  bestDepthSeen = 0;

  const usiVariant = VARIANT_USI[variant] || 'shogi';
  engine.postMessage('stop');
  engine.postMessage(`setoption name USI_Variant value ${usiVariant}`);
  engine.postMessage(`setoption name MultiPV value ${multiPV || 3}`);
  engine.postMessage('setoption name Threads value 1');
  engine.postMessage('usinewgame');
  engine.postMessage(`position sfen ${sfen}`);
  engine.postMessage(`go depth ${depth || 15}`);
  sendHostState();
}

function stopEngine() {
  if (engineReady && engine) {
    engine.postMessage('stop');
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'HOST_ANALYZE') {
    analyze(msg.sfen, msg.variant, msg.multiPV, msg.depth, msg.engine);
  } else if (msg.type === 'HOST_STOP') {
    stopEngine();
  } else if (msg.type === 'HOST_SET_ENGINE') {
    setEngineType(msg.engine).then(() => loadEngine(msg.engine));
  } else if (msg.type === 'HOST_STATUS_CHECK') {
    notifyStatus();
    sendHostState();
  } else if (msg.type === 'HOST_INIT') {
    loadEngine(msg.engine || activeEngineType);
  }
});

loadEngine(activeEngineType);
