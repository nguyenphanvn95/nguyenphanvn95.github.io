const ENGINE_LIMITS = {
  yaneuraou: {
    depth: { min: 6, max: 30, step: 1, defaultValue: 15 },
    multiPV: { min: 1, max: 6, step: 1, defaultValue: 3 },
  },
  stockfish: {
    depth: { min: 6, max: 24, step: 1, defaultValue: 15 },
    multiPV: { min: 1, max: 6, step: 1, defaultValue: 3 },
  },
};

const DEFAULT_PREFS = {
  engineType: 'yaneuraou',
  analysisDepth: 15,
  multiPV: 3,
  analysisOn: true,
  panelVisible: true,
  bestMoveHotkey: 'Space',
  autoMoveEnabled: false,
  autoMoveDelayMs: 250,
};

let activeTabId = null;
let prefs = { ...DEFAULT_PREFS };

function setPopupAvailability(hasLishogiTab) {
  const emptyState = document.getElementById('emptyState');
  const settingsWrap = document.getElementById('settingsWrap');
  const badge = document.getElementById('badge');
  const streamBtn = document.getElementById('btnOpenStream');
  if (emptyState) emptyState.classList.toggle('show', !hasLishogiTab);
  if (settingsWrap) settingsWrap.classList.toggle('hidden', !hasLishogiTab);
  if (badge && !hasLishogiTab) badge.textContent = '-';
  if (streamBtn) streamBtn.disabled = !hasLishogiTab;
}

function getEngineLimits(engineType) {
  return ENGINE_LIMITS[engineType] || ENGINE_LIMITS.yaneuraou;
}

function clampSetting(value, config) {
  const parsed = parseInt(value, 10);
  if (Number.isNaN(parsed)) return config.defaultValue;
  return Math.max(config.min, Math.min(config.max, parsed));
}

function normalizePrefs() {
  const limits = getEngineLimits(prefs.engineType);
  prefs.analysisDepth = clampSetting(prefs.analysisDepth, limits.depth);
  prefs.multiPV = clampSetting(prefs.multiPV, limits.multiPV);
  const hotkeys = ['Space', 'Enter', 'KeyH', 'KeyB', 'Off'];
  prefs.bestMoveHotkey = hotkeys.includes(prefs.bestMoveHotkey) ? prefs.bestMoveHotkey : DEFAULT_PREFS.bestMoveHotkey;
  prefs.autoMoveEnabled = prefs.autoMoveEnabled === true;
  prefs.autoMoveDelayMs = Math.max(0, Math.min(2000, parseInt(prefs.autoMoveDelayMs, 10) || DEFAULT_PREFS.autoMoveDelayMs));
}

function updateSliderUi() {
  normalizePrefs();
  const limits = getEngineLimits(prefs.engineType);

  const depthRange = document.getElementById('depthRange');
  depthRange.min = String(limits.depth.min);
  depthRange.max = String(limits.depth.max);
  depthRange.step = String(limits.depth.step);
  depthRange.value = String(prefs.analysisDepth);
  document.getElementById('depthValue').textContent = String(prefs.analysisDepth);
  document.getElementById('depthMin').textContent = String(limits.depth.min);
  document.getElementById('depthMax').textContent = String(limits.depth.max);

  const pvRange = document.getElementById('pvRange');
  pvRange.min = String(limits.multiPV.min);
  pvRange.max = String(limits.multiPV.max);
  pvRange.step = String(limits.multiPV.step);
  pvRange.value = String(prefs.multiPV);
  document.getElementById('pvValue').textContent = String(prefs.multiPV);
  document.getElementById('pvMin').textContent = String(limits.multiPV.min);
  document.getElementById('pvMax').textContent = String(limits.multiPV.max);
}

function renderUi(state) {
  const data = state || {};
  prefs = {
    ...prefs,
    ...DEFAULT_PREFS,
    engineType: data.engineType || prefs.engineType,
    analysisDepth: data.analysisDepth ?? prefs.analysisDepth,
    multiPV: data.multiPV ?? prefs.multiPV,
    analysisOn: typeof data.analysisOn === 'boolean' ? data.analysisOn : prefs.analysisOn,
    panelVisible: typeof data.panelVisible === 'boolean' ? data.panelVisible : prefs.panelVisible,
    bestMoveHotkey: data.bestMoveHotkey || prefs.bestMoveHotkey,
    autoMoveEnabled: typeof data.autoMoveEnabled === 'boolean' ? data.autoMoveEnabled : prefs.autoMoveEnabled,
    autoMoveDelayMs: data.autoMoveDelayMs ?? prefs.autoMoveDelayMs,
  };
  normalizePrefs();

  document.getElementById('engineSelect').value = prefs.engineType;
  document.getElementById('enableEngine').checked = prefs.analysisOn;
  document.getElementById('showPanel').checked = prefs.panelVisible;
  document.getElementById('hotkeySelect').value = prefs.bestMoveHotkey;
  document.getElementById('autoMoveEnabled').checked = prefs.autoMoveEnabled;
  document.getElementById('autoDelayRange').value = String(prefs.autoMoveDelayMs);
  document.getElementById('autoDelayValue').textContent = `${prefs.autoMoveDelayMs} ms`;
  updateSliderUi();

  document.getElementById('badge').textContent = data.variant || '-';
  document.getElementById('statusHint').textContent = data.sfen
    ? 'The panel and popup are using the same settings.'
    : 'Open Lishogi to use the panel and engine analysis.';
}

async function savePrefs() {
  await chrome.storage.local.set({
    engineType: prefs.engineType,
    analysisDepth: prefs.analysisDepth,
    multiPV: prefs.multiPV,
    analysisOn: prefs.analysisOn,
    panelVisible: prefs.panelVisible,
    bestMoveHotkey: prefs.bestMoveHotkey,
    autoMoveEnabled: prefs.autoMoveEnabled,
    autoMoveDelayMs: prefs.autoMoveDelayMs,
  });
}

async function syncToPage(extra = {}) {
  if (!activeTabId) return;
  try {
    await chrome.tabs.sendMessage(activeTabId, {
      type: 'POPUP_SYNC_PREFS',
      engineType: prefs.engineType,
      analysisDepth: prefs.analysisDepth,
      multiPV: prefs.multiPV,
      analysisOn: prefs.analysisOn,
      panelVisible: prefs.panelVisible,
      bestMoveHotkey: prefs.bestMoveHotkey,
      autoMoveEnabled: prefs.autoMoveEnabled,
      autoMoveDelayMs: prefs.autoMoveDelayMs,
      ...extra,
    });
  } catch (e) {}
}

async function loadState() {
  const stored = await chrome.storage.local.get([
    'engineType',
    'analysisDepth',
    'multiPV',
    'analysisOn',
    'panelVisible',
    'bestMoveHotkey',
    'autoMoveEnabled',
    'autoMoveDelayMs',
    'shogiState',
  ]);
  prefs = {
    ...DEFAULT_PREFS,
    ...prefs,
    engineType: stored.engineType || prefs.engineType,
    analysisDepth: stored.analysisDepth ?? prefs.analysisDepth,
    multiPV: stored.multiPV ?? prefs.multiPV,
    analysisOn: typeof stored.analysisOn === 'boolean' ? stored.analysisOn : prefs.analysisOn,
    panelVisible: typeof stored.panelVisible === 'boolean' ? stored.panelVisible : prefs.panelVisible,
    bestMoveHotkey: stored.bestMoveHotkey || prefs.bestMoveHotkey,
    autoMoveEnabled: typeof stored.autoMoveEnabled === 'boolean' ? stored.autoMoveEnabled : prefs.autoMoveEnabled,
    autoMoveDelayMs: stored.autoMoveDelayMs ?? prefs.autoMoveDelayMs,
  };

  const lishogiTabs = await chrome.tabs.query({ url: ['*://lishogi.org/*'] });
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const preferredTab = (activeTab?.url?.includes('lishogi.org') ? activeTab : null) || lishogiTabs[0] || null;
  activeTabId = preferredTab?.id || null;

  if (!preferredTab) {
    setPopupAvailability(false);
    return;
  }

  setPopupAvailability(true);

  if (preferredTab.url?.includes('lishogi.org') && activeTabId) {
    try {
      const liveState = await chrome.tabs.sendMessage(activeTabId, { type: 'GET_STATE' });
      renderUi({ ...(stored.shogiState || {}), ...liveState });
      return;
    } catch (e) {}
  }

  renderUi(stored.shogiState || {});
}

async function openStreamMode() {
  if (!activeTabId) return;
  try {
    await chrome.runtime.sendMessage({ type: 'SET_STREAM_MODE', tabId: activeTabId, enabled: true });
  } catch (e) {}
  await chrome.runtime.sendMessage({ type: 'OPEN_STREAM_WINDOW', tabId: activeTabId });
  window.close();
}

document.getElementById('enableEngine').addEventListener('change', async (event) => {
  prefs.analysisOn = event.target.checked;
  await savePrefs();
  await syncToPage({ triggerAnalysis: false });
});

document.getElementById('showPanel').addEventListener('change', async (event) => {
  prefs.panelVisible = event.target.checked;
  await savePrefs();
  await syncToPage();
});

document.getElementById('engineSelect').addEventListener('change', async (event) => {
  prefs.engineType = event.target.value || 'yaneuraou';
  normalizePrefs();
  updateSliderUi();
  await savePrefs();
  chrome.runtime.sendMessage({ type: 'SET_ENGINE', engine: prefs.engineType }).catch(() => {});
  await syncToPage();
});

document.getElementById('depthRange').addEventListener('input', async (event) => {
  prefs.analysisDepth = clampSetting(event.target.value, getEngineLimits(prefs.engineType).depth);
  updateSliderUi();
  await savePrefs();
  await syncToPage();
});

document.getElementById('pvRange').addEventListener('input', async (event) => {
  prefs.multiPV = clampSetting(event.target.value, getEngineLimits(prefs.engineType).multiPV);
  updateSliderUi();
  await savePrefs();
  await syncToPage();
});

document.getElementById('hotkeySelect').addEventListener('change', async (event) => {
  prefs.bestMoveHotkey = event.target.value || DEFAULT_PREFS.bestMoveHotkey;
  await savePrefs();
  await syncToPage();
});

document.getElementById('autoMoveEnabled').addEventListener('change', async (event) => {
  prefs.autoMoveEnabled = event.target.checked;
  await savePrefs();
  await syncToPage();
});

document.getElementById('autoDelayRange').addEventListener('input', async (event) => {
  prefs.autoMoveDelayMs = Math.max(0, Math.min(2000, parseInt(event.target.value, 10) || DEFAULT_PREFS.autoMoveDelayMs));
  document.getElementById('autoDelayValue').textContent = `${prefs.autoMoveDelayMs} ms`;
  await savePrefs();
  await syncToPage();
});

document.getElementById('btnRefresh').addEventListener('click', loadState);
document.getElementById('btnOpenStream').addEventListener('click', () => {
  openStreamMode().catch(() => {});
});
document.getElementById('openLishogiLink').addEventListener('click', async (event) => {
  event.preventDefault();
  await chrome.tabs.create({ url: 'https://lishogi.org/' });
  window.close();
});

loadState();
